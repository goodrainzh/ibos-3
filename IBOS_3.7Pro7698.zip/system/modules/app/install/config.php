<?php

defined( 'IN_MODULE_ACTION' ) or die( 'Access Denied' );
return array(
    'param' => array(
        'name' => '常用工具',
        'category' => '个人办公',
        'description' => '提供企业app应用功能',
        'author' => 'gzpjh @ IBOS Team Inc',
        'version' => '1.0',
        'pushMovement' => 0,
        'indexShow' => array(
            'link' => 'app/default/index'
        )
    ),
    'config' => array(
        'modules' => array(
            'app' => array(
				'class' => 'application\modules\app\AppModule'
			)
        ),
        'components' => array(
            'messages' => array(
                'extensionPaths' => array(
                    'app' => 'application.modules.app.language'
                )
            )
        ),
    ),
    'authorization' => array(
        'app' => array(
            'type' => 'node',
            'name' => '管理应用',
            'group' => '常用工具',
            'controllerMap' => array(
                'default' => array( 'index', 'applist', 'getapp', 'add', 'edit', 'del' )
            )
        )
    )
);
