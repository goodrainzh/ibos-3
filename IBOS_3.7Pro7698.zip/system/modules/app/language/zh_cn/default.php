<?php

/**
 * 应用门户默认语言包 zh_cn
 * 
 * @package application.modules.app.language.zh_cn
 * @version $Id: index.php 3475 2014-05-28 00:52:26Z gzpjh $
 * @author gzpjh <gzpjh@ibos.com.cn>
 */
return array(
	//applist
	'Application Market' => '应用市场',
	'All' => '全部',
	//index
	'Add Application plates' => '添加应用板块',
	'Other Applications' => '其他应用',
	'Add Applications' => '添加应用',
	'Remove application shortcuts' => '移除应用快捷方式',
	'Tools' => '常用工具'
);
