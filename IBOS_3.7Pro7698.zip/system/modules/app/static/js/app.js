var App = {
	op: {
		/**
		 * 获取应用工具
		 * @method getApp
		 * @return                返回deferred对象
		 */
		getApp: function(){
			var url = Ibos.app.url("app/default/applist");
			return $.get(url, $.noop);
		},
		/**
		 * 获取应用工具列表
		 * @method getAppList
		 * @param  {Object} param 传入json格式数据
		 * @return                返回deferred对象	  
		 */
		getAppList: function(param) {
			var url = Ibos.app.url("app/default/getapp");
			return $.post(url, param, $.noop, "json");
		},
		/**
		 * 添加应用快捷方式
		 * @method addShortcut
		 * @param  {Object} param 传入json格式数据
		 * @return                返回deferred对象
		 */
		addShortcut: function(param) {
			var url = Ibos.app.url("app/default/add");
			param = $.extend({}, param, {type : "shortcut"});
			return $.post(url, param, $.noop, "json");
		},
		/**
		 * 保存应用快捷方式
		 * @method saveShortcut
		 * @param  {Object} param 传入json格式数据
		 * @return                返回deferred对象
		 */
		saveShortcut: function(param) {
			var url = Ibos.app.url("app/default/edit");
			return $.post(url, param, $.noop, "json");
		},
		/**
		 * 保存窗口小部件
		 * @method saveWidgets
		 * @param  {Object} param 传入json格式数据
		 * @return                返回deferred对象	   
		 */
		saveWidgets: function(param) {
			var url = Ibos.app.url("app/default/add");
			param = $.extend({}, param, {type : "widget"});
			return $.post(url, param, $.noop, "json");
		},
		/**
		 * 删除窗口小部件
		 * @method delWidgets
		 * @param  {Object} param 传入json格式数据
		 * @return                返回deferred对象
		 */
		delWidgets : function(param){
			var url = Ibos.app.url("app/default/del");
			return $.post(url, param, $.noop, "json");
		}
	},
	/**
	 * 渲染窗口内的 app 备选列表
	 * @method renderAppList
	 * @param  {String} tpl  传入script模板id
	 * @param  {Array} 	data 传入array格式数据
	 */
	renderAppList: function(tpl, data) {
		var content = "";
		if (tpl && data && data.length) {
			for (var i = 0; i < data.length; i++) {
				content += $.template(tpl, data[i]);
			}
		}
		$("#app_pool").html(content);
	},
	/**
	 * 获取 app 应用列表
	 * @method getAppList
	 * @param  {Object}   param    	 传入JSON格式数据
	 * @param  {Function} [callback] 请求响应后的回调函数
	 */
	getAppList: function(param, callback) {
		var _this = this;
		this.op.getAppList(param).done(function(res) {
			if (res.isSuccess) {
				_this.renderAppList("tpl_app_item", res.data);
				Ibos.app.s({"appListParam": param});
				// 刷新页码按钮状态
					_this.updatePageTurnBtn({
						page: param.page,
						pageCount: res.pages
					});
				callback && callback(res);
			} else {
				Ui.tip(U.lang("APP.GET_APPLIST_ERROR"), "danger");
			}
		});
	},
	/**
	 * 更新翻页按钮状态
	 * @method updatePageTurnBtn
	 * @param  {Object} param 传入JSON格式数据
	 */
	updatePageTurnBtn: function(param) {
		var $prevBtn = $("#app_dialog [data-node-type='appPrevPageBtn']"),
				$nextBtn = $("#app_dialog [data-node-type='appNextPageBtn']");

		$prevBtn.prop("disabled", !param ? true : param.page <= 1);
		$nextBtn.prop("disabled", !param ? false : param.page >= param.pageCount);
	},
	/**
	 * 显示 app 弹窗
	 * @method showAppDialog
	 */
	showAppDialog: function() {
		Ui.closeDialog("d_app");
		var dialog = Ui.dialog({
			id: "d_app",
			// title: "添加应用",
			title: false,
			padding: 0,
			width: 760,
			height: 420,
			lock: true,
			skin: "art-autoheight"
		});
		
		this.op.getApp().done(function(res){
			dialog.content(res);
		});
	},
	/**
	 * 添加一个桌面快捷方式
	 * @method toAddShortcut
	 */
	toAddShortcut: function() {
		Ibos.app.s({"addAppType": "shortcut"});
		this.showAppDialog();
	},
	/**
	 * 移除应用快捷方式
	 * @method addShortcut
	 * @param {Object} data 传入模板JSON格式数据
	 */
	addShortcut: function(data) {
		var $shortcutList = $("#app_shortcut_list li");
		if( $shortcutList .siblings('[data-app-id="'+ data.appid +'"]').length ){
			Ui.tip("@APP.APPLICATION_OF_EXISTING", 'warning');
		}else{
			var $elem = $.tmpl("tpl_app_item", data);
			$elem.append("<i class='o-shortcut-remove' data-action='removeShortcut' title='"+ U.lang("APP.REMOVE_APP_SHORTCUT") +"'></i>");
			$shortcutList.last().before($elem);
		}
	},
	/**
	 * 隐藏添加应用
	 * @method setupShortcut
	 */
	setupShortcut: function() {
		$("#app_shortcut_list").addClass("editable").sortable({
			tolerance: "pointer",
			cursor: "move"
		}).find("li:last").hide();
	},
	/**
	 * 保存快捷方式
	 * @method saveShortcut
	 * @param  {Function} [callback] 回调函数
	 */
	saveShortcut: function(callback) {
		var scDatas = $("#app_shortcut_list [data-node-type='appItem']").map(function() {
			var data = $(this).data();
			return data.appId;
		}).get(),
			param = {shortcuts: scDatas};

		this.op.saveShortcut(param).done(function(res) {
			if (res.isSuccess) {
				$("#app_shortcut_list").removeClass("editable").sortable("destroy")
						.find("li:last").show();
				callback && callback(res);
			}
		});
	},
	/**
	 * 获取桌面上所有部件的 id
	 * @method getWidgetsId
	 * @return {Array}	返回所有部件的id数组 
	 */
	getWidgetsId: function() {
		return $("#app_widget_panel .mbox").map(function() {
			return $.attr(this, "data-id");
		}).get().join(",");
	},
	/**
	 * 保存 app 部件窗口
	 * @method saveWidgets
	 */
	saveWidgets: function() {
		var data = $("#app_widget_panel .mbox").map(function() {
			var data = $(this).data();
			return  data.appId;
		}).get();
	},
	/**
	 * 打开添加 app 部件窗口
	 * @method toAddWidget
	 */
	toAddWidget: function() {
		Ibos.app.s({"addAppType": "widget"});
		this.showAppDialog();
	},
	/**
	 * 添加 app 部件
	 * @method addWidget
	 * @param  {Object} data 传入模板JSON格式数据
	 */
	addWidget: function(data) {
		var a = $("#app_widget_panel").children().last().before($.template("tpl_app_widget", data));
		$("#app_widget_panel").removeClass("app-widget-empty");
	},
	// 
	/**
	 * 移除 app 部件
	 * @method removeWidget
	 * @param  {Element} $elem 传入jquery对象节点
	 */
	removeWidget: function($elem) {
		$elem.remove();
		var appWidgetPanel = $("#app_widget_panel");
		!(appWidgetPanel.find(".mbox").length) && appWidgetPanel.addClass("app-widget-empty");
	},
	/**
	 * 初始化部件和快捷方式
	 * @method initWidgetShort
	 */
	initWidgetShort: function(){
		// 初始化部件和快捷方式
		var widgetData = Ibos.app.g("widgets"),
			$this = this;
		if (widgetData && widgetData.length) {
			$.each(widgetData, function(i, w) {
				$this.addWidget(w);
			});
		}
		// 部件排序
		$("#app_widget_panel").sortable({
			items: ".mbox",
			tolerance: "pointer",
			handle: ".mbox-header",
			cursor: "move"
		}).on("sortupdate", function() {
			$this.saveWidgets();
		});

		var shortcutData = Ibos.app.g("shortcuts");
		if (shortcutData && shortcutData.length) {
			$.each(shortcutData, function(i, s) {
				$this.addShortcut(s);
			});
		}

		$("#app_sc_container").affixTo("#app_widget_panel");
	},
	/**
	 * 打开快捷方式
	 * @method  shortcutOpen
	 */
	shortcutOpen : function(){
		$(document).on("click", ".app-portal-sidebar .app-shortcut-list:not(.editable) [data-node-type='appItem']", function() {
			var data = $(this).data();
			Ui.closeDialog("d_app_ins");
			Ui.openFrame(data.appUrl, {
				id: "d_app_ins",
				title: data.appName,
				width: data.appWidth || 580,
				height: data.appHeight || 400,
				skin: "art-autoheight",
				padding: 0,
				lock: true,
				resize: true
			});
		});
	}
};


$(function() {
	// 初始化部件和快捷方式
	App.initWidgetShort();

	// 打开快捷方式
	App.shortcutOpen();

	Ibos.evt.add({
		// 添加应用
		"toAddShortcut": function() {
			App.toAddShortcut();
		},
		// 设置应用快捷方式
		"setupShortcut": function(param, elem) {
			App.setupShortcut();
			$(elem).addClass("active").attr("data-action", "saveShortcut");
		},
		// 保存应用快捷方式
		"saveShortcut": function(param, elem) {
			App.saveShortcut(function(res) {
				if (res.isSuccess) {
					$(elem).removeClass("active").attr("data-action", "setupShortcut");
					Ui.tip( U.lang("APP.SAVE_SHORTCUT_SUCCESS") );
				}
			});
		},
		// 删除应用快捷方式
		"removeShortcut": function(param, elem) {
			$(elem).closest("li").remove();
		},
		// 添加应用板块
		"toAddWidget": function() {
			App.toAddWidget();	
		},
		// 删除应用板块
		"removeWidget": function(param, elem, callback) {
			App.op.delWidgets(param).done(function(res){
				App.removeWidget($(elem).closest(".mbox"));
			});
		}
	});
});