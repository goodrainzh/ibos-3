/**
 * 常用工具中文包
 */
var L = L || {};

L.APP = {
	GET_APPLIST_ERROR : "获取 app 列表失败",
	REMOVE_APP_SHORTCUT : "移除应用快捷方式",
	SAVE_SHORTCUT_SUCCESS : "保存应用快捷方式成功",
	APPLICATION_OF_EXISTING : "该应用已经添加"
};