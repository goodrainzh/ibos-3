<?php

/**
 * 信息中心模块------ module类文件
 *
 * @link http://www.ibos.com.cn/
 * @copyright Copyright &copy; 2008-2013 IBOS Inc
 * @author Ring <Ring@ibos.com.cn>
 */
/**
 * 信息中心模块------  module类文
 * @package application.modules.article
 * @version $Id: ArticleModule.php 4064 2014-09-03 09:13:16Z zhangrong $
 * @author Ring <Ring@ibos.com.cn>
 */

namespace application\modules\article;

use application\core\modules\Module;

class ArticleModule extends Module {
    
}
