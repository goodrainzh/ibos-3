<?php

use application\core\utils\Cache;

Cache::rm( 'notifyNode' );
