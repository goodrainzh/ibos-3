<?php

/**
 * 日程安排模块
 * 
 * @package application.modules.calendar
 * @version $Id: CalendarModule.php 605 2013-10-28 04:17:21Z gzhzh $
 * @author gzhzh <gzhzh@ibos.com.cn>
 */

namespace application\modules\calendar;

use application\core\modules\Module;

class CalendarModule extends Module {
    
}
