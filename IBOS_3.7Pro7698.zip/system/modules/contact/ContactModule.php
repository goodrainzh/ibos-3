<?php

/**
 * 通讯录模块------ module类文件
 *
 * @link http://www.ibos.com.cn/
 * @copyright Copyright &copy; 2008-2013 IBOS Inc
 * @author gzhzh <gzhzh@ibos.com.cn>
 */
/**
 * 通讯录模块------  module类文
 * @package application.modules.contact
 * @version $Id: ContactModule.php 665 2013-06-24 01:03:57Z gzhzh $
 * @author gzhzh <gzhzh@ibos.com.cn>
 */

namespace application\modules\contact;

use application\core\modules\Module;

class ContactModule extends Module {
    
}
