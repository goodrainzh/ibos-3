/**
 * 通讯录模块中文语言包
 */
var L = L || {};

L.CONT = {
	QQ_INVALID_FORMAT 	: 		"QQ格式不正确",
	SUCCESS_ADD_CONTACT : 		"成功添加外部联系人！"	
};