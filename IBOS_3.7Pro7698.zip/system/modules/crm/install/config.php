<?php

defined( 'IN_MODULE_ACTION' ) or die( 'Access Denied' );
return array(
    'param' => array(
        'name' => 'CRM',
        'category' => 'CRM',
        'description' => '客户关系管理系统',
        'author' => 'banyan @ IBOS Team Inc',
        'version' => '1.0'
    ),
    'config' => array(
        'modules' => array(
            'crm' => array(
                'class' => 'application\modules\crm\CrmModule',
            )
        ),
        'components' => array(
            'messages' => array(
                'extensionPaths' => array(
                    'crm' => 'application.modules.crm.language'
                )
            )
        ),
    ),
    'authorization' => array(
        'index' => array(
            'type' => 'node',
            'name' => 'CRM首页',
            'group' => '浏览',
            'controllerMap' => array(
                'index' => array( 'index' ),
            )
        ),
        'manage' => array(
            'type' => 'node',
            'name' => '权限管理',
            'group' => '高级设置',
            'controllerMap' => array(
                'authority' => array( 'index', 'edit' ),
            )
        ),
        'querypreset' => array(
            'type' => 'node',
            'name' => '查询预设',
            'group' => '高级设置',
            'controllerMap' => array(
                'query' => array( 'index', 'add', 'edit', 'del', 'editgroup' ),
            )
        ),
        'lead' => array(
            'type' => 'data',
            'name' => '线索',
            'group' => '线索',
            'node' => array(
                'index' => array(
                    'name' => '读取',
                    'controllerMap' => array(
                        'lead' => array( 'index' )
                    )
                ),
                'add' => array(
                    'name' => '创建',
                    'controllerMap' => array(
                        'lead' => array( 'add' )
                    )
                ),
                'edit' => array(
                    'name' => '编辑',
                    'controllerMap' => array(
                        'lead' => array( 'edit', 'trans' )
                    )
                ),
                'del' => array(
                    'name' => '删除',
                    'controllerMap' => array(
                        'lead' => array( 'del' )
                    )
                ),
                'assign' => array(
                    'name' => '分配',
                    'controllerMap' => array(
                        'lead' => array( 'assign' )
                    )
                ),
                'share' => array(
                    'name' => '分享',
                    'controllerMap' => array(
                        'lead' => array( 'share' )
                    )
                )
            )
        ),
        'clients' => array(
            'type' => 'data',
            'name' => '客户',
            'group' => '客户',
            'node' => array(
                'index' => array(
                    'name' => '读取',
                    'controllerMap' => array(
                        'client' => array( 'index' )
                    )
                ),
                'add' => array(
                    'name' => '创建',
                    'controllerMap' => array(
                        'client' => array( 'add' )
                    )
                ),
                'edit' => array(
                    'name' => '编辑',
                    'controllerMap' => array(
                        'client' => array( 'edit' )
                    )
                ),
                'del' => array(
                    'name' => '删除',
                    'controllerMap' => array(
                        'client' => array( 'del' )
                    )
                ),
                'assign' => array(
                    'name' => '分配',
                    'controllerMap' => array(
                        'client' => array( 'assign' )
                    )
                ),
                'share' => array(
                    'name' => '分享',
                    'controllerMap' => array(
                        'client' => array( 'share' )
                    )
                )
            )
        ),
        'contacts' => array(
            'type' => 'data',
            'name' => '联系人',
            'group' => '联系人',
            'node' => array(
                'index' => array(
                    'name' => '读取',
                    'controllerMap' => array(
                        'contact' => array( 'index' )
                    )
                ),
                'add' => array(
                    'name' => '创建',
                    'controllerMap' => array(
                        'contact' => array( 'add' )
                    )
                ),
                'edit' => array(
                    'name' => '编辑',
                    'controllerMap' => array(
                        'contact' => array( 'edit' )
                    )
                ),
                'del' => array(
                    'name' => '删除',
                    'controllerMap' => array(
                        'contact' => array( 'del' )
                    )
                ),
                'assign' => array(
                    'name' => '分配',
                    'controllerMap' => array(
                        'contact' => array( 'assign' )
                    )
                ),
                'share' => array(
                    'name' => '分享',
                    'controllerMap' => array(
                        'contact' => array( 'share' )
                    )
                )
            )
        ),
        'opportunitys' => array(
            'type' => 'data',
            'name' => '机会',
            'group' => '机会',
            'node' => array(
                'index' => array(
                    'name' => '读取',
                    'controllerMap' => array(
                        'opportunity' => array( 'index' )
                    )
                ),
                'add' => array(
                    'name' => '创建',
                    'controllerMap' => array(
                        'opportunity' => array( 'add' )
                    )
                ),
                'edit' => array(
                    'name' => '编辑',
                    'controllerMap' => array(
                        'opportunity' => array( 'edit' )
                    )
                ),
                'del' => array(
                    'name' => '删除',
                    'controllerMap' => array(
                        'opportunity' => array( 'del' )
                    )
                ),
                'assign' => array(
                    'name' => '分配',
                    'controllerMap' => array(
                        'opportunity' => array( 'assign' )
                    )
                ),
                'share' => array(
                    'name' => '分享',
                    'controllerMap' => array(
                        'opportunity' => array( 'share' )
                    )
                )
            )
        ),
        'contracts' => array(
            'type' => 'data',
            'name' => '合同',
            'group' => '合同',
            'node' => array(
                'index' => array(
                    'name' => '读取',
                    'controllerMap' => array(
                        'contract' => array( 'index' )
                    )
                ),
                'add' => array(
                    'name' => '创建',
                    'controllerMap' => array(
                        'contract' => array( 'add' )
                    )
                ),
                'edit' => array(
                    'name' => '编辑',
                    'controllerMap' => array(
                        'contract' => array( 'edit' )
                    )
                ),
                'del' => array(
                    'name' => '删除',
                    'controllerMap' => array(
                        'contract' => array( 'del' )
                    )
                ),
                'assign' => array(
                    'name' => '分配',
                    'controllerMap' => array(
                        'contract' => array( 'assign' )
                    )
                ),
                'share' => array(
                    'name' => '分享',
                    'controllerMap' => array(
                        'contract' => array( 'share' )
                    )
                )
            )
        ),
        'receipts' => array(
            'type' => 'data',
            'name' => '收款',
            'group' => '收款',
            'node' => array(
                'index' => array(
                    'name' => '读取',
                    'controllerMap' => array(
                        'receipt' => array( 'index' )
                    )
                ),
                'add' => array(
                    'name' => '创建',
                    'controllerMap' => array(
                        'receipt' => array( 'add' )
                    )
                ),
                'edit' => array(
                    'name' => '编辑',
                    'controllerMap' => array(
                        'receipt' => array( 'edit' )
                    )
                ),
                'del' => array(
                    'name' => '删除',
                    'controllerMap' => array(
                        'receipt' => array( 'del' )
                    )
                ),
                'assign' => array(
                    'name' => '分配',
                    'controllerMap' => array(
                        'receipt' => array( 'assign' )
                    )
                ),
                'share' => array(
                    'name' => '分享',
                    'controllerMap' => array(
                        'receipt' => array( 'share' )
                    )
                )
            )
        ),
        'events' => array(
            'type' => 'data',
            'name' => '事件',
            'group' => '事件',
            'node' => array(
                'index' => array(
                    'name' => '读取',
                    'controllerMap' => array(
                        'event' => array( 'index' )
                    )
                ),
                'add' => array(
                    'name' => '创建',
                    'controllerMap' => array(
                        'event' => array( 'add' )
                    )
                ),
                'edit' => array(
                    'name' => '编辑',
                    'controllerMap' => array(
                        'event' => array( 'edit' )
                    )
                ),
                'del' => array(
                    'name' => '删除',
                    'controllerMap' => array(
                        'event' => array( 'del' )
                    )
                ),
                'assign' => array(
                    'name' => '分配',
                    'controllerMap' => array(
                        'event' => array( 'assign' )
                    )
                ),
                'share' => array(
                    'name' => '分享',
                    'controllerMap' => array(
                        'event' => array( 'share' )
                    )
                )
            )
        ),
        'highseaview' => array(
            'type' => 'node',
            'name' => '公海浏览',
            'group' => '高级设置',
            'controllerMap' => array(
                'highseas' => array( 'index' )
            )
        ),
        'highseamanager' => array(
            'type' => 'node',
            'name' => '公海管理',
            'group' => '高级设置',
            'controllerMap' => array(
                'highseas' => array( 'add', 'edit', 'del' )
            )
        ),
        'tags' => array(
            'type' => 'node',
            'name' => '标签管理',
            'group' => '高级设置',
            'controllerMap' => array(
                'tag' => array( 'index', 'add', 'edit', 'del' )
            )
        ),
        'products' => array(
            'type' => 'node',
            'name' => '产品管理',
            'group' => '高级设置',
            'controllerMap' => array(
                'product' => array( 'index', 'add', 'edit', 'del' ),
            )
        ),
    )
);
