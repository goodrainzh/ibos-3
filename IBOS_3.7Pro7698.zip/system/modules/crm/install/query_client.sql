INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '9', '归属用户是我自己', '0', '1', '1', '2', '1', 
" `c_cl`.`uid` = '{-ME-}'", 
" 客户-归属用户ID = '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '10', '别人分配给我未读', '0', '2', '1', '2', '1', 
" `c_cl`.`isunread` = '{-YES-}'\n
AND `c_cl`.`uid` = '{-ME-}'\n
AND `c_cl`.`assignuid` != '{-ME-}'", 
" 客户-新分配的记录未读 = '是'\n
AND 客户-归属用户ID = '当前用户'\n
AND 客户-分配者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '11', '其他人共享给我的', '0', '3', '1', '2', '1', 
" `c_cl_i`.`uid` = '{-ME-}'\n
AND `c_cl_i`.`shareuid` != '{-ME-}'",
" 客户-被分享用户ID = '当前用户'\n
AND 客户-分享者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '12', '我共享给其他人的', '0', '4', '1', '2', '1', 
" `c_cl_i`.`shareuid` = '{-ME-}'\n
AND `c_cl_i`.`uid` != '{-ME-}'",
" 客户-分享者ID = '当前用户'\n
AND 客户-被分享用户ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '13', '本月新增加的客户', '0', '5', '1', '2', '1', 
" `c_cl`.`createtime` < '{-THIS_MONTH.END-}'\n
AND `c_cl`.`createtime` >= '{-THIS_MONTH.START-}'",
" 客户-创建时间 < '这个月末'\n
AND 客户-创建时间 >= '这个月初' ", '0', '' );