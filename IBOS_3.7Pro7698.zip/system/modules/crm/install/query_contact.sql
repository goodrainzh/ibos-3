INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '14', '归属用户是我自己', '0', '1', '1', '3', '1', 
" `c_ct`.`uid` = '{-ME-}'", 
" 联系人-归属用户ID = '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '15', '别人分配给我未读', '0', '2', '1', '3', '1', 
" `c_ct`.`isunread` = '{-YES-}'\n
AND `c_ct`.`uid` = '{-ME-}'\n
AND `c_ct`.`assignuid` != '{-ME-}'",
" 联系人-新分配的记录未读 = '是'\n
AND 联系人-归属用户ID = '当前用户'\n
AND 联系人-分配者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '16', '其他人共享给我的', '0', '3', '1', '3', '1', 
" `c_ct_i`.`uid` = '{-ME-}'\n
AND `c_ct_i`.`shareuid` != '{-ME-}'",
" 联系人-被分享用户ID = '当前用户'\n
AND 联系人-分享者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '17', '我共享给其他人的', '0', '4', '1', '3', '1', 
" `c_ct_i`.`shareuid` = '{-ME-}'\n
AND `c_ct_i`.`uid` != '{-ME-}'",
" 联系人-分享者ID = '当前用户'\n
AND 联系人-被分享用户ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '18', '本月新增的联系人', '0', '5', '1', '3', '1', 
" `c_ct`.`createtime` < '{-THIS_MONTH.END-}'\n
AND `c_ct`.`createtime` >= '{-THIS_MONTH.START-}'",
" 联系人-创建时间 < '这个月末'\n
AND 联系人-创建时间 >= '这个月初' ", '0', '' );