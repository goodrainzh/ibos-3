INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '27', '归属用户是我自己', '0', '1', '1', '5', '1', 
" `c_e`.`uid` = '{-ME-}'",
" 事件-归属用户ID = '当前用户'", '0', '');
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '28', '别人分配给我未读', '0', '2', '1', '5', '1', 
" `c_e`.`isunread` = '{-YES-}'\n
AND `c_e`.`uid` = '{-ME-}'\n
AND `c_e`.`assignuid` != '{-ME-}'",
" 事件-新分配的记录未读 = '是'\n
 AND 事件-归属用户ID = '当前用户'\n
 AND 事件-分配者ID != '当前用户' ", '0', '');
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '29', '其他人共享给我的', '0', '3', '1', '5', '1', 
" `c_e_i`.`uid` = '{-ME-}'\n
AND `c_e_i`.`shareuid` != '{-ME-}'",
" 事件-被分享用户ID = '当前用户'\n
 AND 事件-分享者ID != '当前用户' ", '0', '');
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '30', '我共享给其他人的', '0', '4', '1', '5', '1', 
" `c_e_i`.`shareuid` = '{-ME-}'\n
AND `c_e_i`.`uid` != '{-ME-}'",
" 事件-分享者ID = '当前用户'\n
 AND 事件-被分享用户ID != '当前用户' ", '0', '');
