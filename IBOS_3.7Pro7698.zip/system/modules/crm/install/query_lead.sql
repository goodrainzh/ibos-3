INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '1', '归属用户是我自己', '0', '1', '1', '1', '1', 
" `c_l`.`uid` = '{-ME-}'",
" 线索-归属用户ID = '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '2', '别人分配给我未读', '0', '2', '1', '1', '1', 
" `c_l`.`isunread` = '{-YES-}'\n
AND `c_l`.`uid` = '{-ME-}'\n
AND `c_l`.`assignuid` != '{-ME-}'",
" 线索-新分配的记录未读 = '是'\n
  AND 线索-归属用户ID = '当前用户'\n
  AND 线索-分配者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '3', '其他人共享给我的', '0', '3', '1', '1', '1', 
" `c_l_i`.`uid` = '{-ME-}'\n
AND `c_l_i`.`shareuid` != '{-ME-}'",
" 线索-被分享用户ID = '当前用户'\n
  AND 线索-分享者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '4', '我共享给其他人的', '0', '4', '1', '1', '1', 
" `c_l_i`.`shareuid` = '{-ME-}'\n
AND `c_l_i`.`uid` != '{-ME-}'",
" 线索-分享者ID = '当前用户'\n
  AND 线索-被分享用户ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '5', '我的共享给其他人', '0', '5', '1', '1', '1', 
" `c_l`.`uid` = '{-ME-}'\n
AND `c_l_i`.`shareuid` = '{-ME-}'\n
AND `c_l_i`.`uid` != '{-ME-}'",
" 线索-归属用户ID = '当前用户'\n
  AND 线索-分享者ID = '当前用户'\n
  AND 线索-被分享用户ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '6', '本月新增加的线索', '0', '6', '1', '1', '1', 
" `c_l`.`createtime` < '{-THIS_MONTH.END-}'\n
AND `c_l`.`createtime` >= '{-THIS_MONTH.START-}'",
" 线索-创建时间 < '这个月末'\n
  AND 线索-创建时间 >= '这个月初' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '7', '本月已转化的线索', '0', '7', '1', '1', '1', 
" `c_l`.`converttime` < '{-THIS_MONTH.END-}'\n
AND `c_l`.`converttime` >= '{-THIS_MONTH.START-}' ",
" 线索-转换时间 < '这个月末'\n
AND 线索-转换时间 >= '这个月初' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '8', '本月已丢失的线索', '0', '8', '1', '1', '1', 
" `c_l`.`converttime` < '{-THIS_MONTH.END-}'\n
AND `c_l`.`converttime` >= '{-THIS_MONTH.START-}'\n
AND `c_l`.`status` = '{-LEAD_STATE.LOST-}'",
" 线索-转换时间 < '这个月末'\n
  AND 线索-转换时间 >= '这个月初'\n
  AND 线索-转换状态 = '丢失' ", '0', '' );