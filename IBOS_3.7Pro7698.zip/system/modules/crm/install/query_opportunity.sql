INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '19', '归属用户是我自己', '0', '1', '1', '4', '1', 
" `c_o`.`uid` = '{-ME-}'",
" 机会-归属用户ID = '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '20', '别人分配给我未读', '0', '2', '1', '4', '1', 
" `c_o`.`isunread` = '{-YES-}'\n
AND `c_o`.`uid` = '{-ME-}'\n
AND `c_o`.`assignuid` != '{-ME-}'", 
" 机会-新分配的记录未读 = '是'\n
  AND 机会-归属用户ID = '当前用户'\n
  AND 机会-分配者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '21', '其他人共享给我的', '0', '3', '1', '4', '1', 
" `c_o_i`.`uid` = '{-ME-}'\n
AND `c_o_i`.`shareuid` != '{-ME-}'", 
" 机会-被分享用户ID = '当前用户'\n
  AND 机会-分享者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '22', '我共享给其他人的', '0', '4', '1', '4', '1', 
" `c_o_i`.`shareuid` = '{-ME-}'\n
AND `c_o_i`.`uid` != '{-ME-}'", 
" 机会-分享者ID = '当前用户'\n
  AND 机会-被分享用户ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '23', '本月新增加的机会', '0', '5', '1', '4', '1', 
" `c_o`.`createtime` < '{-THIS_MONTH.END-}'\n
AND `c_o`.`createtime` >= '{-THIS_MONTH.START-}'", 
" 机会-创建时间 < '这个月末'\n
  AND 机会-创建时间 >= '这个月初' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '24', '预计本月结束机会', '0', '6', '1', '4', '1', 
" `c_o`.`expectendtime` < '{-THIS_MONTH.END-}'\n
AND `c_o`.`expectendtime` >= '{-THIS_MONTH.START-}'", 
" 机会-预期结束时间 < '这个月末'\n
  AND 机会-预期结束时间 >= '这个月初' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '25', '本月已失败的机会', '0', '7', '1', '4', '1', 
" `c_o`.`createtime` < '{-THIS_MONTH.END-}'\n
AND `c_o`.`createtime` >= '{-THIS_MONTH.START-}'\n
AND `c_o`.`status` = '{-OPP_STATE.F-}'", 
" 机会-创建时间 < '这个月末'\n
  AND 机会-创建时间 >= '这个月初'\n
  AND 机会-成交状态 = '失败' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '26', '本月已成功的机会', '0', '8', '1', '4', '1', 
" `c_o`.`createtime` < '{-THIS_MONTH.END-}'\n
AND `c_o`.`createtime` >= '{-THIS_MONTH.START-}'\n
AND `c_o`.`status` = '{-OPP_STATE.S-}'", 
" 机会-创建时间 < '这个月末'\n
  AND 机会-创建时间 >= '这个月初'\n
  AND 机会-成交状态 = '成功' ", '0', '' );
