INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '36', '归属用户是我自己', '0', '1', '1', '7', '1', 
" `c_rc`.`uid` = '{-ME-}'", 
" 收款-归属用户ID = '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '37', '别人分配给我未读', '0', '2', '1', '7', '1', 
" `c_rc`.`isunread` = '{-YES-}'\n
AND `c_rc`.`uid` = '{-ME-}'\n
AND `c_rc`.`assignuid` != '{-ME-}'", 
" 收款-新分配的记录未读 = '是'\n
  AND 收款-归属用户ID = '当前用户'\n
  AND 收款-收款-分配者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '38', '其他人共享给我的', '0', '3', '1', '7', '1', 
" `c_rc_i`.`uid` = '{-ME-}'\n
AND `c_rc_i`.`shareuid` != '{-ME-}'", 
" 收款-分享者ID = '当前用户'\n
  AND 收款-分享者ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '39', '我共享给其他人的', '0', '4', '1', '7', '1', 
" `c_rc_i`.`shareuid` = '{-ME-}'\n
AND `c_rc_i`.`uid` != '{-ME-}'", 
" 收款-分享者ID = '当前用户'\n
  AND 收款-被分享用户ID != '当前用户' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '40', '本月已完成的收款', '0', '5', '1', '7', '1', 
" `c_rc`.`receive` > '0'\n
AND `c_rc`.`receivetime` >= '{-THIS_MONTH.STRAT-}'\n
AND `c_rc`.`receivetime` < '{-THIS_MONTH.END-}'", 
" 收款-到账金额 > '0'\n
  AND 收款-收款时间 >= '这个月末'\n
  AND 收款-收款时间 < '这个月初' ", '0', '' );
INSERT INTO `{{crm_query}}` ( `queryid`, `name`, `createtime`, `sort`, `status`, `groupid`, `system`, `condformula`, `condtext`, `uid`, `shareuid` ) VALUES ( '41', '预计本月完成收款', '0', '6', '1', '7', '1', 
" `c_rc`.`planreceive` > '0'\n
AND `c_rc`.`planreceivetime` >= '{-THIS_MONTH.START-}'\n
AND `c_rc`.`planreceivetime` < '{-THIS_MONTH.END-}'", 
" 收款-计划到账金额 > '0'\n
  AND 收款-计划收款时间 >= '这个月末'\n
  AND 收款-计划收款时间 < '这个月初' ", '0', '' );
