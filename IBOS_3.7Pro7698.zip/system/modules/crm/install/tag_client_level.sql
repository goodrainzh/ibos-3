INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '7', '未分级客户', 'rgb(218, 223, 230)', '2', '1', '1' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '8', '小型客户', '#7AC2F3', '2', '1', '2' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '9', '中型客户', '#A7D85A', '2', '1', '3' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '10', '大型客户', '#FFBB6D', '2', '1', '4' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '11', 'VIP客户', '#E88C73', '2', '1', '5' );
