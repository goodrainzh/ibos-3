INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '1', '初步接触', 'rgb(218, 223, 230)', '1','1', '1' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '2', '确定意向', '#7AC2F3', '1', '1', '2' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '3', '重点跟进', '#A7D85A', '1', '1', '3' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '4', '签约客户', '#FFBB6D', '1', '1', '4' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '5', '停滞客户', '#FFE18F', '1', '1', '5' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '6', '丢单客户', '#E88C73', '1', '1', '6' );
