INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '27', '初相识', 'rgb(218, 223, 230)', '6', '1', '1' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '28', '一般关系', '#7AC2F3', '6', '1', '2' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '29', '朋友关系', '#A7D85A', '6', '1', '3' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '30', '好友关系', '#FFBB6D', '6', '1', '4' );
