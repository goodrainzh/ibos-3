INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '22', '经办人', 'rgb(218, 223, 230)', '5', '1', '1' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '23', '决策人', '#7AC2F3', '5', '1', '2' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '24', '使用人', '#A7D85A', '5', '1', '3' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '25', '意见影响人', '#FFBB6D', '5', '1', '4' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '26', '商务决策', '#E88C73', '5', '1', '5' );
