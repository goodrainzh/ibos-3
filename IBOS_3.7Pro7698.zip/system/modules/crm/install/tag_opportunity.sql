INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '12', '1-前期接触', 'rgb(218, 223, 230)', '3', '1', '1' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '13', '2-机会评估', '#7AC2F3', '3', '1', '2' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '14', '3-需求分析', '#A7D85A', '3', '1', '3' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '15', '4-方案提供', '#FFBB6D', '3', '1', '4' );
INSERT INTO {{crm_tag}} ( `tagid`, `name`, `color` , `groupid` , `system` , `sort` ) VALUES ( '16', '5-多方选择/评估', '#E88C73', '3', '1', '5' );
