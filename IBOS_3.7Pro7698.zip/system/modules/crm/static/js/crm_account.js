/**
 * CRM 客户模块
 * @author inaki
 * @version $Id$
 */

(function() {
	var Account = {
		op: {
			// 客户数据验证
			_validateAccount: function(data) {
				var _parsedData;
				if (!data || !data.length) {
					return false;
				}
				_parsedData = U.serializedToObject(data);
				if (!$.trim(_parsedData.fullname)) {
					return false;
				}
				return true;
			},
			// 新建客户
			add: function(data, callback) {
				if (this._validateAccount(data.formData)) {
					$.post(Ibos.app.url('crm/client/add'), data.formData, function(res) {
						callback && callback(res);
						$(Account).trigger("accountadd", {data: data.formData, res: res, client: data.client});
					}, "json");
				}
			},
			// 更新客户信息
			update: function(id, data, callback) {
				if (this._validateAccount(data)) {
					data.push({name: "id", value: id});
					$.post(Ibos.app.url('crm/client/edit'), data, function(res) {
						callback && callback(res);
						$(Account).trigger("accountupdate", {id: id, data: data, res: res});
					}, "json");
				}
			},
			// 删除客户
			remove: function(ids, callback) {
				if (ids) {
					$.post(Ibos.app.url('crm/client/del'), {ids: ids}, function(res) {
						callback && callback(res);
						$(Account).trigger("accountremove", {ids: ids, res: res});
					}, "json");
				}
			},
			// 获取客户
			get: function(param, callback) {
				if ($.isFunction(param)) {
					callback = param;
					param = null;
				}
				$.post(Ibos.app.url('crm/client/select'), param, function(res) {
					callback && callback(res);
				}, "json");
			},
			// 移动到公海
			moveToHighseas: function(data, callback) {
				$.post(Ibos.app.url('crm/client/movehighsea'), data, function(res) {
					callback && callback(res);
				}, "json");
			},
			// 恢复快照
			restoreSnap: function(param, callback) {
				$.post(Ibos.app.url('crm/client/restoresnap'), param, function(res) {
					callback && callback(res);
				}, 'json');
			},
			// 领取客户
			pull: function(ids, callback) {
				if (ids) {
					$.post(Ibos.app.url('crm/client/claim'), {ids: ids, seaid: Ibos.app.g('seaid')}, function(res) {
						callback && callback(res);
					}, "json");
				}
			}
		},
		_dialog: function(url, opts) {
			Ui.closeDialog("d_account_info");
			if (url) {
				Ui.ajaxDialog(url, $.extend({
					id: "d_account_info",
					title: U.lang("CRM.ACCOUNT_INFO"),
					padding: 0,
					lock: true,
					ok: true,
					okVal: U.lang("SAVE"),
					cancel: true,
					close: function() {
						$.formValidator && $.formValidator.resetTipState("accountInfo");
					}
				}, opts));
			}

		},
		_validateForm: function(ok) {
			var formData;
			if ($.formValidator && $.formValidator.pageIsValid("accountInfo")) {
				formData = this.DOM.content.find("form").serializeArray();
				ok && ok.call(this, formData);
			}
		},
		// 新建客户
		add: function(param) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/client/add'), {
				ok: function() {
					_this._validateForm.call(this, function(formData) {
						Account.op.add($.extend({
							formData: formData
						}, param));
					});
					return false;
				},
				title: U.lang("CRM.ADD_CLIENT")
			});
		},
		// 编辑客户
		edit: function(param, ok) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/client/edit', param || {}), {
				ok: function() {
					_this._validateForm.call(this, function(formData) {
						// 更新信息需要具体 id
						Account.op.update(param.id, formData);
					});
					return false;
				}
			});
		},
		// 打开公海对话框
		showHighseasPoolDialog: function(ok) {
			Ui.closeDialog("d_highseas_pool");
			Ui.ajaxDialog(Ibos.app.url('crm/client/movehighsea'), {
				id: "d_highseas_pool",
				title: U.lang("CRM.SELECT_TARGET_HIGHSEAS"),
				padding: "0 0 20px 0",
				init: function() {
					$("#highseas_pool").on("click", "li", function() {
						var $item = $(this);
						if ($item.hasClass("active")) {
							$item.removeClass("active");
						} else {
							$item.addClass("active").siblings().removeClass("active");
						}
					});
				},
				ok: function() {
					var highseasIds = $("#highseas_pool li.active").map(function() {
						return $.attr(this, "data-highseas-id");
					}).get().join(",");
					ok && ok.call(this, highseasIds);
					return false;
				},
				okVal: U.lang("SAVE"),
				cancel: true
			});
		},
		// 百度一下 (~~囧~~)
		baiduSearch: function(keyword) {
			// var tpl = '<div>' +
			// 		'<ul class="nav nav-skid nav-skid-inverse" id="baidu_search_tab">' +
			// 		'<li class="active"><a href="http://www.baidu.com/index.php?isidx=1#wd=<%=keyword%>" target="baidu_search_frame">Baidu</a></li>' +
			// 		'<li><a href="http://www.google.com/#newwindow=1&q=<%=keyword%>" target="_blank">Google</a></li>' +
			// 		'<li><a href="http://www.bing.com/search?q=<%=keyword%>" target="_blank">Bing</a></li>' +
			// 		'</ul>' +
			// 		'</div>' +
			// 		'<div>' +
			// 		'<iframe frameborder="0" id="baidu_search_frame" style="width: 730px; height: 580px;" src="http://www.baidu.com/s?wd=<%=keyword%>"></iframe>' +
			// 		'</div>';
			// Ui.dialog({
			// 	id: "d_baidu_search",
			// 	title: U.lang("CRM.BAIDU_SEARCH"),
			// 	content: $.template(tpl, {keyword: keyword}),
			// 	padding: 0
			// });
			// 修改为在新窗口中进行百度搜索
			window.open("http://www.baidu.com/s?wd=" + keyword);
		},
		// 选择客户对话框，单选
		selectOne: function(param, ok) {
			var _this = this,
				dialog = Ui.ajaxDialog(Ibos.app.url('crm/client/select', param), {
					id: "d_select_account",
					title: U.lang("CRM.SELECT_ACCOUNT"),
					padding: 0,
					init: function() {
						var bcb = new Crm.BnCardBox({
							container: "#acc_bncard_list",
							page: "#select_acc_pn",
							search: "#select_acc_search"
						}, {
							tpl: "tpl_acc_card",
							op: _this.op.get
						});
						$("#acc_bncard_list").on("click", "[data-node-type='bncard']", function() {
							var selected = $(this).data("id"),
								title = $(this).find(".bncard-title").text(),
								account = {
									fullname: title,
									url: Ibos.app.url("crm/client/detail", {id: selected})
								};

							ok && ok(selected, account);
							Ui.getDialog("d_select_account").close();
						});
					},
					ok: false,
					close: function(){
						Ibos.app.s("bnCards", null);
						Ibos.app.s("crmAccounts", null);
					},
					cancel: function(){
						Ibos.app.s("bnCards", null);
						Ibos.app.s("crmAccounts", null);
					},
					cancelVal: U.lang("CLOSE"),
					lock: true
				});
			dialog.opParams = param;
		}
	};
	Crm.Account = Account;
})();
$(function() {
	var Account = Crm.Account;
	$(Account).on({
		"accountadd": function(evt, evtData) {
			var res = evtData.res,
				url = Ibos.app.url("crm/client/detail", {id: res.cid});
			if (res.isSuccess) {
				Ui.getDialog("d_account_info").close();
				if( evtData.client == 1 ){
					$(".crm-warning-tip").slideUp(200, function () {
						var index= function(){
									var i = 0, 
										len = evtData.data.length,
										item;
									for( i = 0; i < len; i++ ){
										item = evtData.data[i];
										if( item.name === 'fullname' ){
											return i;
										}
									}
									return -1;
								}(),
							data = {
								account: {
									url: url,
									fullname: U.entity.escape(evtData.data[index].value)
								}, 
								cid: res.cid
							};
						$(this).html($.template("tpl_account_associated", data)).slideDown(200);
					});
				}else{
					location.href = url;
					Ui.tip("@OPERATION_SUCCESS");
				}
			} else {
				Ui.tip(res.msg, "danger");
			}
		},
		"accountupdate": function(evt, evtData) {
			var res = evtData.res;
			if (res.isSuccess) {
				Ui.tip("@OPERATION_SUCCESS");
				Ui.getDialog("d_account_info").close();
				window.location.reload();
			} else {
				Ui.tip(res.msg, "danger");
			}
		},
		"accountremove": function(evt, evtData) {
			var res = evtData.res;
			if (res.isSuccess) {
				Ui.tip("@OPERATION_SUCCESS");
			} else {
				Ui.tip(res.msg, "danger");
			}
		}
	});

	Ibos.evt.add({
		// 百度一下
		"baiduSearch": function(param) {
			Account.baiduSearch(param.keyword);
		},
		// 添加客户
		"addAccount": function(param) {
			Account.add(param);
		},
		// 编辑客户信息
		"updateAccount": function(param) {
			Account.edit(param);
		},
		// 打开文件上传对话框
		"openUploadDialog": function() {
			Ibos.uploadDialog({
				upload_url: Ibos.app.url('crm/client/attach'),
				post_params: {id: Ibos.app.g("accountId")},
				custom_settings: {
					success: function(file, res) {
						var dyAttachment = $("#dy_attachment");
						dyAttachment.prepend($.template("tpl_attach", res)).closest(".crm-attach-card").removeClass("empty");
						if( dyAttachment.children().length > 5 ){
							dyAttachment.children(".media:last").remove();
						}
					}
				}
			});
		}
	});
});
