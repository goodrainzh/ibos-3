/**
 * Crm 客户事件列表
 * @version $Id$
 */
$(function() {
    var CrmEvent = Crm.Event;
    var accountId = Ibos.app.g("accountId");
    var formhash = Ibos.app.g('formhash');
    var asoContact = new Crm.AsoContactDialog("#evt_publish .o-evt-man", {
        data: function(callback) {
            Crm.Contact.op.get({
                cid: accountId,
                formhash: formhash,
                action: "eventrelated"
            }, callback);
        }
    });
    var asoOpp = new Crm.AsoOppDialog("#evt_publish .o-evt-funnel", {
        data: function(callback) {
            Crm.Opportunity.op.get({
                cid: accountId
            }, callback);
        }
    });
    var asoDatetime = new Crm.AsoDatetimeDialog("#evt_publish .o-evt-clock", {
        data: function(callback) {
            $.get(Ibos.app.url('crm/event/datetime'), callback);
        }
    });

    var asoTag = new Crm.AsoTagMenu("#evt_publish .o-evt-memo", "#evt_tag_menu");

    new Crm.EvtPublish("#evt_publish_tt", "#evt_publish_btn", function(evt, content, dom) {
        var _this = this,
            postData = [{
                name: "cid",
                value: accountId
            }, {
                name: "formhash",
                value: formhash
            }, {
                name: "content",
                value: content
            }, {
                name: "contactid",
                value: asoContact.getVal()
            }, {
                name: "oid",
                value: asoOpp.getVal()
            }];
        postData = postData.concat(asoDatetime.getVal(), asoTag.getData())
        dom.btn.button("loading");
        CrmEvent.op.addRecord(postData, function(res) {
            dom.btn.button("reset");
            if (res.isSuccess) {
                asoContact.reset();
                asoOpp.reset();
                asoDatetime.reset();
                asoTag.reset();
                _this.reset();
            }
        });
    });

    Ibos.evt.add({
        "removeVwRecord": function(param, elem) {
            CrmEvent.op.removeRecord(param.id);
        }
    });

    var recordList = new Ibos.CmList("#evt_vw_list", {
        tpl: "tpl_vwevt_item",
        animate: true
    });

    $(CrmEvent).on({
        "crmrecordadd": function(evt, evtData) {
            var res = evtData.res;
            res.isSuccess && recordList.addItem({
                data: res.data
            }, true);
        },
        "crmrecordupdate": function(evt, evtData) {
            var res = evtData.res;
            res.isSuccess && recordList.updateItem(res.data.id, {
                data: res.data
            });
        },
        "crmrecordremove": function(evt, evtData) {
            evtData.res.isSuccess && recordList.removeItem(evtData.ids);
        }
    });

    Crm.Query.init("#crm_filter_dropdown");
    $(document).on("advquery", function(evt, evtData) {
        window.location.href = Ibos.app.url('crm/client/detail', {
            op: 'event',
            id: accountId,
            'search[value]': $.trim($("#mn_search").val()),
            'search[regex]': false
        }) + "&" + evtData.param;
    });
    $("#mn_search").search(function(value) {
        $("#crm_filter_dropdown").trigger("hide.bs.dropdown", {
            value: value
        });
    });
});
