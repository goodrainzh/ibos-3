/**
 * CRM 客户列表
 * @author inaki
 * @version $Id$
 */
$(function() {
    var Account = Crm.Account;

    // 批量操作入口
    Account.multiAccess = function(callback) {
        var accountIds = U.getCheckedValue("account[]", "#account_table");
        if (!accountIds) {
            Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", "warning");
        } else {
            callback && callback(accountIds);
        }
    };
    
    // 初始化表格控件
    var accountTable = $("#account_table").DataTable($.extend(true, {}, Ibos.settings.dataTable, {
        // --- Data
        deferLoading: 0, // 每个文件加上这一行
        ajax: Ibos.app.url('crm/client/index', Ibos.app.g('seaid') ? {seaid: Ibos.app.g('seaid')} : {}),
        language: {
            zeroRecords: '<div class="tac"><img src="static/image/common/no-info.png"></div>'
        },
        // --- Callback
        initComplete: function() {
            // Fixed: IE8下表格初始化后需要再次初始化 checkbox，否则触发不了change事件
            $(this).find('[data-name]').label();
        },
        rowCallback: function(row, data) {
            var $row = $(row);
            $row.find("label input[type='checkbox']").label();
            // 客户跟进记录详情
            var $memo = $row.find(".crm-memo"), param;
            if ($memo.length) {
                param = Ibos.app.getEvtParams($memo[0]);
                // 通过 Ajax 获取
                $memo.ajaxPopover(Ibos.app.url('crm/event/ajaxload', param), false, {
                    template: '<div class="popover popover-w crm-memo-popover"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>',
                    trigger: "hover",
                    html: true,
                    delay: {
                        show: 200,
                        hide: 200
                    }
                });
            }
            // 标签详情
            var $tag = $row.find('[data-node-type="crmTag"]'), content;
            if ($tag.length) {
                content = $tag.next().html();
                $tag.popover({
                    template: '<div class="popover popover-w crm-tag-popover"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>',
                    trigger: "hover",
                    html: true,
                    content: content,
                    delay: {
                        hide: 200
                    }
                });
            }
        },
        order: [1, "desc"], // ID 倒序
        columns: [
            // 复选框
            {
                "data": "",
                "orderable": false,
                "className": "dt-checkbox-td",
                "render": function(data, type, row) {
                    return '<label class="checkbox mbz"><input type="checkbox" name="account[]" value="' + row.id + '"/></label>';
                }
            },
            // ID（隐藏）
            {
                "data": "cid",
                "visible": false,
                "render": function(data, type, row) {
                    return row.id;
                }
            },
            // 标签
            {
                "data": "tags",
                "orderable": false,
                "render": function(data, type, row) {
                    var _tpl = '<div class="crm-tag-group<%= row.tags.length %>" data-node-type="crmTag">' +
                            '<% for (var i = 0; i < row.tags.length; i++) { %>' +
                            '<i class="crm-tag<%= i + 1 %>" style="background-color: <%= row.tags[i].color %>;"></i>' +
                            '<% } %>' +
                            '</div>' +
                            '<div class="hide">' +
                            '<ul class="crm-tag-list">' +
                            '<% for (var i = 0; i < row.tags.length; i++) { %>' +
                            '<li>' +
                            '<i style="background-color: <%= row.tags[i].color %>;"></i>' +
                            '<%= row.tags[i].name %>' +
                            '</li>' +
                            '<% } %>' +
                            '</ul>' +
                            '</div>';

                    return row.tags && row.tags.length ? $.template(_tpl, {row: row}) : "";
                }
            },
            // 客户名称
            {
                "data": "fullname",
                "render": function(data, type, row) {
                    var _tpl = '<div>' +
                            '<a href="<%= row.homeUrl %>" class="xcm"><%= row.name %></a> ' +
                            '</div>' +
                            '<div class="cps-info fss">' +
                            '<% if(row.contact.name) { %> <span><i class="o16 om-user-simple"></i> <%= row.contact.name %></span> <% } %>' +
                            '<% if(row.contact.tel) { %>' +
                            '<a href="javascript:;" class="ilsep" data-action="phoneTo" data-param="{&quot;number&quot;: &quot;<%= row.contact.tel.value %>&quot;}" title="<%= U.lang(\"CRM.PHONE_TO\")%>">' +
                            '<i class="o16 om-phone-simple"></i> <%= row.contact.tel.value %>' +
                            '</a>' +
                            '<% } %>' +
                            '<% if(row.email) { %>' +
                            '<a href="#<%= row.email %>" class="ilsep" title="<%= U.lang(\"CRM.SEND_MAIL\")%>">' +
                            '<i class="o16 om-email-simple"></i> <%= row.email %>' +
                            '</a>' +
                            '<% } %>' +
                            '</div>';

                    return $.template(_tpl, {row: row});
                }
            },
            // 归属用户
            {
                "data": Ibos.app.g("seaid") ? "lastuid" : "uid",
                "render": function(data, type, row) {
                    var _tpl = '<a href="<%= row.user.spaceUrl %>" class="avatar-circle avatar-circle-small">' +
                            '<img src="<%= row.user.avt %>" />' +
                            '</a> ' +
                            '<span class="fss"><%= row.user.name %></span>';
                    return row.user ? $.template(_tpl, {row: row}) : '';
                }
            },
            // 近期事件
            {
                "data": "latestevent",
                "render": function(data, type, row) {
                    var _tpl = '<div class="crm-memo <%= row.event.color ? \"\" : \"crm-memo-default\" %>" style="background-color: <%= row.event.color %>" data-param="{&quot;key&quot;: &quot;<%= row.id %>&quot;, &quot;id&quot;: &quot;<%= row.latestevent %>&quot;}">' +
                            '<i class="crm-memo-parts" style="background-color: <%= row.event.color %>"></i><%= row.event.name %>' +
                            '</div>';

                    return row.event ? $.template(_tpl, {row: row}) : "";
                }
            },
            // 最近联系时间
            {
                "data": "updatetime",
                "render": function(data, type, row) {
                    return $.template("tpl_cell_contact_time", {row: row});
                }
            }
        ]
    }));

    // 搜索功能
    $("#account_search").search(function(value) {
        accountTable.search(value).draw();
    });

    // 操作菜单项
    $("#account_table").on("change", "[name='account[]']", function(evt) {
        var $checked = U.getChecked("account[]", evt.delegateTarget);
        $("#account_operation_menu").find("[role='singleOperation']").toggle($checked.length <= 1);
    });

    // 高级查询，替换表格数据 ajax 地址
    $(document).on("advquery", function(evt, evtData) {
        var url = Ibos.app.url('crm/client/index', Ibos.app.g('seaid') ? {seaid: Ibos.app.g('seaid')} : {});
        if( evtData ){
            url += '&' + evtData.param;
        }
        accountTable.ajax.url(url).load();
    });
    
    if( !$("#crm_filter_dropdown").length ){
        $(document).trigger("advquery");
    }
    Crm.Query.init("#crm_filter_dropdown");
    Crm.Query.replayCondition(Ibos.app.g('query-condition'));
    $(Account).on({
        // 新建用户
        // "accountadd": function(evt, evtData) {
        //     if (evtData.res.isSuccess) {
        //         accountTable.draw();
        //     }
        // },
        // 删除客户
        "accountremove": function(evt, evtData) {
            if (evtData.res.isSuccess) {
                accountTable.draw(false);
            }
        }
    });
    Ibos.evt.add({
        // 搜索选中客户相关信息
        "searchSelectedAccount": function() {
            // 获取选中项的 ID
            var accId = U.getCheckedValue("account[]", "#account_table"), accName;
            if (!accId) {
                Ui.tip("@SELECT_ONE_ITEM", "warning");
                return false;
            }
            // 根据 ID 从列表数据中找对应的客户名
            accName = $.grep(accountTable.data(), function(d) {
                return d.id == accId;
            })[0].name;
            Account.baiduSearch(accName);
        },
        // 共享客户信息
        "shareAccount": function() {
            Account.multiAccess(function(ids) {
                Crm.showShareDialog(Ibos.app.url('crm/client/share', {ids: ids}), function(res) {
                    if (res.isSuccess) {
                        this.close();
                    }
                });
            });
        },
        // 分配客户信息
        "assignAccount": function() {
            Account.multiAccess(function(ids) {
                Crm.showAssignDialog(Ibos.app.url('crm/client/assign', {ids: ids}), function(res) {
                    if (res.isSuccess) {
                        this.close();
                        accountTable.draw(false);
                    }
                });
            });
        },
        // 发送邮件
        "sendMail": function() {
            if (Ibos.app.g('externalmail') != 1) {
                Ui.tip("@CRM.NOT_OPEN_EMAIL_EXTERNAL", "warning");
                return false;
            }
            Account.multiAccess(function(ids) {
                window.location.href = Ibos.app.url('crm/client/sendmail', {ids: ids});
            });
        },
        // 提取邮箱地址
        "extractMail": function() {
            Account.multiAccess(function(ids) {
                window.location.href = Ibos.app.url('crm/client/exportMail', {ids: ids});
            });
        },
        // 移动到公海
        "moveToHighseas": function() {
            Account.multiAccess(function(id) {
                Account.showHighseasPoolDialog(function(highseasId) {
                    var dialog = this;
                    if (!highseasId) {
                        Ui.tip("@CRM.PLEASE_SELECT_TARGET_HIGHSEAS", "warning");
                        return false;
                    }
                    Account.op.moveToHighseas({id: id, highseasId: highseasId, formhash: Ibos.app.g('formhash')}, function(res) {
                        if (res.isSuccess) {
                            // 成功提示
                            Ui.dialog({
                                title: false,
                                cancel: false,
                                content: "<div class='highseas-tip'></div>",
                                skin: "highseas-tip-dialog"
                            }).time(2);
                            accountTable.draw(false);
                            dialog.close();
                        } else {
                            Ui.tip(res.msg, "danger");
                        }
                    });
                });
            });
        },
        // 批量删除客户
        "removeAccounts": function() {
            Account.multiAccess(function(ids) {
                Ui.confirm(U.lang("CRM.REMOVE_ACCOUNT_CONFIRM"), function() {
                    Account.op.remove(ids);
                });
            });
        },
        // 领取客户
        "pullAccount": function(param) {
            Account.op.pull(param.id, function(res) {
                if (res.isSuccess) {
                    Ui.tip("@OPERATION_SUCCESS");
                    accountTable.draw(false);
                } else {
                    Ui.tip(res.msg, "danger");
                }
            });
        },
        // 批量领取客户
        "pullAccounts": function() {
            Account.multiAccess(function(ids) {
                Account.op.pull(ids, function(res) {
                    if (res.isSuccess) {
                        Ui.tip("@OPERATION_SUCCESS");
                        accountTable.draw(false);
                    } else {
                        Ui.tip(res.msg, "danger");
                    }
                });
            });
        }
    });
});

