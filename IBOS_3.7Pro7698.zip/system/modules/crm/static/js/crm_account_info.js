/**
 * Crm 客户信息
 * @version $Id$
 */
$(function() {
	// 机会共享
	$("#account_regdate_datepicker").datepicker();
	// 初始化归属用户
	var initUid = $("#belong_input").val();
	var belongModel = new Crm.BelongModel(initUid);
	var belongView = new Crm.BelongView(belongModel, {
		display: "#belong_info",
		button: "#update_belong_btn",
		input: "#belong_input"
	});
	var belongController = new Crm.BelongController(belongModel, belongView);
	belongController.setUid(initUid);
	// 初始化快照功能
	if (Crm.SnapModel) {
		var snapModel = new Crm.SnapModel({url: Ibos.app.url("crm/client/snap")});
		var snapView = new Crm.SnapView(snapModel, {
			content: "#account_snap_body",
			select: "#account_snap_id",
			prevBtn: "#account_snap_prev",
			nextBtn: "#account_snap_next"
		});
		var snapCtrl = new Crm.SnapController(snapModel, snapView);
		// 恢复快照
		$("#account_snap_restore").on("click", function() {
			var id = snapModel.getVal();
			Crm.Account.op.restoreSnap({snapid: id}, function(res) {
				if (res.isSuccess) {
					Ui.closeDialog("d_account_info");
					Ui.tip("@CRM.RESTORE_SNAP_SUCCESS");
					window.location.reload();
				} else {
					Ui.closeDialog("d_account_info");
					Ui.tip("@CRM.RESTORE_SNAP_FAIL", "danger");
				}
			});
		});
	}
	// 初始化表单验证
	var _initFormValidator = function() {
		// 延时执行以修正提示定位
		setTimeout(function() {
			$.formValidator.initConfig({
				formID: "account_info_form",
				theme: "",
				validatorGroup: "accountInfo"
			});
			// 机会主题不能为空
			$("#account_fullname").formValidator({
				onFocus: U.lang("CRM.INPUT_ACCOUNT_FULLNAME"),
				validatorGroup: "accountInfo"
			}).regexValidator({
				regExp: "notempty",
				dataType: "enum",
				onError: U.lang("CRM.INPUT_ACCOUNT_FULLNAME")
			});
			// 客户邮编格式验证
			$("#account_zipcode").formValidator({
				onFocus: U.lang("CRM.INPUT_ACCOUNT_ZIPCODE"),
				empty: true,
				validatorGroup: "accountInfo"
			}).regexValidator({
				regExp: "zipcode",
				dataType: "enum",
				onError: U.lang("CRM.SURE_CORRECT_ZIPCODE")
			});

			// 客户邮件格式验证
			$("#account_email").formValidator({
				onFocus: U.lang("CRM.INPUT_LEAD_EMAIL"),
				empty: true,
				validatorGroup: "accountInfo"
			}).regexValidator({
				regExp: "email",
				dataType: "enum",
				onError: U.lang("CRM.SURE_CORRECT_EMAIL")
			});
			// 客户网址格式验证
			$("#account_website").formValidator({
				onFocus: U.lang("CRM.INPUT_LEAD_WEBSITE"),
				empty: true,
				validatorGroup: "accountInfo"
			}).regexValidator({
				regExp: "url",
				dataType: "enum",
				onError: U.lang("CRM.SURE_CORRECT_WEBSITE")
			});
		}, 0);
	};
	Crm.loadFormValidator(_initFormValidator);

	Ibos.evt.add({
		// 关联联系人
		contactContact: function(param, elem){
			var type = param.action;
				Crm.Contact.select(param, function(contactIds) {
					Crm.Contact.op.attach(type, $.extend({
						contactid: contactIds,
						id: Ibos.app.g('id')
					}, param),
					function(res) {
						if (res.isSuccess) {
							Ui.tip("@OPERATION_SUCCESS");
						} else {
							Ui.tip(res.msg, "danger");
						}
					});
				});
		}
	});
});



