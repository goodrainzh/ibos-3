/**
 * Crm 客户机会
 * @version  $Id$
 * @author   inaki
 */
$(function() {
	var OppList = {
		$container: $("#acc_opp_list"),
		tpl: "tpl_acc_opp",

		init: function(){
			var _this = this;
			$(Crm.Opportunity).on({
				"oppadd": function(evt, evtData){
					var res = evtData.res;
					res.isSuccess && _this.add(res.data);
				},
				"oppupdate": function(evt, evtData){
					var res = evtData.res;
					res.isSuccess && _this.update(res.data);
				}
			});
		},

		add: function(data){
			// 清除空值
			var $empty = this.$container.find(".empty-opp-box");
			if($empty.length){
				$empty.remove();
			}
			this.$container.prev("div").show();
			$('[role="OppQuickAddBtn"]').show();
			data.conds = data.conds || [];
			data.progressName = data.progressName.slice(2);
			return $.tmpl(this.tpl, data).prependTo(this.$container);
		},

		update: function(data){
			if(data && data.id) {
				$.tmpl(this.tpl, data).replaceAll(this.$container.children("[data-id='" + data.id + "']"));
			}
		}
	}
	OppList.init();
});
