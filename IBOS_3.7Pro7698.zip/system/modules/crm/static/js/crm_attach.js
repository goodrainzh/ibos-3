/**
 * CRM 客户附件
 * @author inaki
 * @version $Id$
 */

$(function() {
	var CrmAttach = {
		op: {
			removeAttach: function(param, callback) {
				if (param.id) {
					param.op = 'remove';
					$.post(Ibos.app.url(Ibos.app.g('attachRoute')), param, function(res) {
						callback && callback(res);
					}, "json");
				}
			}
		},
		// 批量操作入口
		multiAccess: function(callback) {
			var aids = U.getCheckedValue("attach[]");
			if (!aids) {
				Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", "warning");
			} else {
				callback && callback(aids);
			}
		},
		// 获取字符串的长度
		strlength: function(str){
			var temp,
				icount = 0,
				pattern = /[^\x00-\xff]/ ;
			for(var i=0; i<str.length; i++){
				temp = str.substr(i, 1);
				if( pattern.exec(temp) == null ){
					icount += 1;
				}else{
					icount += 2;
				}
			}
			return icount;
		}
	};

	var canEditOffice =  Ibos.app.g('canEdit');

	// 初始化表格控件
	var attachTable = $("#attach_table").DataTable($.extend(true, {}, Ibos.settings.dataTable, {
		// --- Data
		ajax: Ibos.app.url(Ibos.app.g('attachRoute'), {op: 'lists', id: Ibos.app.g('id')}),
        language: {
            zeroRecords: '<div class="tac"><img src="static/image/common/no-info.png"></div>'
        },
		// --- Callback
		initComplete: function() {
			// Fixed: IE8下表格初始化后需要再次初始化 checkbox，否则触发不了change事件
			$(this).find('[data-name]').label();
		},
		rowCallback: function(row, data) {
			$(row).find("label input[type='checkbox']").label();
		},
		drawCallback: function() {
			renderAttInfo();
		},
		order: [1, "desc"], // ID 倒序
		// --- Column
		columns: [
			// 复选框
			{
				"data": "",
				"orderable": false,
				"className": "dt-checkbox-td",
				"render": function(data, type, row) {
					return '<label class="checkbox mbz"><input type="checkbox" name="attach[]" value="' + row.id + '"/></label>';
				}
			},
			// ID（隐藏）
			{
				"data": "",
				"visible": false,
				"render": function(data, type, row) {
					return row.id;
				}
			},
			// 格式
			{
				"data": "aicon",
				"render": function(data, type, row) {
					return '<img src="' + row.icon + '" alt="" width="32" height="32">';
				}
			},
			// 名称
			{
				"data": "aname",
				"render": function(data, type, row) {
					return '<a href="javascript:;" class="xcm" title="'+ row.name +'">' + row.name + '</a>';
				}
			},
			// 归属用户
			{
				"data": "auid",
				"render": function(data, type, row) {
					var _tpl = '<a href="<%= row.user.spaceUrl %>" class="avatar-circle avatar-circle-small">' +
							'<img src="<%= row.user.avt %>" />' +
							'</a> ' +
							'<span class="fss"><%= row.user.name %></span>';

					return $.template(_tpl, {row: row});
				}
			},
			// 模块位置
			{
				"data": "asubmod",
				"render": function(data, type, row) {
					return '<span class="fss">' + row.submod + "</span>";
				}
			},
			// 文件大小
			{
				"data": "afilesize",
				"render": function(data, type, row) {
					return '<span class="fss">' + row.formatedSize + "</span>";
				}
			},
			// 上传时间
			{
				"data": "aupdatetime",
				"render": function(data, type, row) {
					var _tpl = '<span class="crm-att-datetime fss"><%= row.uploadTime %></span>' +
							'<div class="crm-att-op">' +
							'<a href="<%= row.url %>" target="_blank" class="o-download" title="<%= U.lang("DOWNLOAD") %>"></a> ' +
							'<a href="javascript:;" data-param=\'{"href": "<%= row.officereadurl %>"}\' data-action="viewOfficeFile" class="o-view"></a>' +
							(row.officeediturl && canEditOffice ? '<a href="javascript:;" data-param=\'{"href": "<%= row.officeediturl %>"}\' data-action="editOfficeFile" class="o-edit mlm"></a>' : '') +
							'<a href="javascript:;" class="o-trash mlm" title="<%= U.lang("DELETE") %>" data-action="removeAttach" data-param="{&quot;id&quot;: <%= row.id %>}"></a>' +
							'</div>';

					return $.template(_tpl, {row: row});
				}
			}
		]
	}));

	// 渲染附件信息视图
	var renderAttInfo = function(data) {
		var data = attachTable.data(),
				checked = U.getCheckedValue("attach[]", "#attach_table").split(","),
				selectedData = $.grep(data, function(d) {
					return checked.length ? $.inArray(d.id, checked) !== -1 : false;
				});
		var text = "";
		// 选中单个文件和选中多个文件，信息内容不一样
		if (selectedData.length === 1) {
			var selectName = selectedData[0].name,
				strlength = CrmAttach.strlength(selectName);
			if(strlength > 22){
				selectName = selectName.substr(0,6) + "..." + selectName.slice(-10);
			}

			text = $.template(U.lang("CRM.SINGLE_ATTACH_INFO_TPL"), {
				name: selectName,
				size: U.formatFileSize(selectedData[0].size),
				time: selectedData[0].uploadTime
			});
		} else if (selectedData.length > 1) {
			var totalSize = 0;
			$.each(selectedData, function(i, d) {
				totalSize += +d.size;
			});
			text = $.template(U.lang("CRM.MULTI_ATTACH_INFO_TPL"), {
				count: selectedData.length,
				size: U.formatFileSize(totalSize)
			});
		}
		$(".crm-att-info").html(text);
	};

	$(document).on("change", "[name='attach[]']", function() {
		renderAttInfo();
	});

	Ibos.evt.add({
		// 移除附件
		"removeAttach": function(param) {
			Ui.confirm(U.lang("CRM.REMOVE_ATTACH_CONFIRM"), function() {
				CrmAttach.op.removeAttach(param, function(res) {
					if (res.isSuccess) {
						Ui.tip("@CRM.REMOVE_ATTACH_SUCCESS");
						attachTable.draw(false);
					}
				});
			});
		},
		// 批量移除附件
		"removeAttachs": function() {
			CrmAttach.multiAccess(function(ids) {
				Ui.confirm(U.lang("CRM.REMOVE_ATTACHS_CONFIRM"), function() {
					CrmAttach.op.removeAttach({id: ids}, function(res) {
						if (res.isSuccess) {
							Ui.tip("@CRM.REMOVE_ATTACH_SUCCESS");
							attachTable.draw(false);
						}
					});
				});
			});
		},
		// 批量下载附件
		"downloadAttachs": function() {
			CrmAttach.multiAccess(function(ids) {
				window.location.href = Ibos.app.url(Ibos.app.g('attachRoute'), {op: 'batchdownload', id: ids});
			});
		},
		// 上传附件
		uploadAttachs: function(){
			Ibos.uploadDialog({
				upload_url: Ibos.app.url(Ibos.app.g('attachRoute')),
				post_params: {id: U.getUrlParam().id},
				custom_settings: {
					success: function(file, res) {
						attachTable.draw(false);
					}
				}
			});
		}
	});
});
