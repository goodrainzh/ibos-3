/**
 * Crm 权限设置详细页
 * @author  inaki
 * @version $Id$
 */

$(function(){

	// 权限等级
	$("[data-toggle='level']").each(function(){
		var $input = $(this),
			levelIns,
			tooltipIns;

		// 初始化权限等级并缓存其实例
		levelIns = $input.privilegeLevel().data("privilegeLevel");

		// 初始化工具提示并缓存其实例
		// @Todo: IE8 下tooltip首次出现的位置有点偏差，需要调整
		tooltipIns = levelIns.$anchor.tooltip({ title: U.lang("CRM.AUTH_LEVEL_" + levelIns.value)}).data("tooltip");
		// 权限等级变化时更新工具提示的文字
		$input.on("change", function(){
			tooltipIns.options.title = U.lang("CRM.AUTH_LEVEL_" + this.value);
			tooltipIns.show();
		});
	});

	// 岗位客户人员上限必须为有效数字
	$("#pos_account_max").on("change", function(){
		if(!$.trim(this.value)) {
			return;
		}
		if(!U.isPositiveInt(this.value)) {
			this.value = Ibos.string.toPositiveInt(this.value);
		}
	});

	// 水平方向
	var $table = $(".table");
	$(".horizontal").each(function(index, item){
		$(item).on("click", function(){
			var $tr = $table.find("tbody tr").eq(index);
			$tr.each(function(i, item){
				var $td = $(item).find("td"),
					$a = $td.find("a");

				$a.trigger("click.level");
				$(".tooltip").remove();
			});
		});
	});

	// 垂直方向
	$(".vertical").each(function(index, item){
		$(item).on("click", function(){
			var $tr = $table.find("tbody tr");
			$tr.each(function(i, item){
				var $td = $(item).find("td").eq( (index+1) ),
					$a = $td.find("a");

				$a.trigger("click.level");
				$(".tooltip").remove();
			});
		});
	});
});