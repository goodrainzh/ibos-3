/**
 * CRM 通用 JS
 * @version $Id$
 */

var Crm = {
    op: {
        // 保存目标设置
        // saveTarget: function(data, callback){
        // 	console.log("saveTarget: ", data);

        // 	$.post("?", data, function(res){
        // 		res = { isSuccess: true };
        // 		callback && callback(res);
        // 	}/*, "json"*/);
        // },

        // 保存共享信息
        saveShare: function(url, data, callback) {
            if (data && data.length) {
                $.post(url, data, function(res) {
                    callback && callback(res, data);
                }, "json");
            }
        },
        // 保存分配信息
        saveAssign: function(url, data, callback) {
            if (data && data.length) {
                $.post(url, data, function(res) {
                    callback && callback(res, data);
                }, "json");
            }
        }
    },
    // 查询配置对话框
    showQueryDialog: function(param) {
        Ui.closeDialog("d_query_dialog");
        Ui.ajaxDialog(Ibos.app.url('crm/query/editgroup', param), {
            id: "d_query_dialog",
            title: U.lang("CRM.SETUP_QUERY"),
            lock: true,
            width: 470,
            padding: 0,
            ok: function() {
                window.location.reload();
            },
            cancel: true
        });
    },
    // 条件配置对话框
    showCondDialog: function(url, param, ok) {
        param = param || {};
        Ui.closeDialog("d_cond_dialog");
        Ui.ajaxDialog(url, {
            id: "d_cond_dialog",
            title: U.lang("CRM.ADD_QUERY_CONDITION"),
            padding: 0,
            lock: true,
            ok: function() {
                var dialog = this,
                    $form = this.DOM.content.find("form"),
                    name = $form[0].name.value,
                    cond;
                // 检查名称
                if ($.trim(name) === "") {
                    Ui.tip("@CRM.INPUT_COND_NAME", "warning");
                    return false;
                }
                // 组合条件语句
                cond = $("#cond_list li").map(function() {
                    return $(this).data("value");
                }).get().join("\n");
                // 组合条件语句
                condtext = $("#cond_list li").map(function() {
                    return $(this).text();
                }).get().join("\n");
                if ($.trim(cond) === "") {
                    Ui.tip("@CRM.INPUT_COND_SQL", "warning");
                    return false;
                }
                ok && ok.call(dialog, {
                    name: name,
                    condformula: cond,
                    condtext: condtext
                });
                return false;
            },
            cancel: true
        });
    },
    // 读取通用共享页
    loadShare: function(container, url, param, callback) {
        var $container = $(container);
        if ($container.length) {
            setTimeout(function() {
                $container.waiting(null, "small");
            }, 0);
        }
        $.get(url, param, function(res) {
            $container.html(res).waiting(false);
        }).done(callback);
    },
    // 共享对话框
    showShareDialog: function(url, ok) {
        var _this = this;
        Ui.ajaxDialog(url, {
            id: "d_share",
            title: U.lang("CRM.SHARE"),
            padding: 0,
            init: function() {
                this._reset();
            },
            lock: true,
            ok: function() {
                var dialog = this,
                    $form = this.DOM.content.find("form"),
                    formData = $form.serializeArray();
                _this.op.saveShare(url, formData, function(res) {
                    ok && ok.call(dialog, res);
                });
                return false;
            },
            okVal: U.lang("SAVE"),
            cancel: true
        });
    },
    // 分配对话框
    showAssignDialog: function(url, ok) {
        var _this = this;
        Ui.ajaxDialog(url, {
            id: "d_assign",
            title: U.lang("CRM.ASSIGN"),
            width: 420,
            lock: true,
            okVal: U.lang("SAVE"),
            cancel: true,
            init: function() {
                $("#assign_user").userSelect({
                    type: "user",
                    data: Ibos.data.get("user"),
                    box: $("#assign_user_box"),
                    maximumSelectionSize: 1
                });
                this.DOM.content.find(".checkbox input").label();
            },
            ok: function() {
                var dialog = this,
                    $form = this.DOM.content.find("form"),
                    formData = $form.serializeArray();
                // 分配目标用户不能为空
                // TODO::同时检查选中用户不为自己 @banyan
                if ($.trim($form[0].assignuser.value) === "") {
                    Ui.tip("@CRM.SELECT_ASSIGN_USER", "warning");
                    return false;
                }
                _this.op.saveAssign(url, formData, function(res) {
                    ok && ok.call(dialog, res);
                });
                return false;
            }
        });
    },
    // 加载 formvalidator 相关的文件
    loadFormValidator: function(callback) {
        if ($.formValidator) {
            callback && callback();
        } else {
            var path = Ibos.app.getStaticUrl("/js/lib/formValidator");
            U.loadFile(document, {
                tag: "link",
                id: "css_formvalidator",
                rel: "stylesheet",
                href: path + "/themes/Ibos/style/style.css"
            });
            $.getScript(path + "/formValidator.packaged.js")
                .done(function() {
                    $.getScript(path + "/themes/Ibos/js/theme.js")
                        .done(callback);
                });
        }
    },
    // 配置目标
    showTarget: function(param, ok) {
        param = param || {};
        Ui.ajaxDialog(Ibos.app.url('crm/target/index', param), {
            id: "d_crm_target",
            title: U.lang("CRM.SETUP_TARGET"),
            padding: 0,
            width: 780,
            ok: ok || true,
            okVal: U.lang("SAVE"),
            cancel: true,
            lock: true
        });
    }
};


/* 通用卡片选择框（联系人、合同、机会、客户） */
(function() {
    var BnCardList = function(ct, settings) {
        var $ct = $(ct);
        var _this = this;
        this.selected = settings.selected || [];

        Ibos.app.s({
            bnCards: $.unique($.merge((Ibos.app.g("bnCards") || []), settings.selected || []))
        });

        if (!$ct.length) {
            return false;
        }

        settings = $.extend({
            tpl: ""
        }, settings);

        this.render = function(data) {
            var resHtml = "";
            if (data && data.length) {
                $.each(data, function(i, d) {
                    resHtml += $.template(settings.tpl, d);
                });
                $ct.html(resHtml);

                $('[data-node-type="bncard"]').each(function(i, elem) {
                    if ($.inArray($.attr(elem, "data-id"), Ibos.app.g("bnCards")) !== -1) {
                        $(elem).addClass("active");
                    }
                });
                _this.countChange();
            } else {
                $ct.empty();
            }
        };

        this.countChange = function() {
            $(settings.count).html($.template(settings.countTpl, {
                count: Ibos.app.g("bnCards").length
            }));
        };

        this.select = function(id) {
            $ct.find("[data-node-type='bncard'][data-id='" + id + "']").addClass("active");
            this.selected.push(id);
            $(this).trigger("bncardselect", {
                id: id
            });
            Ibos.app.s({
                bnCards: $.unique($.merge((Ibos.app.g("bnCards") || []), [id]))
            });
        };

        this.unselect = function(id) {
            $ct.find("[data-node-type='bncard'][data-id='" + id + "']").removeClass("active");
            this.selected.splice($.inArray(id, this.selected), 1);
            $(this).trigger("bncardunselect", {
                id: id
            });
            var bnCards = Ibos.app.g("bnCards");
            bnCards.splice($.inArray(id, bnCards), 1);
            Ibos.app.s({
                bnCards: bnCards
            });
        };

        this.getSelected = function() {
            return this.selected;
        };

        $ct.on("click", "[data-node-type='bncard']", function() {
            if ($(this).hasClass("active")) {
                _this.unselect($.attr(this, "data-id"));
            } else {
                _this.select($.attr(this, "data-id"));
            }
            _this.countChange();
        });
    };

    var BnCardBox = function(elems, options) {
        elems = elems || {};
        options = $.extend({}, this.constructor.defaults, options);
        this.$container = $(elems.container);
        var _this = this,
            isLoad = false,
            data = null,
            selected = null,
            count = 0;

        getData();
        // 初始化列表
        if (!_this.$container.length) {
            $.error("Crm.BnCardBox: 未找到节点 elems.container");
        } else {
            _this.list = new BnCardList(_this.$container, {
                tpl: options.tpl,
                selected: selected,
                countTpl: options.countTpl,
                count: elems.count
            });
        }
        // 初始化页码
        this.$page = $(elems.page);
        if (!this.$page.length) {
            $.error("Crm.BnCardBox: 未找到节点 elems.page");
        } else {
            _initPagination(this.$page);
        }

        // 初始化搜索
        this.$search = $(elems.search);
        if (this.$search.length) {
            $(elems.search).search(function() {
                // results = options.keywordFilter(this.value, data);
                // if (_this.$page.length) {
                // 	_initPagination(_this.$page, results.length);
                // }
                isLoad = false;
                getData(0, $(elems.search).val());
                _initPagination(_this.$page);
            });
        }

        function _initPagination($page) {
            var _settings = {
                items_per_page: 9,
                num_display_entries: 5,
                prev_text: false,
                next_text: false,
                renderer: "ibosRenderer",
                allow_jump: true,
                callback: function(page, elem) {
                    if (isLoad) {
                        getData(page, $(elems.search).val());
                    }
                    _this.list.render(data);
                    isLoad = true;
                    $.ajaxSetup({
                        async: true
                    });
                }
            };

            if (!$.fn.pagination) {
                $.getScript(Ibos.app.getStaticUrl("/js/lib/jquery.pagination.js"))
                    .done(function() {
                        $page.pagination(count, _settings);
                    });
            } else {
                $page.pagination(count, _settings);
            }
        }

        function getData(page, value) {
            $.ajaxSetup({
                async: false
            });
            var param = $.extend(options.params, {
                start: (page || 0) * 9,
                length: 9,
                "search[value]": (value || ""),
                "search[regex]": false
            });
            options.op(param, function(res) {
                data = res.data;
                count = res.count;
                selected = res.contactidS && res.contactidS.split(',');
                Ibos.app.s("crmAccounts", options.accountsFilter(data));
            });
        }

        // $(this.list).on("bncardselect bncardunselect", function(evt, data) {
        // 	// var selected = _this.list.getSelected();
        // 	var selected = Ibos.app.g("bnCards");
        // 	$(elems.count).html($.template(options.countTpl, {count: selected.length}));
        // $(_this).trigger(evt.type, data);
        // });
    };

    BnCardBox.defaults = {
        // // 搜索过滤器
        // keywordFilter: function(keyword, source) {
        // 	keyword = $.trim(keyword);
        // 	var rlt;
        // 	if (keyword === "") {
        // 		rlt = [].concat(source);
        // 	} else {
        // 		rlt = $.grep(source, function(r) {
        // 			return Ibos.matchSpell(keyword, r.name);
        // 		});
        // 	}
        // 	return rlt;
        // },
        // // 翻页过滤器
        // pageFilter: function(page, source) {
        // 	page = page || 0;
        // 	return source.slice(page * 9, (page + 1) * 9);
        // },
        // 复杂数组去重
        accountsFilter: function(data) {
            var accounts = Ibos.app.g("crmAccounts") || [];
            if (!accounts.length) {
                accounts = data;
            } else {
                da: for (var i = 0, len = data.length; i < len; i++) {
                    for (var j = 0, lens = accounts.length; j < lens; j++) {
                        if (data[i].id == accounts[j].id) {
                            continue da;
                        }
                    }
                    accounts.push(data[i]);
                }
            }
            return accounts;
        },
        // 列表项模板
        tpl: "",
        countTpl: "<%=count%>"
    };

    Crm.BnCardBox = BnCardBox;
})();


/* 修改归属用户相关类 */
(function() {
    // 归属用户模型类
    Crm.BelongModel = function(uid) {
        this._uid = "";
        if (uid) {
            this.updateUser(uid);
        }
    };
    // 更新归属用户信息
    Crm.BelongModel.prototype.updateUser = function(uid) {
        var userInfo = Ibos.data.getUser(uid);
        if (userInfo) {
            this._user = userInfo;
            this._uid = uid;
            $(this).trigger("update", userInfo);
        }
    };
    // 获取当前 uid
    Crm.BelongModel.prototype.getUid = function() {
        return this._uid;
    };


    // 归属用户视图类
    Crm.BelongView = function(model, elements) {
        var _this = this;
        this.model = model;
        this.elements = elements || {};
        $(model).on("update", function(evt, userInfo) {
            _this.renderDisplay(userInfo);
        });

        this.createSelectBox();
    };
    // 重新渲染视图
    Crm.BelongView.prototype.renderDisplay = function(userInfo) {
        var $display = $(this.elements.display);
        var tpl = '<a href="<%= spaceurl %>" class="avatar-circle avatar-circle-small"> ' +
            '<img src="<%= avatar %>" alt=""> ' +
            '</a> ' +
            '<strong><%= text %></strong> ' +
            '<span class="ilsep"><%= department %></span>·<span class="ilsep"><%= position %></span>';

        $display.html($.template(tpl, userInfo));
    };
    // 创建选人框
    Crm.BelongView.prototype.createSelectBox = function() {
        var _this = this;
        if (this.elements.button) {
            var boxId = $(this.elements.button).attr("id") + "_box";
            var $box = $("#" + boxId);
            var selectBox;
            // 如果没初始化过人员控件，则初始化并绑定对应事件
            if (!$box.length) {
                $box = $('<div id="' + boxId + '"></div>').hide().appendTo(document.body);
                var usableData = Ibos.app.g("accUids"),
                    data = usableData.split(","),
                    formData = Ibos.data.includes(data);
                $box.selectBox({
                    type: "user",
                    data: formData,
                    values: [this.model.getUid()],
                    maximumSelectionSize: 1
                });

                selectBox = $box.data("selectBox");
                $(selectBox).on("slbchange", function(evt, data) {
                    $(_this).trigger("updateUser", data.id);
                });
            } else {
                selectBox = $box.data("selectBox");
                selectBox.setValue(this.model.getUid());
            }

            $(this.elements.button).on("click", function() {
                var $elem = $(this);
                // 选人窗口出现后需要重新定位
                $box.zIndex(10000).show().position({
                    at: "right bottom",
                    my: "right top",
                    of: $elem
                });
            });
        }
    };

    // 归属用户控制器类
    Crm.BelongController = function(model, view) {
        var _this = this;
        this.model = model;
        this.view = view;
        $(view).on("updateUser", function(evt, uid) {
            _this.setUid(uid);
        });
    };
    Crm.BelongController.prototype.setUid = function(uid) {
        this.model.updateUser(uid);
        $(this.view.elements.input).val(uid);
    };
})();

// 通用高级查询
Crm.Query = {
    init: function(form) {
        var $form = $(form),
            tag = "",
            $userBox = $("#organization"),
            condition = U.getUrlParam().condition;

        if (!form.length) {
            return false;
        }

        // 选中标签时，更新对应的标签数总计
        $form.on("change", ".crm-ft-tag-list input[type='checkbox']", function() {
                var $list = $(this).closest(".crm-ft-tag-list"),
                    $checked = $list.find("input[type='checkbox']:checked");
                $list.siblings(".ft-nk").html(
                    $checked.length > 0 ?
                    '<strong class="label">' + $checked.length + '</strong>' :
                    '<i class="o-ol-chevron-right"></i>'
                );
            })
            // 关闭高级查询菜单且标签发生改变时，发起查询
            .on("hide.bs.dropdown", function(evt, evtData) {
                var tagParam = $form.serialize();
                evtData = evtData || {};

                if (evt.target === this && tag !== tagParam || evtData.value) {
                    tag = tagParam;
                    if ($.parseJSON($form.serializeJSON()).organization !== '') {
                        $("[role='condition'][data-condition='all']").click();
                    } else {
                        $(document).trigger("advquery", {
                            param: tag + "&condition=" + condition
                        });
                    }
                }
            })
            // 点击条件方案时
            .on("click", "[role='condition']", function(evt) {
                condition = $.attr(this, "data-condition");

                $(this).parent().addClass("active").siblings(".active").removeClass("active");

                $(evt.delegateTarget).find("[data-toggle='dropdown']").html(
                    U.entity.escape($(this).text()) + '<div class="pull-right"> <span class="o-crm-funnel"></span> <i class="caret"></i> </div>'
                );

                $(document).trigger("advquery", {
                    param: tag + "&condition=" + condition
                });
            })
            // 清空所有查询条件
            .on("click", ".crm-tag-clear", function() {
                $form.find(".crm-ft-tag-list input[type='checkbox']:checked").prop("checked", false).trigger("change");
                $form.find("[role='condition']").eq(0).click();
            });
        // 防止dropdown自动关闭
        $("ul.dropdown-menu").on("click", "[data-stop]", function(e) {
            var $el = $(e.target);
            if ($el.attr("tabindex") === '-1') {
                var $li = $el.closest("li"),
                    $ul = $li.closest("ul").find(".select2-search-choice"),
                    index = $li.index($ul),
                    val = $userBox.val().split(",");

                val.splice(index, 1);

                $userBox.data("userSelect").values = val;
                $userBox.val(val.join(","));
                $li.remove();
            }
            return false;
        });
        $("#organization_box").on("click", function(e) {
            e.stopPropagation();
        });
    },
    replayCondition: function(queryCondition) {
        $("[role='condition'][data-condition='" + queryCondition + "']").click();
    }
};

$(function() {
    Ibos.evt.add({
        // 设置高级查询
        "setupQuery": function(param) {
            Crm.showQueryDialog(param);
        },
        // 设置目标
        "setupTarget": function(param) {
            Crm.showTarget(param, function() {
                var $form = this.DOM.content.find(".tab-pane.active");
                $form.submit();
                return false;
            });
        },
        // @Todo: 短信功能未完成
        "sendMessage": function(param) {
            if (param.number) {
                console && console.log("send message to: ", param.number);
            }
        },
        // @Todo: 拨号功能未完成
        "phoneTo": function(param) {
            if (param.number) {
                console && console.log("phone to: ", param.number);
            }
        }
    });

    // 二级菜单初始化
    Ui.submenu(".crm-filter-menu");
});
