/**
 * Crm 收款模块
 * @author   inaki
 * @version  $Id$
 */

(function () {
	var Coll = {
		// 数据接口
		op: {
			add: function (data, callback) {
				if (!data || !data.length) {
					return false;
				}
				$.post(Ibos.app.url('crm/receipt/add'), data, function (res) {
					$(Coll).trigger("colladd", {data: data, res: res});
					callback && callback(res);
				}, "json");
			},
			update: function (id, data, callback) {
				if (!id || !data || !data.length) {
					return false;
				}
				data.push({name: "id", value: id});
				$.post(Ibos.app.url('crm/receipt/edit'), data, function (res) {
					$(Coll).trigger("collupdate", {data: data, res: res});
					callback && callback(res);
				}, "json");
			},
			remove: function (ids) {
				if (!ids) {
					return false;
				}
				$.post(Ibos.app.url('crm/receipt/del'), {ids: ids}, function (res) {
					$(Coll).trigger("collremove", {ids: ids, res: res});
				}, "json");
			},
			// 转化计划为记录
			transPlanToRecord: function (data, callback) {
				if (!data || !data.length) {
					return false;
				}
				$.post(Ibos.app.url('crm/receipt/edit'), data, function (res) {
					callback && callback(res);
					$(Coll).trigger("colltransplan", {data: data, res: res});
				}, "json");
			},
			// 增加收款计划
			addPlan: function (data, callback) {
				if (!data || !data.length) {
					return false;
				}
				$.post(Ibos.app.url('crm/receipt/addplan'), data, function (res) {
					callback && callback(res);
					$(Coll).trigger("collplanadd", {data: data, res: res});
				}, "json");
			},
			// 修改收款计划
			updatePlan: function (id, data, callback) {
				if (!id || !data || !data.length) {
					return false;
				}
				data.push({name: "id", value: id});
				$.post(Ibos.app.url('crm/receipt/editplan'), data, function (res) {
					callback && callback(res);
					$(Coll).trigger("collplanupdate", {data: data, res: res});
				}, "json");
			},
			// 删除收款计划
			removePlan: function (ids) {
				if (!ids) {
					return false;
				}
				$.post(Ibos.app.url('crm/receipt/removeplan'), {ids: ids}, function (res) {
					$(Coll).trigger("collplanremove", {ids: ids, res: res});
				}, "json");
			}
		},
		// 对话框接口
		_dialog: function (url, ok) {
			Ui.closeDialog("d_coll_info");
			Ui.ajaxDialog(url, {
				id: "d_coll_info",
				title: U.lang("CRM.COLLECTION_INFO"),
				lock: true,
				padding: 0,
				ok: function () {
					var formData = this.DOM.content.find("form").serializeArray();
					ok && ok.call(this, formData);
					return false;
				},
				cancel: true
			});
		},
		// 打开新建收款记录对话框
		add: function (param) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/receipt/add', param || {}), function (formData) {
				_this.op.add(formData);
			});
		},
		// 打开编辑收款记录对话框
		edit: function (param) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/receipt/edit', param || {}), function (formData) {
				_this.op.update(param.id, formData);
			});
		},
		// 打开计划转记录对话框
		transPlanToRecord: function (param) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/receipt/transplan', param || {}), function (formData) {
				_this.op.transPlanToRecord(formData);
			});
		},
		_planDialog: function (url, ok) {
			Ui.closeDialog("d_coll_plan");
			Ui.ajaxDialog(url, {
				id: "d_coll_plan",
				title: U.lang("CRM.COLLECTION_PLAN"),
				padding: 0,
				lock: true,
				ok: function () {
					var $form = this.DOM.content.find("form"), formData = $form.serializeArray(), _formatFormData = U.serializedToObject(formData);
					if ($.trim(_formatFormData.planreceivetime) === "") {
						Ui.tip("@CRM.INPUT_PLAN_COLL_TIME", "warning");
						return false;
					}
					ok && ok.call(this, formData);

					return false;
				},
				cancel: true
			});
		},
		// 打开新建收款计划对话框
		addPlan: function (param) {
			var _this = this;
			this._planDialog(Ibos.app.url('crm/receipt/addplan', param || {}), function (formData) {
				_this.op.addPlan(formData);
			}
			);
		},
		// 打开编辑收款计划对话框
		editPlan: function (param) {
			var _this = this;
			this._planDialog(Ibos.app.url('crm/receipt/editplan', param || {}), function (formData) {
				_this.op.updatePlan(param.id, formData);
			}
			);
		}
	};

	Crm.Collection = Coll;
})();

$(function () {
	var Coll = Crm.Collection;

	$(Coll).on({
		"colladd collupdate collremove colltransplan collplanadd collplanupdate collplanremove": function (evt, evtData) {
			if (evtData.res.isSuccess) {
				Ui.tip("@OPERATION_SUCCESS");
			} else {
				Ui.tip(evtData.res.msg, "danger");
			}
		},
		"colladd collupdate colltransplan": function (evt, evtData) {
			if (evtData.res.isSuccess) {
				Ui.getDialog("d_coll_info").close();
			}
		},
		"collplanadd collplanupdate": function (evt, evtData) {
			if (evtData.res.isSuccess) {
				Ui.getDialog("d_coll_plan").close();
			}
		}
	});

	Ibos.evt.add({
		// 新建收款信息
		"addColl": function (param) {
			Coll.add(param);
		},
		// 编辑收款信息
		"editColl": function (param) {
			Coll.edit(param);
		}
	});
});
