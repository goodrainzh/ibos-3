/**
 * Crm 收款列表页
 * @author  inaki
 * @version $Id$
 */

$(function() {
	var Coll = Crm.Collection;

	// 列表选中页批量操作
	Coll.multiAccess = function(callback) {
		var collIds = U.getCheckedValue("collection[]", "#coll_table");
		if (!collIds) {
			Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", "warning");
		} else {
			callback && callback(collIds);
		}
	};

	// 初始化表格控件
	var collTable = $("#coll_table").DataTable($.extend(true, {}, Ibos.settings.dataTable, {
		// --- Data
		deferLoading: 0, // 每个文件加上这一行
		ajax: Ibos.app.url('crm/receipt/index'),
        language: {
            zeroRecords: '<div class="tac"><img src="static/image/common/no-info.png"></div>'
        },
		// --- Callback
		initComplete: function() {
			// Fixed: IE8下表格初始化后需要再次初始化 checkbox，否则触发不了change事件
			$(this).find('[data-name]').label();
		},
		rowCallback: function(row, data) {
			var $row = $(row);
			$row.find("label input[type='checkbox']").label();
		},
		order: [1, "desc"], // ID 倒序

		columns: [
			// 复选框
			{
				"data": "",
				"orderable": false,
				"className": "dt-checkbox-td",
				"render": function(data, type, row) {
					return '<label class="checkbox mbz"><input type="checkbox" name="collection[]" value="' + row.id + '"/></label>';
				}
			},
			// ID（隐藏）
			{
				"data": "rid",
				"visible": false,
				"render": function(data, type, row) {
					return row.id;
				}
			},
			// 类型
			{
				"data": "receive",
				"render": function(data, type, row) {
					return '<i class="' + (row.status == 1 ? "o-coll-cb" : "o-coll-pb") + '"></i>';
				}
			},
			// 客户
			{
				"data": "clientName",
				"render": function(data, type, row) {
					return '<p class="mbm"><a href="javascript:;" class="xcm" data-action="editColl" data-param="{&quot;id&quot;: &quot;' + row.id + '&quot;}">' + row.account.name + '</a></p>' +
							'<p class="fss">' + row.contract.number + '</p></td>';
				}
			},
			// 收款金额
			{
				"data": "income",
				"render": function(data, type, row) {
					return '<span class="' + (row.status == 1 ? "xco" : "") + '"><em class="xwb ffmy">￥</em>' + row.income + '</span>';
				}
			},
			// 计划价差异
			{
				"data": "diff",
				"orderable": false,
				"render": function(data, type, row) {
					var _tpl;
					// 计划
					if (row.status == 0) {
						_tpl = '<span class="fss"><i class="om-sandclock"></i> <%= U.lang("CRM.TO_COLLECTED") %></span>';
						// 记录
					} else {
						_tpl =
								'<% if(row.markup) { %>' +
								'<span class="fss"><i class="om-crm-rise"></i> ￥<%= row.markup %></span>' +
								'<% } else if(row.markdown) { %>' +
								'<span class="fss"><i class="om-crm-fall"></i> ￥<%= row.markdown %></span>' +
								'<% } else { %>' +
								'<span class="fss"><i class="om-crm-equal"></i> <%= U.lang("CRM.CONSISTENT_WITH_PLAN")%></span>' +
								'<% } %>';
					}
					return $.template(_tpl, {row: row});
				}
			},
			// 到账时间
			{
				"data": "payTime",
				"render": function(data, type, row) {
					return '<span class="fss">' + row.payTime + '</span>';
				}
			}
		]
	}));

	$("#coll_search").search(function(value) {
		collTable.search(value).draw();
	});

	// 高级查询，替换表格数据 ajax 地址
	$(document).on("advquery", function(evt, evtData) {
		collTable.ajax.url(Ibos.app.url('crm/receipt/index') + '&' + evtData.param).load();
	});
	Crm.Query.init("#crm_filter_dropdown");
	Crm.Query.replayCondition(Ibos.app.g('query-condition'));

	Ibos.evt.add({
		// 批量共享
		"shareColls": function() {
			Coll.multiAccess(function(ids) {
				Crm.showShareDialog(Ibos.app.url('crm/receipt/share', {ids: ids}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						this.close();
						collTable.draw(false);
					}
				});
			});
		},
		// 批量分配
		"assignColls": function() {
			Coll.multiAccess(function(ids) {
				Crm.showAssignDialog(Ibos.app.url('crm/receipt/assign', {ids: ids}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						this.close();
						collTable.draw(false);
					}
				});
			});
		},
		// 批量删除收款信息
		"removeColls": function() {
			Coll.multiAccess(function(ids) {
				Ui.confirm(U.lang("CRM.REMOVE_COLLECTION_CONFIRM"), function() {
					Coll.op.remove(ids);
				});
			});
		}
	});

	$(Coll).on({
		// 新建收款信息
		"colladd": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				collTable.draw();
			}
		},
		// 编辑、删除收款信息
		"collupdate collremove": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				collTable.draw(false);
			}
		}
	});
});
