/**
 * Crm 收款信息
 * @author    inaki
 * @version   $Id$
 */

(function () {
	// 共享
	$("#coll_share_tab").on("shown", function () {
		Crm.loadShare("#coll_share", Ibos.app.url('crm/receipt/share'), Ibos.app.getEvtParams(this));
	});

	// 初始化到账时间选择器
	$("#coll_time_dp").datepicker();

	// 到账金额
	$('#coll_num').on("change", function () {
		var value = this.value.replace(/\,/g, "");
		this.value = U.regex(value, "currency") ? 
					value : 
				Ibos.string.addCommas(Ibos.string.toPositiveDecimals(value, 2));
	});

	// 合同编号，值改变时相关信息发生变化
	var contracts = {}; // 合同信息缓存
	$("#coll_ctrt_num").on("change", function () {
		var elem = this;
		var _render = function (data) {
			$("#coll_ctrt_related").html($.template("tpl_ctrt_related", data));
		};
		// 有缓存时从缓存中获取
		if (contracts[this.value]) {
			_render(contracts[this.value]);
			// 没有时发出 ajax 获取数据
		} else {
			if(!this.value) return;
			Crm.Contract.op.get({id: this.value}, function (res) {
				var data = res.data[0];
				if( data == undefined ) return;
				data.user = Ibos.data.getUser(data.uid);
				contracts[elem.value] = data;
				_render(data);

			});
		}
		// $.get(Ibos.app.url('crm/receipt/getplan'), {id: this.value}, function (res) {
		// 	$("#coll_ctrt_plans").html($.template("tpl_ctrt_plans", res));
		// }, "json");

	}).trigger("change");
})();

