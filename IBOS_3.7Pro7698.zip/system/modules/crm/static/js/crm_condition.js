/**
 * Crm 通用查询条件设置
 * @author ink
 * @version $Id$
 */
$(function () {
	// 查询条件设置
	var condition = {
		$Wrap: $("#inputWrap"),
		init: function(){
			var _this = this,
				$key = $("#cond_key");

			$key.change(function(){
				var key = this.value;
				_this.initInput(key);
			}).trigger("change");
		},
		_append: function (data) {
			var tpl = '';
			if( data.operator === "LIKE" || data.operator === "NOT LIKE" ){
				data.operator2 = data.operator === "LIKE" ? "包含" : "不包含";
				tpl = '<li data-value="<%=logic%> <%=key%> <%=operator%> \'%<%= value %>%\'">'+
							'<%= logic %> <%= keyText %> <%= operator2 %> \'<%= dataValue %>\' '+
							'<a hrelogicf="javascript:;" class="o-close-small"></a>'+
						'</li>';
			}else{
				tpl = '<li data-value="<%=logic%> <%=key%> <%=operator%> \'<%= value %>\'">'+
							'<%=logic%> <%= keyText %> <%= operator %> \'<%= dataValue %>\' '+
							'<a href="javascript:;" class="o-close-small"></a>'+
						'</li>';
			}
			$.tmpl(tpl, data).appendTo("#cond_list");
		},
		// 添加条件
		add: function () {
			var data = {
				key: $("#cond_key").val(),
				keyText: $("#cond_key option:selected").text(),
				operator: $("#cond_operator").val(),
				value: $("#cond_value").val(),
				dataValue: U.entity.escape($("#cond_value").attr("data-value") || $("#cond_value").val()),
				logic: $('#crm_cond_dialog [data-logic].active').attr("data-logic")
			},
				logic = "",
				value = "";

			// 如果值为自定义的，返回
			if( data.value === '{-custom-}' ){
				Ui.tip("@CRM.PLEASE_COMPLETED_CONDITION", "warning");
				return false;
			}

			logic = data.logic;
			if( data.operator === "LIKE" || data.operator === "NOT LIKE" ){
				value = "'%" + data.value + "%'";
			}else{
				value = "'" + data.value + "'";
			}

			// 重复条件提示
			if (
				$("#cond_list li[data-value='" + logic + " " + data.key + " " + data.operator + " " + value + "']").length
				||
				$("#cond_list li[data-value='" + " " + data.key + " " + data.operator + " " + value + "']").length
			) {
				Ui.tip("@CRM.REPEATED_CONDITION", "warning");
				return false;
			}

			if (!$("#cond_list li").length) {
				data.logic = "";
			}

			if( data.dataValue === "" ){
				data.dataValue = "''";
			}

			this._append(data);
		},
		remove: function ($item) {
			// 当移除第一个条件且有第二个条件时，将第二个条件的逻辑符去掉
			if ($item.index() === 0) {
				var $nextItem = $item.next(), text;
				if ($nextItem.length) {
					text = $item.next().html();
					$item.next().html(text.match(/\s(.*)/)[1]);
				}
			}
			$item.remove();
		},
		// user:1 time:2 read:3 status:4 input: 5
		operatorChange: function(type){
			var $operator = $("#cond_operator");

            $operator.empty();
            $operator.append($.template("operator_tpl", {type: type}));
		},
		initInput: function(key){
			var $wrap = this.$Wrap,
				html = '',
				_this = this;
			switch(key.split(".")[1]){
				case "`uid`":
				case "`cid`":
				case "`assignuid`":
				case "`creator`":
				case "`editor`":
				case "`shareuid`":
				case "`lastuid`":
					_this.operatorChange(1);
					_this.userInit();
					break;
				case "`begin`":
				case "`end`":
				case "`signdate`":
				case "`assigntime`":
				case "`createtime`":
				case "`updatetime`":
				case "`converttime`":
				case "`planreceivetime`":
					_this.operatorChange(2);
					_this.timeInit();
					break;
				case "`isunread`":
					_this.operatorChange(3);
					$wrap.empty();
                    html = '<select data-value="空值" name="value" id="cond_value">'+
								'<option value="{-NULL-}">空值</option>'+
								'<option value="{-YES-}">是</option>'+
								'<option value="{-NO-}">否</option>'+
							'</select>';

					$wrap.append(html);
					var $cond = $wrap.find('#cond_value');
					$cond.on("change", function(){
						$(this).attr("data-value", $(this).find("option:selected").text());
			        });
					break;
				case "`status`":
					_this.operatorChange(4);
					_this.statusInit(key);
					break;
				default:
					_this.operatorChange(5);
					$wrap.empty();
					html = '<input type="text" name="value" id="cond_value">';
					$wrap.append(html);
			}
		},
		userInit: function(){
			var $wrap = this.$Wrap;

			$wrap.empty();

			$("#cond_uid_box").next(".select2-drop").remove();
			$("#cond_uid_box").remove();
			$wrap.append($.template("userinput_tpl"));
			
			var $uid = $("#cond_uid"),
				$cond = $('#cond_value');

			$uid.userSelect({
				data: Ibos.data.get("user"),
				type: "user",
		        maximumSelectionSize: 1
			});
			var $selectContariner = $wrap.find(".select2-container"),
				$uidBox = $("#cond_uid_box");

			$selectContariner.hide();

			$uid.change(function(ev, val){
				this.value = val || this.value;
				if( this.value === "" ) return;
				var value = this.value.split("_")[1],
					$datauid = $cond.find("option[data-uid]"),
					username = Ibos.data.getUser(value).text;
				if( $datauid.length ){
					$datauid
						.val(value).text(username)
						.attr("selected", true);
				}else{
					$cond
						.find("option:last-child")
						.before('<option data-uid selected value='+ value +'>'+ username +'</option>');
				}
    			$selectContariner.hide();
    			$uidBox.hide();
				$cond.trigger("change");
			});
			$cond.on("change", function(){
				$(this).attr("data-value", $(this).find("option:selected").text());

    			if( this.value !== "{-custom-}" ) { return; }
    			$wrap.find(".select2-search-choice-close").trigger("click");
				$uid.val("");
				setTimeout(function(){
    				$selectContariner.show();
				}, 200);
			});
			$wrap.on("click", "[data-stop]", function(ev){
				if(ev.target.className !== 'select2-search-choice-close'){
					return false;
				}
			});
			$uidBox.on("click", function(ev){
				if( ev.target.nodeName == 'INPUT' )  {
					setTimeout(function(){
						var value = $uidBox.find("li input:checked").val();
						$uid.trigger("change", value);
					}, 100);
				}
				ev.stopPropagation();
			});
			$(document).on("click", function(){
				if($uid.val() === ""){
					$cond.find("option:eq(0)")[0].selected = true; 
				}
				$selectContariner.hide();
			});
		},
		timeInit: function(){
			var $wrap = this.$Wrap;
			$wrap.empty();

			$(".bootstrap-datetimepicker-widget").remove();

			$wrap.append($.template("time_tpl"));
			var $custom = $('#custom_time'),
				$cond = $('#cond_value');

			$custom
				.datepicker()
				.on("hide", function(event){
					var value = $(this).find("input").val(),
						$datetime = $cond.find("option[data-time]");

					if( value === "" ) return;	
					if( $datetime.length ){
						$datetime
							.val(+new Date(value)/1000).text(value)
							.attr("selected", true);
					}else{
						$cond
							.find("option:last-child")
							.before('<option data-time selected value='+ (+new Date(value)/1000) +'>'+ value +'</option>');
					}
					$cond.trigger("change");
				});
			
	        $cond.on("change", function(){
				$(this).attr("data-value", $(this).find("option:selected").text());
	        	if( this.value !== "{-custom-}" ) { return; }

	        	$custom.find(".datepicker-btn").trigger("click");
	        	$(".bootstrap-datetimepicker-widget").css({
	        		display: "block",
	        		position: "absolute",
	        		left: $cond.offset().left,
	        		top: $cond.offset().top + 40
	        	});
	        });
		},
		statusInit: function(key){
			var $wrap = this.$Wrap;
			$wrap.empty();

			$wrap.append( $.template("status_tpl", {name : key.split(".")[0]}) );

			var $cond = $wrap.find('#cond_value');
			$cond.on("change", function(){
				$(this).attr("data-value", $(this).find("option:selected").text());
		    });
		}
	};
	condition.init();

	$("#crm_cond_dialog").bindEvents({
		"click #add_cond": function () {
			condition.add();
		},
		"click .o-close-small": function (evt) {
			var $item = $(evt.target).closest("li");
			condition.remove($item);
		}
	});
});

//@ sourceURL=crm_condition.js
