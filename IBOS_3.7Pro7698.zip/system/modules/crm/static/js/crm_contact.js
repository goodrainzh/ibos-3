/**
 * Crm 联系人模块
 * @version $Id$
 */
(function() {

	var Contact = {
		op: {
			// 恢复快照
			restoreSnap: function(param, callback) {
				$.post(Ibos.app.url('crm/contact/restoresnap'), param, function(res) {
					callback && callback(res);
				}, "json");
			},
			_validate: function(data) {
				var parsed;
				if (!data || !data.length) {
					return false;
				}
				parsed = U.serializedToObject(data);
				// 检查联系人姓名
				if ($.trim(parsed.name) == "") {
					return false;
				}
				return true;
			},
			// 添加联系人
			add: function(data, callback) {
				if (this._validate(data.formData)) {
					$.post(Ibos.app.url('crm/contact/add'), data.formData, function(res) {
						if(res.isSuccess){
							callback && callback(res);
							$(Contact).trigger("contactadd", {data: data, res: res});
						}else{
							Ui.tip(res.msg, "danger");
						}
					}, "json");
				}
			},
			update: function(id, data, callback) {
				if (this._validate(data)) {
					data.push({name: "id", value: id});
					$.post(Ibos.app.url('crm/contact/edit'), data, function(res) {
						if(res.isSuccess){
							callback && callback(res);
							$(Contact).trigger("contactupdate", {id: id, data: data, res: res});
						}else{
							Ui.tip(res.msg, "danger");
						}
					}, "json");
				}
			},
			remove: function(ids, callback) {
				if (ids) {
					$.post(Ibos.app.url('crm/contact/del'), {ids: ids}, function(res) {
						if(res.isSuccess){
							callback && callback(res);
							$(Contact).trigger("contactremove", {ids: ids, res: res});
						}else{
							Ui.tip(res.msg, "danger");
						}
					});
				}
			},
			// 获取联系人
			get: function(param, callback) {
				if ($.isFunction(param)) {
					callback = param;
					param = null;
				}
				$.post(Ibos.app.url('crm/contact/select'), param, function(res) {
					callback && callback(res);
					// 作为全局数据缓存
					Ibos.app.s("contacts", res.data);
				}, "json");
			},
			// 关联客户
			bindAccount: function(param, callback) {
				$.post(Ibos.app.url('crm/contact/clientrelated', {op: 'bind'}), param, function(res) {
					callback && callback(res);
				}, "json");
			},
			// 取消客户关联
			unbindAccount: function(param, callback) {
				$.post(Ibos.app.url('crm/contact/clientrelated', {op: 'unbind'}), param, function(res) {
					callback && callback(res);
				}, "json");
			},
			// 关联联系人
			attach: function(type, param, callback) {
				$.post(Ibos.app.url('crm/contact/' + type, {op: 'bind'}), param, function(res) {
					callback && callback(res);
				}, "json");
			},
			// 解除联系人关联
			detach: function( param, callback) {
				$.post(Ibos.app.url('crm/contact/opprelated', {op: 'unbind'}), param, function(res) {
					callback && callback(res);
				}, "json");
			},
		},
		_dialog: function(url, opts) {
			Ui.closeDialog("d_contact_info");
			if (url) {
				Ui.ajaxDialog(url, $.extend({
					id: "d_contact_info",
					title: U.lang("CRM.CONTACT_INFO"),
					padding: 0,
					lock: true,
					ok: true,
					close: function() {
						$(document).off("contactinvalid");
						// 关闭验证信息提示
						if ($.formValidator) {
							$.formValidator.resetTipState("contactInfo");
						}
					},
					cancel: true
				}, opts));
			}
		},
		_validateForm: function(ok) {
			var formData;
			if ($.formValidator.pageIsValid("contactInfo")) {
				formData = this.DOM.content.find("form").serializeArray();
				ok && ok.call(this, formData);
			}
		},
		// 新建联系人
		add: function(param) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/contact/add', param), {
				ok: function() {
					_this._validateForm.call(this, function(formData) {
						Contact.op.add($.extend({
							formData: formData
						}, param));
					});
					return false;
				}
			});
		},
		// 编辑联系人
		edit: function(param, ok) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/contact/edit', param || {}), {
				ok: function() {
					_this._validateForm.call(this, function(formData) {
						Contact.op.update(param.id, formData);
					});
					return false;
				}
			});
		},
		// 选择联系人对话框
		select: function(param, ok) {
			var dialog = Ui.ajaxDialog(Ibos.app.url('crm/contact/select', param), {
				id: "d_select_contact",
				title: U.lang("CRM.SELECT_CONTACT"),
				padding: 0,
				ok: function() {
					ok && ok(Ibos.app.g("bnCards"));
				},
				okVal: U.lang("SAVE"),
				close: function(){
					Ibos.app.s("bnCards", null);
					Ibos.app.s("crmAccounts", null);
				},
				cancel: function(){
					Ibos.app.s("bnCards", null);
					Ibos.app.s("crmAccounts", null);
				},
				lock: true
			});
			dialog.opParams = param;
		},
		// 批量操作入口
		multiAccess: function(callback) {
			var contactId = U.getCheckedValue("contact[]", "#contact_table");
			if (!contactId) {
				Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", "warning");
			} else {
				callback && callback(contactId);
			}
		}
	};
	Crm.Contact = Contact;

})();

$(function() {
	var Contact = Crm.Contact;
	$(Contact).on({
		"contactadd contactupdate": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				if( evt.type === "contactadd" && evtData.data.cid ){
					location.reload();
				}
				Ui.getDialog("d_contact_info").close();
				Ui.tip("@OPERATION_SUCCESS");
			} else {
				Ui.tip(evtData.res.msg, "danger");
			}
		}
	});
	Ibos.evt.add({
		// 添加联系人
		"addContact": function(param) {
			Contact.add(param);
		},
		"editContact": function(param) {
			if (!param || !param.id) {
				return false;
			}
			Contact.edit(param);
		}
	});

	// 删除关联联系人
	$(".at-contact-item [data-action='deleteContact'], [data-action='detchContact']").click(function(ev){
		var $this = $(this);
		var param = $this.data("param");
		Ui.confirm(Ibos.l("CRM.DETACH_CONTACT_CONFIRM"), function(){
			Contact.op[ $this.data("action") == 'deleteContact' ?  "unbindAccount" : "detach" ](param, function(res){
				if( res.isSuccess ){
					$this.closest("li").remove();
					Ui.tip(Ibos.l("DELETE_SUCCESS"));
				}else{
					Ui.tip(Ibos.l("DELETE_FAILED"), 'danger');
				}
			});
		});
		ev.stopPropagation();
	});
});
