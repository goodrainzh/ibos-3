/**
 * Crm 客户 联系人
 * @version $Id$
 */

$(function() {
	var contactList = {
		$container: $("#at_contact_list"),
		tpl: "tpl_contact",
		init: function() {
			var _this = this;
			// 阻止联系人信息内部链接的冒泡
			this.$container
				// 添加 
				.on("click", "[data-node='contactAttach']", function(e) {
					var param = Ibos.app.getEvtParams(this),
							type = param.action;
					Crm.Contact.select(Ibos.app.getEvtParams(this), function(contactIds) {
						Crm.Contact.op.attach(type, $.extend({
							contactid: contactIds,
							id: Ibos.app.g('id')
						}, param),
						function(res) {
							if (res.isSuccess) {
								window.location.reload();
								Ui.tip("@OPERATION_SUCCESS");
							} else {
								Ui.tip(res.msg, "danger");
							}
						});
					});
				});
		}
	};
	contactList.init();

	Ibos.evt.add({
		"editContact": function(param){
			if (!param || !param.id) {
				return false;
			}
			Crm.Contact._dialog(Ibos.app.url('crm/contact/edit', param || {}), {
				ok: function() {
					Crm.Contact._validateForm.call(this, function(formData) {
						Crm.Contact.op.update(param.id, formData, function(){
							window.location.reload();
						});
					});
					return false;
				}
			});
		}
	});
});