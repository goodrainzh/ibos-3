/**
 * Crm 联系人首页
 * @author  inaki
 * @version $Id$
 */
$(function() {
	var Contact = Crm.Contact;

	// 初始化表格控件
	var contactTable = $("#contact_table").DataTable($.extend(true, {}, Ibos.settings.dataTable, {
		// --- Data
		deferLoading: 0, // 每个文件加上这一行
		ajax: Ibos.app.url('crm/contact/index'),
        language: {
            zeroRecords: '<div class="tac"><img src="static/image/common/no-info.png"></div>'
        },
		// --- Callback
		initComplete: function() {
			// Fixed: IE8下表格初始化后需要再次初始化 checkbox，否则触发不了change事件
			$(this).find('[data-name]').label();
		},
		rowCallback: function(row, data) {
			var $row = $(row);
			$row.find("label input[type='checkbox']").label();
		},
		order: [1, "desc"], // ID 倒序

		columns: [
			// 复选框
			{
				"data": "",
				"orderable": false,
				"className": "dt-checkbox-td",
				"render": function(data, type, row) {
					return '<label class="checkbox mbz"><input type="checkbox" name="contact[]" value="' + row.id + '"/></label>';
				}
			},
			// ID（隐藏）
			{
				"data": "contactid",
				"visible": false,
				"render": function(data, type, row) {
					return row.id;
				}
			},
			// 联系人信息
			{
				"data": "name",
				"render": function(data, type, row) {
					var _tpl =
							'<div class="media">' +
							'<% if(row.avt) { %>' +
							'<div class="pull-left cttv-avt-small"><img src="<%= row.avt %>" width="30" height="30"/></div>' +
							'<% } else { %>' +
							'<div class="pull-left cttv-avt-small" style="background-color: <%= row.color %>"><%= row.name.charAt(0) %></div>' +
							'<% } %>' +
							'<div class="media-body">' +
							'<a href="javascript:;" class="xcm" data-action="editContact" data-param="{&quot;id&quot;: &quot;<%= row.id %>&quot;}"><%= row.name %></a>' +
							'<div class="fss"><%= row.department %> · <%= row.position %></div>' +
							'</div>' +
							'</div>';

					return $.template(_tpl, {row: row});
				}
			},
			// 所属公司
			{
				"data": "company",
				"render": function(data, type, row) {
					return '<span class="fss">' + row.fullname + '</span>';
				}
			},
			// 工作电话
			{
				"data": "mobile",
				"render": function(data, type, row) {
					return '<span class="fss">' + row.mobile + '</span>';
				}
			},
			// 最近联系时间
			{
				"data": "lasttouchtime",
				"render": function(data, type, row) {
					return '<span class="fss">' + row.contactTime + '</span>';
				}
			}
		]
	}));

	$("#contact_search").search(function(value) {
		contactTable.search(value).draw();
	});

	// 高级查询，替换表格数据 ajax 地址
	$(document).on("advquery", function(evt, evtData) {
		contactTable.ajax.url(Ibos.app.url('crm/contact/index') + '&' + evtData.param).load();
	});
	Crm.Query.init("#crm_filter_dropdown");
	Crm.Query.replayCondition(Ibos.app.g('query-condition'));
	// 数据交互事件监听
	$(Contact).on({
		"contactadd": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				contactTable.draw();
			}
		},
		"contactupdate contactremove": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				contactTable.draw(false);
			}
		}
	});


	Ibos.evt.add({
		// 发送邮件
		"sendMail": function() {
			if (Ibos.app.g('externalmail') != 1) {
				Ui.tip("@CRM.NOT_OPEN_EMAIL_EXTERNAL", "warning");
				return false;
			}
			Contact.multiAccess(function(ids) {
				window.location.href = Ibos.app.url('crm/contact/sendmail', {ids: ids});
			});
		},
		// 提取邮箱地址
		"extractMail": function() {
			Contact.multiAccess(function(ids) {
				// 导出选中客户的邮箱地址至 excel 表
				window.location.href = Ibos.app.url('crm/contact/exportmail', {ids: ids});
			});
		},
		// 批量删除联系人
		"removeContacts": function() {
			Contact.multiAccess(function(contactIds) {
				Ui.confirm(U.lang("CRM.REMOVE_CONTACT_CONFIRM"), function() {
					Contact.op.remove(contactIds);
				});
			});
		},
		// 共享联系人信息
		"shareContact": function() {
			Contact.multiAccess(function(contactIds) {
				Crm.showShareDialog(Ibos.app.url('crm/contact/share', {ids: contactIds}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						this.close();
						contactTable.draw(false);
					}
				});
			});
		},
		// 分配联系人信息
		"assignContact": function() {
			Contact.multiAccess(function(contactId) {
				Crm.showAssignDialog(Ibos.app.url('crm/contact/assign', {ids: contactId}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						this.close();
						contactTable.draw(false);
					}
				});
			});
		}
	});
});