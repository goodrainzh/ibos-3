/**
 * Crm 联系人信息
 * @version $Id$
 */
$(function () {
	var Contact = Crm.Contact;
	// 基本组件初始化
	$("#contact_info").find(".radio input").label();
	$("#contact_birthday").datepicker();
	$("#contact_info_tab").on("shown", "[data-toggle='tab']", function (evt) {
		// 重置表单验证提示
		$.formValidator.resetTipState("contactInfo");
		// 读取共享联系人
		if (evt.target.hash === "#contact_share") {
			Crm.loadShare(evt.target.hash, Ibos.app.url('crm/contact/share'), Ibos.app.getEvtParams(this));
		}
	});



	// 联系方式管理
	var contactWay = {
		$container: $("#contact_way"),
		tpl: "tpl_contact_way",
		index: 0,
		init: function () {
			var _this = this;
			_this.index = this.$container.find("input").length;
			this.$container.bindEvents({
				"click [data-node='addItem']": function(evt){
					_this.addRow({
						type: "",
						value: "",
						index: ++_this.index
					});
				},
				"click .o-close": function () {
					_this.removeRow($(this).closest(".control-group"));
				}
			});
			this._bind( _this.$container );
		},
		// 增加一行联系方式
		addRow: function (data) {
			var $newRow = $.tmpl(this.tpl, data);
			this.$container.find(">div").last().before($newRow);
			this._bind($newRow);
		},
		// 移除一行联系方式
		removeRow: function ($row) {
			var $prevRow = $row.prev();
			// 移除一行后，焦点放到被移除行的上一行中
			if ($prevRow.length) {
				$prevRow.find("[name='extendvalue[]']").focus();
				// 若已没有可用行，则焦点放到新建行中
			} else {
				this.$container.find('[name="extendvalue[]"]').focus();
			}
			$row.off("change");
			// 删除表单验证提示
			var $input = $row.find("input"),
				validObjects = $("body").data("contactInfo").validObjects;
			validObjects.splice( validObjects.indexOf( $input[0] ), 1);
			$("#"+ $input.attr("id") + "Tip").remove();
			$row.remove();
		},
		_bind: function($row){
			var _this = this;
			$row.find("select").change(function(){
				_this.regInput($(this), this.value);
			}).trigger("change");
		},
		regInput: function($this, regType){
			var $obj = $this.closest("div").find("input"),
				regExp = "",
				dataType = "enum";
			switch(regType){
				case "email":
				case "mobile":
				case "qq":
					regExp = regType;
					break;
				case "phone":
					regExp = "^(0\\d{2,3}-?)?\\d{6,}$";
            		dataType = "number";
					break;
				default:
					regExp = "notempty";
			}
			var validObjects = $("body").data("contactInfo").validObjects,
				index = 0;
			if( (index =  validObjects.indexOf( $obj[0] )) >= 0 ){
				validObjects.splice( index, 1);
			}

			$obj.formValidator({
				onFocus: U.lang("CRM.INPUT_LEAD_" + regType.toUpperCase()),
				validatorGroup: "contactInfo",
				empty: true
			}).regexValidator({
				regExp: regExp,
				dataType: dataType,
				onError: U.lang("CRM.SURE_CORRECT_"+ regType.toUpperCase())
			});
		}
	};

	// 初始化快照功能
	if (Crm.SnapModel) {
		var snapModel = new Crm.SnapModel({url: Ibos.app.url('crm/contact/snap')});
		var snapView = new Crm.SnapView(snapModel, {
			content: "#contact_snap_body",
			select: "#contact_snap_id",
			prevBtn: "#contact_snap_prev",
			nextBtn: "#contact_snap_next"
		});
		var snapCtrl = new Crm.SnapController(snapModel, snapView);
		$("#contact_snap_restore").on("click", function () {
			var id = snapModel.getVal();
			Contact.op.restoreSnap({id: id}, function (res) {
				if (res.isSuccess) {
					Ui.closeDialog("d_contact_info");
					Ui.tip("@CRM.RESTORE_SNAP_SUCCESS");
					window.location.reload();
				}
			});
		});
	}


	// 初始化头像上传功能
	var _initUpload = function () {
		Ibos.upload.image({
			// Backend Settings
			upload_url: Ibos.app.url('crm/contact/avatar', {"uid": Ibos.app.g("uid"), "hash": Ibos.app.g("upload").hash}),
			post_params: {},
			file_size_limit: Ibos.app.g("upload").max,
			file_queue_limit: "1",
			file_types: Ibos.app.g("upload").imageexts.ext,
			file_types_description: Ibos.app.g("upload").imageexts.scriptdepict,
			button_placeholder_id: "contact_avt_upload",
			button_image_url: "",
			button_width: 178,
			button_height: 198,
			custom_settings: {
				success: function (obj, res) {
					if (res.isSuccess) {
						$('#contact_avt_preview').find('img').attr('src', res.data);
						$('#contact_avt').val(res.file);
					} else {
						Ui.tip(res.msg, "danger");
					}
				}
			}
		});
	};

	if (typeof SWFUpload !== "undefined") {
		_initUpload();
	} else {
		$.getScript(Ibos.app.getStaticUrl("/js/lib/SWFUpload/SWFUpload.packaged.js")).done(function () {
			$.getScript(Ibos.app.getStaticUrl("/js/lib/SWFUpload/handlers.js")).done(_initUpload);
		});
	}
	// 初始化表单验证
	var _initFormValidator = function () {
		// 延时执行以修正提示定位
		setTimeout(function () {
			$.formValidator.initConfig({
				formID: "contact_info_form",
				theme: "",
				validatorGroup: "contactInfo"
			});
			// 联系人姓名不能为空
			$("#contact_name").formValidator({
				onFocus: U.lang("CRM.INPUT_CONTACT_NAME"),
				validatorGroup: "contactInfo"
			}).regexValidator({
				regExp: "notempty",
				dataType: "enum",
				onError: U.lang("CRM.INPUT_CONTACT_NAME")
			});

			contactWay.init();
		}, 0);
	};

	Crm.loadFormValidator(_initFormValidator);


	Ibos.evt.add({
		// 关联客户
		"bindAccount": function (param, elem) {
			Crm.Account.selectOne(param, function (accountid, account) {
				$(elem).closest(".crm-warning-tip").slideUp(200, function () {
					account.fullname = U.entity.escape(account.fullname);
					var data = {
						account: account, 
						cid: accountid
					};
					$(this).html($.template("tpl_account_associated", data)).slideDown(200);
				});
			});
		},
		// 解除客户关联
		"unbindAccount": function (param, elem) {
			$(elem).closest(".crm-warning-tip").slideUp(200, function () {
				var data = {
					cid: ""
				};
				$(this).html($.template("tpl_account_unassociated", data)).slideDown(200);
			});
		}
	});
});
