/**
 * Crm 合同模块
 * @author  inaki
 * @version $Id$
 */

$(function () {

	var Contract = {
		op: {
			// 设置合同当前步骤
			setProgress: function (param, callback) {
				$.post(Ibos.app.url('crm/contract/edit', {op: 'field', field: 'status', formhash: Ibos.app.g('formhash')}), param, function (res) {
					callback && callback(res);
				}, "json");
			},
			// 删除合同
			remove: function (ids, callback) {
				if (ids) {
					$.post(Ibos.app.url('crm/contract/del', {ids: ids}), function (res) {
						callback && callback(res);
						$(Contract).trigger("ctrtremove", {ids: ids, res: res});
					}, "json");
				}
			},
			// 获取合同
			get: function (param, callback) {
				if ($.isFunction(param)) {
					callback = param;
					param = null;
				}
				$.post(Ibos.app.url('crm/contract/get'), param, function (res) {
					callback && callback(res);
					// 作为全局数据缓存
					Ibos.app.s("contracts", res.data);
				}, "json");
			}
		},
		// 选择合同
		select: function (ok) {
			Ui.ajaxDialog("/system/modules/crm/views/contract/select.html", {
				id: "d_select_contract",
				title: U.lang("CRM.SELECT_CONTRACT"),
				padding: 0,
				ok: function () {
					ok && ok(this.selected);
				},
				okVal: U.lang("SAVE"),
				close: function(){
					Ibos.app.s("bnCards", null);
					Ibos.app.s("crmAccounts", null);
				},
				cancel: function(){
					Ibos.app.s("bnCards", null);
					Ibos.app.s("crmAccounts", null);
				},
				lock: true
			});
		}
	};
	$(Contract).on("ctrtremove", function (evt, evtData) {
		if (evtData.res.isSuccess) {
			Ui.tip("@OPERATION_SUCCESS");
		} else {
			Ui.tip(res.msg, "danger");
		}
	});
	Crm.Contract = Contract;
});
