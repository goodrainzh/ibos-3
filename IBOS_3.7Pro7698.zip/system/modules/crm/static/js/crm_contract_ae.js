/**
 * Crm 合同新建编辑
 * @author  inaki
 * @version $Id$
 */

$(function() {
	var Contract = {
		OrderInit: function() {
			// 订单明细表格
			var ctrtOrder = {
				$table: $("#ctrl_pd_table"),
				init: function() {
					var _this = this;

					this.table = new Ibos.CmList(this.$table.find("tbody"), {tpl: "tpl_pd_row"});

					var $lastRowClone = this.$table.find(".ctrl-pd-last").clone();

					var addCustomRow = function() {
						var $row = _this.$table.find(".ctrl-pd-last");
						$lastRowClone.clone().insertAfter($row);
						$row.removeClass("ctrl-pd-last");
					};
					this.$table.bindEvents({
						// 格式化成交价为货币格式
						"change [name^='executionprice'],[name='newexecutionprice[]']": function() {
							this.value = _this.formatCurrency(this.value || 0);
							_this.calculate();
						},
						// 格式化数量为正整数
						"change [name^='quantity'],[name='newquantity[]']": function() {
							this.value = this.value ? Ibos.string.toPositiveInt(this.value) : "0";
							_this.calculate();
						},
						"click .o-trash": function() {
							$(this).closest("tr").remove();
							_this.calculate();
						}

					})
							// 最后一行输入内容时，自动新增一行
							.on("keyup", ".ctrl-pd-last input[name='newprodname[]']", function() {
								if ($.trim(this.value)) {
									addCustomRow();
								}
							});
				},
				// 计算总额
				calculate: function() {
					var total = 0, price, quantityl;
					price = $('[name^="executionprice"], [name="newexecutionprice[]"]').map(function() {
						return this.value;
					}).get();

					quantity = $('[name^="quantity"], [name="newquantity[]"]').map(function() {
						return +this.value;
					}).get();

					for (var i = 0; i < price.length; i++) {
						total += this.formatCurrencyToNumber(price[i]) * quantity[i];
					}

					$(this).trigger("calc", {total: total, formattedTotal: this.formatCurrency(total)});

					return total;
				},
				// 转化为货币格式
				formatCurrency: function(value) {
					value = (value + "").replace(/\,/g, "");
					return U.regex(value, "currency") ? value : Ibos.string.addCommas(Ibos.string.toPositiveDecimals(value, 2));
				},
				// 将货币格式转为数字格式
				formatCurrencyToNumber: function(value) {
					return +((value+"").replace(/,/g, ""));
				}
			};

			$(ctrtOrder).on("calc", function(evt, data) {
				$("#ctrt_prod_total").html(data.formattedTotal);
				$("#prod_total").val(data.formattedTotal);
			});

			ctrtOrder.init();
			ctrtOrder.calculate();

			// 产品服务侧栏树
			var btnOff = true;
			var treeSettings = {
				data: {
					simpleData: {
						enable: true
					}
				},
				view: {
					showLine: false,
					selectedMulti: false,
					showIcon: false,
					addDiyDom: function(treeId, treeNode){
						if(treeNode.product){
							var aObj = $("#" + treeNode.tId + "_a");
							var optBtn = "<i class='o-menu-add add-pos' title='添加产品'></i>";
							aObj.append(optBtn);
						}else{
							var $obj = $("#"+ treeNode.tId +"_switch");
							if($obj.hasClass("noline_docu")){
								$obj.removeClass("noline_docu").addClass("noline_close");
							}
						}
					}
				},
				callback: {
					onClick: function(evt, treeId, treeNode) {
						// 如果是产品项节点，则添加一行记录
						$("#" + treeNode.tId + "_a").removeClass("curSelectedNode");
						if (treeNode.product) {
							var $product = ctrtOrder.table.getItem(treeNode.realid);
							if( $product.length ){
									if( !btnOff ) return;
									btnOff = false;
									var $quantity =  $product.find("[name^=quantity]"),
										$animateWrap = $product.find(".p-animate"),
										$animate = $animateWrap.find("ul"),
										$animateLi = $animateWrap.find("li"),
										$border = $(".border"),
										num = +$quantity.val() + 1;

									$product.addClass("active");
									$animateLi.eq(0).html($quantity.val());
									$animateLi.eq(1).html(num);
									$animateWrap.show();
									$quantity.val("");

									$border.show().css("top", $product[0].offsetTop);

									$animate.animate({
										top: "-30"
									}, 300, function(){
										$border.hide();
										$quantity.val( num );
										$product.removeClass("active");
										$animateWrap.hide();
										$animate.css("top", 0);
										ctrtOrder.calculate();
										btnOff = true;
									});

							}else{
								treeNode.name = U.entity.escape(treeNode.name);
								ctrtOrder.table.addItem($.extend({}, treeNode, {
									priceBefore: ctrtOrder.formatCurrency(treeNode.price),
									price: ctrtOrder.formatCurrency(treeNode.price),
									num: 1
								}), true);
								ctrtOrder.calculate();
							}
						}
					}
				}
			};

			// 拿到树的数据并初始化
			$.get(Ibos.app.url('crm/productcategory/withproduct'), function(res) {
				$.map(res, function(item){
					item.name = U.entity.unescape(item.name);
				});
				$.fn.zTree.init($("#ctrt_pd_tree"), treeSettings, res);
			}, "json");
		},
		ErecordInit: function() {
			// 打开幻灯预览器
			function showGallery(container, index) {
				var $container = $(container), fullGallery = $container.data("fullGallery");
				// 设置当前活动状态的图片
				var _setIndex = function(index) {
					var _timer;
					if (typeof index !== "undefined" && fullGallery) {
						// 定时检测，当幻灯不在动画过程中时，再设置当前图片索引
						_timer = setInterval(function() {
							if (!fullGallery.gallery.in_transition) {
								fullGallery.gallery.showImage(index);
								clearInterval(_timer);
							}
						}, 100);
					}
				};

				// 读取初始化需要的文件
				var _loadFiles = function(callback) {
					if (typeof FullGallery !== "undefined") {
						callback && callback();
					} else {
						U.loadCss(Ibos.app.getStaticUrl("/js/lib/gallery/jquery.gallery.css"));
						U.loadCss(Ibos.app.getStaticUrl("/js/app/fullGallery/fullGallery.css"));

						var galleryJsPath = Ibos.app.getStaticUrl("/js/lib/gallery/jquery.gallery.js"),
								mousewheelJsPath = Ibos.app.getStaticUrl("/js/lib/jquery.mousewheel.js"),
								fullGalleryJsPath = Ibos.app.getStaticUrl("/js/app/fullGallery/fullGallery.js");

						$.when($.getScript(galleryJsPath), $.getScript(mousewheelJsPath))
								.done(function() {
									$.getScript(fullGalleryJsPath, callback);
								});
					}
				};

				// 非初始化过画廊时，加载相关样式和脚本
				if (!fullGallery) {
					_loadFiles(function() {
						// 根据图片节点生成相关数据
						var images = $container.find("img").map(function(index, elem) {
							return {
								thumburl: $.attr(elem, "src"),
								url: $.attr(elem, "data-full"),
								title: $.attr(elem, "title"),
								desc: $.attr(elem, "alt")
							};
						}).get();

						// 初始化画廊
						$container.data("fullGallery", new FullGallery(images, {start_at_index: index}));
					});
				} else {
					fullGallery.show();
					_setIndex(index);
				}
			}

		},
		_getAccountInfoById: function(data, id) {
			var acObj;
			$.each(data, function(index, el) {
				if (el.id === id) {
					acObj = el;
				}
			});
			return acObj;
		}
	};

	// 签约客户，关联机会，关联联系人
	var $ctrtAccout = $("#ctrt_account");
	if ($ctrtAccout.is('select')) {
		$ctrtAccout.ibosSelect({width: "100%"});
	}

	// 根据客户变化，机会及联系人相关数据也会变化
	$ctrtAccout.on("change", function() {
		var getSetting = function(data) {
			return {
				width: "100%",
				multiple: false,
				allowClear: true,
				data: $.map(data, function(_data) {
					return {id: _data.id, text: _data.name};
				})
			};
		};
		Crm.Opportunity.op.get({id: this.value}, function(res) {
			$("#ctrt_opportunity").ibosSelect(getSetting(res.data));
		});

		Crm.Contact.op.get({cid: this.value, formhash: Ibos.app.g('formhash'), action: "opprelated"}, function(res) {
			$("#ctrt_contact").ibosSelect(getSetting(res.data));
		});

	}).triggerHandler("change");

	// 合同负责人，我方签约人
	$("#ctrt_principal, #ctrt_our_contractor").userSelect({
		type: "user",
		data: Ibos.data.get("user"),
		maximumSelectionSize: 1,
		clearable: false
	});


	$("form").submit(function(ev){
		if(!$.trim($("[name='cid']").val())){
			Ui.tip(Ibos.l('CRM.SELECT_USER'), 'danger');
			ev.preventDefault();
		}
	});

	// 开始时间、结束时间
	$("#ctrt_startdate_dp").datepicker({target: $("#ctrt_enddate_dp")});
	// 签约日期
	$("#ctrt_date_dp").datepicker();

	// 小数数值自动修正
	$(document).on("change", "[data-decimals]", function() {
		var digits = $.attr(this, "data-digits") || 2,
			value = this.value.replace(/\,/g, "");

		this.value = U.regex(value, "currency") ?
				value :
				Ibos.string.addCommas(Ibos.string.toPositiveDecimals(value, digits));
	});

	$("#contract_tab").on("click", "[data-node='accountAttach']", function(e) {
		var param = "",
				$content = $(this).closest("table"),
				$opp = $content.find("[name='oid']"),
				$selectOpt = $content.find("[data-node='selectedOpp']");
		Crm.Account.selectOne(param, function(aid) {
			var id = aid,
					data = Ibos.app.g("crmAccounts"),
					accObj = Contract._getAccountInfoById(data, id);
			$content.find("[data-node='selectedAccount']").text(U.entity.unescape(accObj.name));
			$content.find("[name='cid']").val(accObj.id);

			var $selected = $content.find("[data-node='oppAttach']"),
					cdata = $selected.data("param");
			cdata.cid = id;
			$selected.attr("data-param", $.toJSON(cdata));
			$opp.val("");
			$selectOpt.text("");
		});
	}).on("click", "[data-node='oppAttach']", function(e) {
		var param = $(this).data("param"),
				$content = $(this).closest("table"),
				$opp = $content.find("[name='oid']"),
				$selectOpt = $content.find("[data-node='selectedOpp']");
		Crm.Opportunity.selectOne(param, function(selected) {
			var data = Ibos.app.g("crmAccounts"),
					optObj = Contract._getAccountInfoById(data, selected);
			$selectOpt.text(U.entity.unescape(optObj.name));
			$opp.val(selected);
		});
	});

	Contract.OrderInit();
	Contract.ErecordInit();

});
