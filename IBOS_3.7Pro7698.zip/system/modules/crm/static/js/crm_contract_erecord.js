/**
 * Crm 合同电子档页
 * @author  inaki
 * @version $Id$
 */

(function () {
	var PreviewBox = function(elem, opts){
		var _this = this;
		this.$elem = $(elem);
		this._timer = 0;
		this._show = false;
		this.opts = $.extend({
			src: this.$elem.attr("data-src") || this.$elem.attr("src")
			// width, height, position
		}, opts);

		this.$elem.on({
			"mouseenter": function(evt){
				_this.show({ left: evt.pageX, top: evt.pageY });
			},

			"mouseleave": function(evt){
				var $pwBox = _this.$elem.data("previewBox");

				if($.contains($pwBox[0], evt.relatedTarget) || $pwBox[0] === evt.relatedTarget) {
					return false;
				}

				_this.hide();
			}
		});
	};

	PreviewBox.prototype._createBox = function(){
		var _this = this,
			opts = this.opts;

		var $pwBox = $("<div class='img-pw-box'><img src='"+ opts.src +"'/></div>").appendTo(document.body),
			$pwImg = $pwBox.children();

		if(opts.width) {
			$pwImg.css("width", opts.width);
		}

		if(opts.height) { 
			$pwImg.css("height", opts.height);
		}

		$pwBox.on({
			"mouseenter": function(){
				_this.show();
			},

			"mouseleave": function(evt){
				if($.contains(_this.$elem, evt.relatedTarget) || _this.$elem === evt.relatedTarget) {
					return false;
				}
				_this.hide();
			}
		});

		this.$elem.data("previewBox", $pwBox);	

		return $pwBox;
	};


	PreviewBox.prototype.show = function(pos) {
		var _this = this,
			$pwBox = this.$elem.data("previewBox");

		clearTimeout(this._timer);

		if(this._show){
			return false;
		}

		if(!$pwBox) {
			$pwBox = this._createBox();
		}

		this._timer = setTimeout(function(){
			$pwBox.show().fadeTo(0, 0).fadeTo(200, 1);

			$pwBox.position($.extend({
				of: _this.$elem
			}, _this.opts.position));

			_this._show = true;
		}, 100);
	};

	PreviewBox.prototype.hide = function(){
		var _this = this,
			$pwBox = this.$elem.data("previewBox");

		clearTimeout(this._timer);

		if(!this._show){
			return false;
		}

		if($pwBox){
			this._timer = setTimeout(function(){
				$pwBox.remove();
				_this.$elem.removeData("previewBox");
				_this._show = false;
			}, 200);
		}
	};

	Ibos.PreviewBox = PreviewBox;
})();


$(function(){

	// 打开幻灯预览器
	function showGallery(container, index) {
		var $container = $(container),
			fullGallery = $container.data("fullGallery");

		// 设置当前活动状态的图片
		var _setIndex = function(index){
			var _timer;
			if(typeof index !== "undefined" && fullGallery) {
				// 定时检测，当幻灯不在动画过程中时，再设置当前图片索引
				_timer = setInterval(function(){
					if(!fullGallery.gallery.in_transition) {
						fullGallery.gallery.showImage(index);
						clearInterval(_timer);		
					}
				}, 100);
			}
		};

		// 读取初始化需要的文件
		var _loadFiles = function(callback){
			if(typeof FullGallery !== "undefined") {
				callback && callback();
			} else {
				U.loadCss(Ibos.app.getStaticUrl("/js/lib/gallery/jquery.gallery.css"));
				U.loadCss(Ibos.app.getStaticUrl("/js/app/fullGallery/fullGallery.css"));

				var galleryJsPath = Ibos.app.getStaticUrl("/js/lib/gallery/jquery.gallery.js"),
					mousewheelJsPath = Ibos.app.getStaticUrl("/js/lib/jquery.mousewheel.js"),
					fullGalleryJsPath = Ibos.app.getStaticUrl("/js/app/fullGallery/fullGallery.js");

				$.when($.getScript(galleryJsPath), $.getScript(mousewheelJsPath))
				.done(function(){
					$.getScript(fullGalleryJsPath, callback);
				});
			}
		};

		// 非初始化过画廊时，加载相关样式和脚本
		if(!fullGallery) {
			_loadFiles(function(){
				// 根据图片节点生成相关数据
				var images = $container.find("img").map(function(index, elem){
					return {
						thumburl: $.attr(elem, "src"),
						url: $.attr(elem, "data-full"),
						title: $.attr(elem, "title"),
						desc: $.attr(elem, "alt")
					};
				}).get();

				// 初始化画廊
				$container.data("fullGallery", new FullGallery(images, { start_at_index: index }));
			});
		} else {
			fullGallery.show();
			_setIndex(index);
		}
	}

	var $erList  = $("#ctrt_erecord_list"),
		$delErecord = $("[data-action='delErecord']");

	$erList.on("click", "li", function(ev){
		var target = ev.target || ev.srcElement;
		if( /span|input|label/.test(target.nodeName.toLowerCase()) ){
			var erecord = U.getCheckedValue("erecord");
			if( $.trim( erecord ) ){
				$delErecord.show();
			}else{
				$delErecord.hide();
			}
		}else{
			showGallery($erList, $(this).index());
		}
	});

	var $erslideshow = $("#erecord_slideshow");

	$erslideshow.on("click", function(){
		showGallery($erList, 0);
	});

	// Hover 图片放大预览
	$erList.find("li").each(function(){
		var src = $(this).find("img").attr("src");
		new Ibos.PreviewBox(this, { 
			width: 400, 
			position: {
				my: "left-85 top+10",
				at: "right bottom"
			},
			src: src
		});
	});
	
	Ibos.evt.add({
		// 打开电子档图片上传对话框
		"showERecordUploadDialog": function() {
			Ibos.uploadDialog({
				upload_url: Ibos.app.url('crm/contract/attach'),
				post_params: {isele: '1', id: Ibos.app.g("contractId")},
				file_types: Ibos.app.g("upload").imageexts.ext,
				custom_settings: {
					success: function(file, res) {
						var $record = $.tmpl("erecord_tpl", res);
						$record.find("[type='checkbox']").label();
						$("#ctrt_erecord_list").prepend($record);
						var src = res.thumburl;
						new Ibos.PreviewBox($record, { 
							width: 400, 
							position: {
								my: "left-85 top-20",
								at: "right bottom"
							},
							src: src
						});
						if( !$erslideshow.is("visible") ){
							$erslideshow.show();
						}
					}
				}
			});
		},
		// 删除电子档
		"delErecord": function(){
			var erecord = U.getCheckedValue("erecord");
			if( !erecord ){
				Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", 'danger');
				return false;
			}
			Ui.confirm(Ibos.l("CRM.REMOVE_ERECORDS_CONFIRM"), function(){
				$.post(Ibos.app.url("crm/contract/attach", {op: "remove"}), { id: erecord }, function(res){
					if( res.isSuccess ){
						$.each(erecord.split(","), function(i, item){
							$erList.find("[data-id='"+ item +"']").remove();
						});
						if( !$erList.find("li").length ){
							$delErecord.hide();
							$erslideshow.hide();
						}
						Ui.tip("@OPERATION_SUCCESS");
					}else{
						Ui.tip("@OPERATION_FAILED", 'danger');
					}
				}, 'json');
			});
		}
	});
});