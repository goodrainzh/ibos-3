/**
 * Crm 合同动态聚合页
 * @author  inaki
 * @version $Id$
 */

$(function() {
	// 初始化步骤下拉选框
	var setProgress = {
		el: $("#ctrt_progress"),
		val: $("#ctrt_progress").val(),
		targetEl: $(".crm-memo span"),
		status: ["执行前", "执行中", "执行完", "合同终止"],
		bind: function(){
			var that = this;
			that.el.pSelect({width: 120}).on("change", function() {
				var _this = this;
				if( that.val == this.value ) return;
				Crm.Contract.op.setProgress({value: this.value, id: Ibos.app.g('contractId')}, function(res) {
					if (res.isSuccess) {
						that.val = _this.value;
						that.targetEl.html( that.status[_this.value-1] );
						Ui.tip("@OPERATION_SUCCESS");
					} else {
						Ui.tip(res.msg, "danger");
					}
				});
			});
		}
	};
	setProgress.bind();
	

	// 收款时间线节点信息提示
	$(".coll-tl-nodes").find("li").each(function() {
		var $elem = $(this);

		Ui.popover($elem, {
			content: $elem.html(),
			placement: "bottom",
			trigger: "hover",
			html: true,
			container: document.body
		});
	});

	// 收款信息表
	var rctList = {
		container: "#coll_rct",
		init: function() {
			var _this = this,
					$container = $(this.container);

			$container.bindEvents({
				"click [data-node='editPlanBtn']": function() {
					var planId = $(this).closest("tr").attr("data-record-id");
					Crm.Collection.editPlan({id: planId});
				},
				"click [data-node='removePlanBtn']": function() {
					var planId = $(this).closest("tr").attr("data-record-id");
					Crm.Collection.op.removePlan(planId);
				},
				"click [data-node='transPlanBtn']": function() {
					var planId = $(this).closest("tr").attr("data-record-id");
					Crm.Collection.transPlanToRecord({id: planId});
				},
				"click [data-node='editRecordBtn']": function() {
					var recordId = $(this).closest("tr").attr("data-record-id"),
							contractid = $(this).closest("tr").attr("data-contract-id");
					Crm.Collection.edit({id: recordId, contractid: contractid});
				},
				"click [data-node='removeRecordBtn']": function() {
					var recordId = $(this).closest("tr").attr("data-record-id");
					Crm.Collection.op.remove(recordId);
				}
			});
		}
	}

	rctList.init();

	$(Crm.Collection).on({
		// 增删改记录、增删改计划
		// @Todo: 由于复杂度问题，反馈暂时使用刷新，计划完善
		"colladd collupdate collremove collplanadd collplanupdate collplanremove colltransplan": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				window.location.reload();
			}
		}
	});



	Ibos.evt.add({
		// 添加收款计划
		"addCollPlan": function(param) {
			Crm.Collection.addPlan(param);
		},
		// 上传附件
		"openUploadDialog": function() {
			Ibos.uploadDialog({
				upload_url: Ibos.app.url('crm/contract/attach'),
				post_params: {id: Ibos.app.g("contractId")},
				custom_settings: {
					success: function(file, res) {
						$("#dy_attachment").prepend($.template("tpl_attach", res)).closest(".crm-attach-card").removeClass("empty");
					}
				}
			});
		}
	});
});