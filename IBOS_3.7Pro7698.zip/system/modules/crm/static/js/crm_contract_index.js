/**
 * Crm 合同列表页
 * @author    inaki
 * @version   $Id$
 */

$(function() {
	var Ctrt = Crm.Contract;

	// 列表选中页批量操作
	Ctrt.multiAccess = function(callback) {
		var collIds = U.getCheckedValue("contract[]", "#contract_table");
		if (!collIds) {
			Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", "warning");
		} else {
			callback && callback(collIds);
		}
	};
	// 初始化表格控件
	var contractTable = $("#contract_table").DataTable($.extend(true, {}, Ibos.settings.dataTable, {
		// --- Data
		deferLoading: 0, // 每个文件加上这一行
		ajax: Ibos.app.url('crm/contract/index'),
        language: {
            zeroRecords: '<div class="tac"><img src="static/image/common/no-info.png"></div>'
        },
		// --- Callback
		initComplete: function() {
			// Fixed: IE8下表格初始化后需要再次初始化 checkbox，否则触发不了change事件
			$(this).find('[data-name]').label();
		},
		rowCallback: function(row, data) {
			var $row = $(row);
			$row.find("label input[type='checkbox']").label();
		},
		order: [1, "desc"], // ID 倒序
		columns: [
			// 复选框
			{
				"data": "",
				"orderable": false,
				"className": "dt-checkbox-td",
				"render": function(data, type, row) {
					return '<label class="checkbox mbz"><input type="checkbox" name="contract[]" value="' + row.id + '"/></label>';
				}
			},
			// ID（隐藏）
			{
				"data": "contractid",
				"visible": false,
				"render": function(data, type, row) {
					return row.id;
				}
			},
			// 所属客户
			{
				"data": "clientName",
				"render": function(data, type, row) {
					return '<p class="mbm"><a href="' + row.homeUrl + '" class="xcm">' + row.account.name + '</a></p><p class="fss">' + row.number + '</p>';
				}
			},
			// 合同类型
			{
				"data": "type",
				"render": function(data, type, row) {
					var _tpl = '<div class="crm-memo <%= row.type.color ? \"\" : \"crm-memo-default\" %>" style="background-color: <%= row.type.color %>">' +
							'<i class="crm-memo-parts" style="background-color: <%= row.type.color %>"></i><%= row.type.name %>' +
							'</div>';

					return row.type ? $.template(_tpl, {row: row}) : "";
				}
			},
			// 合同金额
			{
				"data": "total",
				"render": function(data, type, row) {
					return '<span class="fss xco">￥' + row.total + '</span>';
				}
			},
			// 已收款
			{
				"data": "collected",
				"render": function(data, type, row) {
					return '<span class="fss">￥' + row.collected + '</span>';
				}
			},
			// 归属用户
			{
				"data": "belongUser",
				"render": function(data, type, row) {
					var _tpl = '<a href="<%= row.user.spaceUrl %>" class="avatar-circle avatar-circle-small">' +
							'<img src="<%= row.user.avt %>" />' +
							'</a> ' +
							'<span class="fss"><%= row.user.name %></span>';

					return $.template(_tpl, {row: row});
				}
			}
		]
	}));

	$("#contract_search").search(function(value) {
		contractTable.search(value).draw();
	});

	// 高级查询，替换表格数据 ajax 地址
	$(document).on("advquery", function(evt, evtData) {
		contractTable.ajax.url(Ibos.app.url('crm/contract/index') + '&' + evtData.param).load();
	});
	Crm.Query.init("#crm_filter_dropdown");
	Crm.Query.replayCondition(Ibos.app.g('query-condition'));
	Ibos.evt.add({
		// 批量共享
		"shareContracts": function() {
			Ctrt.multiAccess(function(ids) {
				Crm.showShareDialog(Ibos.app.url('crm/contract/share', {ids: ids}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						this.close();
						contractTable.draw(false);
					}
				});
			});
		},
		// 批量分配
		"assignContracts": function() {
			Ctrt.multiAccess(function(ids) {
				Crm.showAssignDialog(Ibos.app.url('crm/contract/assign', {ids: ids}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						this.close();
						contractTable.draw(false);
					}
				});
			});
		},
		// 从列表删除勾选的合同
		"removeContracts": function() {
			Ctrt.multiAccess(function(ids) {
				Ui.confirm(U.lang("CRM.REMOVE_CONTRACT_CONFIRM"), function() {
					Ctrt.op.remove(ids);
				});
			});
		}
	});

	$(Ctrt).on("ctrtremove", function(evt, evtData) {
		if (evtData.res.isSuccess) {
			contractTable.draw(false);
		}
	});
});