
/**
 * Crm 事件模块
 * @version $Id$
 */
(function () {
	var ce = {
		op: {
			// 添加事件
			addRecord: function (data, callback) {
				if (data && data.length) {
					$.post(Ibos.app.url('crm/event/add'), data, function (res) {
						callback && callback(res);
						$(ce).trigger("crmrecordadd", {data: data, res: res});
					}, "json");
				}
			},
			// 更新事件
			updateRecord: function (id, data, callback) {
				if (data && data.length) {
					$.post(Ibos.app.url('crm/event/edit'), data, function (res) {
						callback && callback(res);
						$(ce).trigger("crmrecordupdate", {id: id, data: data, res: res});
					}, "json");
				}
			},
			// 删除事件
			removeRecord: function (ids, callback) {
				if (ids) {
					$.post(Ibos.app.url('crm/event/del'), {ids: ids}, function (res) {
						callback && callback(res);
						$(ce).trigger("crmrecordremove", {ids: ids, res: res});
					}, "json");
				}
			}
		},
		_dialog: function (url, opts) {
			var _this = this;
			Ui.closeDialog("d_event_info");
			if (url) {
				Ui.ajaxDialog(url, $.extend({
					id: "d_event_info",
					title: U.lang("CRM.EVENT"),
					lock: true,
					ok: true,
					init: function(){
						var $content = this.DOM.content,
							$opp = $content.find("[name='oid']"),
							$selectOpt = $content.find("[data-node='selectedOpp']"),
							$cnt = $content.find("[name='contactid']"),
							$selectCnt = $("[data-node='selectedContact']"),
							$cntAtt = $("[data-node='contactAttach']");
						$content.on("click", "[data-node='accountAttach']", function(e){
							var param = "";
							Crm.Account.selectOne(param, function(accountId){
								var id = accountId,
									data = Ibos.app.g("crmAccounts"),
									accObj = _this._getAccountInfoById(data, id);
								$content.find("[data-node='selectedAccount']").text(accObj.name);
								$content.find("[name='cid']").val(accObj.id);

								var $selected = $content.find("[data-node='oppAttach']"),
									cdata = $selected.data("param");
								cdata.cid = id;
								$selected.attr("data-param", $.toJSON(cdata));
								$opp.val("");
								$selectOpt.text("");

								var cntdata = $cntAtt.data("param");
								cntdata.cid = id;
								$cntAtt.attr("data-param", $.toJSON(cntdata));
								$cnt.val("");
								$selectCnt.text("");
							});
						}).on("click", "[data-node='oppAttach']", function(e){
							var param = $(this).data("param");
							Crm.Opportunity.selectOne(param, function(selected){
								var data = Ibos.app.g("crmAccounts"),
									optObj = _this._getAccountInfoById(data, selected);
								$selectOpt.text(optObj.name);
								$opp.val(selected);

								var cntdata = $cntAtt.data("param");
								cntdata.oid = selected;
								$cntAtt.attr("data-param", $.toJSON(cntdata));
								$cnt.val("");
								$selectCnt.text("");

							});
						}).on("click", "[data-node='contactAttach']", function(){
							var param = $(this).data("param");
							Crm.Contact.select(param, function(selected){
								var data = Ibos.app.g("crmAccounts"),
									ctArr = _this._filterDataByIds(data, selected),
									ctStr = _this._formData(ctArr);
								$cnt.val(selected);
								$selectCnt.text(ctStr);
							});
						});
					},
					cancel: true,
					close: function () {
						$.formValidator && $.formValidator.resetTipState("eventInfo");
					}
				}, opts));
			}
		},
		_validateForm: function (ok) {
			var formData;
			if ($.formValidator.pageIsValid("eventInfo")) {
				formData = this.DOM.content.find("form").serializeArray();
				ok && ok.call(this, formData);
			}
		},
		// 通过id获取客户信息对象
		_getAccountInfoById: function(data, id){
			var acObj;
			$.each(data, function(index, el) {
				if(el.id === id){
					acObj = el;
				}
			});
			return acObj;
		},
		// 过滤数据
		_filterDataByIds: function(data, ids){
			var resultArr = [];
			$.each(data, function(index, el) {
				if($.inArray(el.id, ids) >= 0){
					resultArr.push(el);
				}
			});
			return resultArr;
		},
		// 格式化数据
		_formData: function(arr){
			var nameStr = "";
			$.each(arr, function(index, el) {
				nameStr = nameStr +  el.name + ",";
			});
			return nameStr;
		},
		// 新建事件
		add: function (ok) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/event/add'), {
				ok: function () {
					_this._validateForm.call(this, function (formData) {
						ce.op.addRecord(formData);
					});
					return false;
				}
			});
		},
		// 编辑事件
		edit: function (param, ok) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/event/edit', param), {
				ok: function () {
					_this._validateForm.call(this, function (formData) {
						ce.op.updateRecord(param.id, formData);
					});
					return false;
				}
			});
		},
		// 批量操作入口
		multiAccess: function (callback) {
			var evtId = U.getCheckedValue("event[]", "#event_table");
			if (!evtId) {
				Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", "warning");
			} else {
				callback && callback(evtId);
			}
		}
	};

	Crm.Event = ce;
})();


$(function () {
	var CrmEvent = Crm.Event;

	Ibos.evt.add({
		// 新建事件记录
		"addRecord": function () {
			CrmEvent.add();
		},
		// 编辑事件记录
		"editRecord": function (param) {
			CrmEvent.edit(param);
		}
	});

	$(CrmEvent).on({
		"crmrecordadd crmrecordupdate crmrecordremove": function (evt, evtData) {
			var res = evtData.res;
			if (res.isSuccess) {
				Ui.tip("@OPERATION_SUCCESS");
			} else {
				Ui.tip(res.msg, "danger");
			}
		},
		"crmrecordadd crmrecordupdate": function (evt, evtData) {
			var res = evtData.res;
			if (res.isSuccess) {
				var dialog = Ui.getDialog("d_event_info");
				dialog && dialog.close();
			}
		}
	});
});
