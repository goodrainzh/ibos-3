/**
 * Crm 事件列表页
 * @author    inaki
 * @version   $Id$
 */

$(function() {
	var Ce = Crm.Event;

	// 初始化表格控件
	var eventTable = $("#event_table").DataTable($.extend(true, {}, Ibos.settings.dataTable, {
		// --- Data
		deferLoading: 0, // 每个文件加上这一行
		ajax: Ibos.app.url('crm/event/index'),
        language: {
            zeroRecords: '<div class="tac"><img src="static/image/common/no-info.png"></div>'
        },
		// --- Callback
		initComplete: function() {
			// Fixed: IE8下表格初始化后需要再次初始化 checkbox，否则触发不了change事件
			$(this).find('[data-name]').label();
		},
		rowCallback: function(row, data) {
			var $row = $(row);
			$row.find("label input[type='checkbox']").label();
		},
		order: [1, "desc"], // ID 倒序
		columns: [
			// 复选框
			{
				"data": "",
				"orderable": false,
				"className": "dt-checkbox-td",
				"render": function(data, type, row) {
					return '<label class="checkbox mbz"><input type="checkbox" name="event[]" value="' + row.id + '"/></label>';
				}
			},
			// ID（隐藏）
			{
				"data": "eventid",
				"visible": false,
				"render": function(data, type, row) {
					return row.id;
				}
			},
			// 描述
			{
				"data": "content",
				"render": function(data, type, row) {
					return '<a href="javascript:;" data-action="editRecord" data-param="{&quot;id&quot;: &quot;' + row.id + '&quot;}" title="'+ row.content +'" class="xcm event-desc">' + row.content + '</a>';
				}
			},
			// 归属用户
			{
				"data": "uid",
				"render": function(data, type, row) {
					return '<span class="fss" title="'+ row.user.name +'">' + row.user.name + '</span>';
				}
			},
			// 所属客户
			{
				"data": "fullname",
				"render": function(data, type, row) {
					return '<a href="'+ Ibos.app.url("crm/client/detail", {op: "event",id: row.account.id }) +'" class="fss" title="'+ row.account.name +'">' + row.account.name + '</a>';
				}
			},
			// 销售行为
			{
				"data": "eventBehavior",
				"render": function(data, type, row) {
					var _tpl = '<div class="crm-memo <%= row.event.color ? \"\" : \"crm-memo-default\" %>" style="background-color: <%= row.event.color %>">' +
							'<i class="crm-memo-parts" style="background-color: <%= row.event.color %>"></i><%= row.event.name %>' +
							'</div>';

					return row.event ? $.template(_tpl, {row: row}) : "";
				}
			},
			// 结束时间
			{
				"data": "endTime",
				"render": function(data, type, row) {
					return '<span class="fss">' + row.endTime + '</span>';
				}
			}
		]
	}));

	$("#event_search").search(function(value) {
		eventTable.search(value).draw();
	});

	// 高级查询，替换表格数据 ajax 地址
	$(document).on("advquery", function(evt, evtData) {
		eventTable.ajax.url(Ibos.app.url('crm/event/index') + '&' + evtData.param).load();
	});
	Crm.Query.init("#crm_filter_dropdown");
	Crm.Query.replayCondition(Ibos.app.g('query-condition'));

	$(Ce).on({
		// 添加事件
		"crmrecordadd": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				eventTable.draw();
			}
		},
		// 编辑事件、删除事件
		"crmrecordupdate crmrecordremove": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				eventTable.draw(false);
			}
		}
	});


	Ibos.evt.add({
		// 共享事件信息
		"shareRecord": function() {
			Ce.multiAccess(function(ids) {
				Crm.showShareDialog(Ibos.app.url('crm/event/share', {ids: ids}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						this.close();
						eventTable.draw(false);
					}
				});
			});
		},
		// 分配事件信息
		"assignRecord": function() {
			Ce.multiAccess(function(ids) {
				Crm.showAssignDialog(Ibos.app.url('crm/event/assign', {ids: ids}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						this.close();
						eventTable.draw(false);
					}
				});
			});
		},
		// 发送邮件
		"sendMail": function() {
			if (Ibos.app.g('externalmail') != 1) {
				Ui.tip("@CRM.NOT_OPEN_EMAIL_EXTERNAL", "warning");
				return false;
			}
			Ce.multiAccess(function(ids) {
				window.location.href = Ibos.app.url('crm/event/sendmail', {ids: ids});
			});
		},
		// 批量删除事件
		"removeRecords": function() {
			Ce.multiAccess(function(ids) {
				Ui.confirm(U.lang("CRM.REMOVE_RECORDS_CONFIRM"), function() {
					Ce.op.removeRecord(ids);
				});
			});
		}
	});
});
