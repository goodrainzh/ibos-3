/**
 * Crm 事件信息
 * @version $Id$
 */

$(function () {
	// 快捷下拉选择器
	$("#crmev_account, #crmev_opportunity, #crmev_contact").ibosSelect({allowClear: true});

	var $start = $("#start_time"),
		$end = $("#end_time");
		
	// 初始化日期控件
	$start.datepicker({
		target: $end,
		pickTime: true,
		pickSeconds:false,
		format: "yyyy-mm-dd hh:ii"
	});

	// 初始化表单验证
	var	_initFormValidator = function () {
		// 延时执行以修正提示定位
		setTimeout(function () {
			$.formValidator.initConfig({
				formID: "event_info_form",
				theme: "",
				validatorGroup: "eventInfo"
			});
			// 事件内容不能为空
			$("#crmev_content").formValidator({
				onFocus: U.lang("CRM.INPUT_EVENT_CONTENT"),
				validatorGroup: "eventInfo"
			}).regexValidator({
				regExp: "notempty",
				dataType: "enum",
				onError: U.lang("CRM.INPUT_EVENT_CONTENT")
			});
		}, 0);
	};
	Crm.loadFormValidator(_initFormValidator);
});