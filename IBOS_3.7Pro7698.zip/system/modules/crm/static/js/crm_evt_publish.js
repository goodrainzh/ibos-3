/**
 * CRM 事件发布附加信息
 * @version  $Id$
 */
(function(){
	/**
	 * 事件发布 - 对话框基类
	 * @class AsoDialog
	 * @constructor
	 * @param {Element|Jquery|String} ctrl  对话框开关
	 * @param {Object} opts                 配置项
	 */
	function AsoDialog(ctrl, opts){
		var _this = this;

		this.ctrl = $(ctrl);
		this.opts = opts || {};

		this.ctrl.on("click", function(){
			_this.show();
		});
	}
	AsoDialog.prototype = {
		constructor: AsoDialog,
		// 获取对话框内容，由于有可能通过 ajax 请求，所以采取了回调的形式
		getContent: function(callback){
			callback && callback.call(this, "");
		},

		getVal: function(){ return ""; },

		hasVal: function(){ return false; },

		position: function(){
			this.dialog.DOM.wrap.position({
				of: this.ctrl,
				my: "left-10 top",
				at: "left bottom"
			});
		},

		show: function(){
			var _this = this;

			this.dialog = Ui.dialog({
				id: "d_aso",
				title: false,
				padding: "15px",
				cancel: false
			});

			this.position();

			this.getContent(function(content){
				this.dialog.content(this.content[0]);
				this.position();
			});

			$(document).on("mousedown.aso", function(evt){
				if(!$.contains(_this.dialog.DOM.wrap[0], evt.target)){
					_this.hide();
				}
			});

			this.ctrl.addClass("active");
		},

		hide: function(){
			this.dialog.close();
			$(document).off("mousedown.aso");
			this.ctrl.toggleClass("active", this.hasVal());
		}
	}

	/**
	 * 事件发布 - 关联联系人对话框
	 * @class AsoContactDialog
	 * @constructor
	 * @extends {AsoDialog}
	 * @param {Element|Jquery|String} ctrl  对话框开关
	 * @param {Object} opts                 配置项
	 */
	function AsoContactDialog(ctrl, opts){
		this._super.call(this, ctrl, opts);
	}
	Ibos.core.inherits(AsoContactDialog, AsoDialog);
	$.extend(AsoContactDialog.prototype, {
		getContent: function(callback){
			var _this = this;
			if(!this.content) {
	    		if(!this.opts.data){
	    			return false;
	    		}
				this.opts.data(function(res){
					if(res.data){
	    				_this.content = $('<div style="width: 300px; display: none;"> <div class="t mbs">选择联系人</div> <input type="text" /> </div>').appendTo(document.body);

	    				_this.select = _this.content.find("input").ibosSelect({
			    			data: $.map(res.data, function(d){
			    				return { id: d.id, text: d.name };
			    			}),
			    			width: "100%"
			    		});

			    		_this.select.on("change", function(evt){
			    			$(_this).trigger(evt);
			    		});

			    		callback && callback.call(_this, _this.content);
					}
				});
			} else {
				callback && callback.call(_this, _this.content);
			}
		},

		getVal: function(){ return this.select ? this.select.val() : ""; },

		hasVal: function(){ return $.trim(this.getVal()) !== ""; },

		reset: function(){
			this.ctrl.removeClass("active");
			if(this.select){
				this.select.select2("val", "");
			}
		}
	});


	/**
	 * 事件发布 - 关联机会对话框
	 * @class AsoOppDialog
	 * @constructor
	 * @extends {AsoDialog}
	 * @param {Element|Jquery|String} ctrl  对话框开关
	 * @param {Object} opts                 配置项
	 */
	function AsoOppDialog(ctrl, opts){
		this._super.call(this, ctrl, opts);
	}
	Ibos.core.inherits(AsoOppDialog, AsoDialog);
	$.extend(AsoOppDialog.prototype, {
		getContent: function(callback){
			var _this = this;
			if(!this.content) {
	    		if(!this.opts.data){
	    			return false;
	    		}
				this.opts.data(function(res){
					if(res.data){
	    				_this.content = $('<div style="width: 300px; display: none;"> <div class="t mbs">选择机会</div> <input type="text" /> </div>').appendTo(document.body);
	    				// 初始化快捷选择器
	    				_this.select = _this.content.find("input").ibosSelect({
			    			data: $.map(res.data, function(d){
			    				return { id: d.id, text: d.name };
			    			}),
			    			width: "100%",
			    			multiple: false,
			    			allowClear: true,
			    			placeholder: "选择机会"
			    		});

			    		callback && callback.call(_this, _this.content);
					}
				});
			} else {
				callback && callback.call(_this, _this.content);
			}
		},

		getVal: function(){ return this.select ? this.select.val() : ""; },

		hasVal: function(){ return $.trim(this.getVal()) !== ""; },

		reset: function(){
			this.ctrl.removeClass("active");
			if(this.select){
				this.select.select2("val", "");
			}
		}
	});

	/**
	 * 事件发布 - 设置时间对话框
	 * @class AsoDatetimeDialog
	 * @constructor
	 * @extends {AsoDialog}
	 * @param {Element|Jquery|String} ctrl  对话框开关
	 * @param {Object} opts                 配置项
	 */
	function AsoDatetimeDialog(ctrl, opts){
		this._super.call(this, ctrl, opts);
	}
	Ibos.core.inherits(AsoDatetimeDialog, AsoDialog);
	$.extend(AsoDatetimeDialog.prototype, {
		// 获取内容，第一次通过 opts.data 方法 ajax 加载后缓存，后续直接从页面中读取
		getContent: function(callback){
			var _this = this;
			if(!this.content) {
				if(!this.opts.data){
	    			return false;
	    		}
				this.opts.data(function(res){
					if(res){
	    				_this.content = $(res).appendTo(document.body);
	    				_this.content.find(".checkbox input").label();

	    				var $start = $('[data-node="startTime"]', this.content),
	    					$end = $('[data-node="endTime"]', this.content);

	    				// 改变“持续时间”视图
	    				var _renderInterval = function(){
	    					var startTime = $start.data("datetimepicker").getLocalDate(),
	    						endTime = $end.data("datetimepicker").getLocalDate(),
	    						iv = startTime && endTime ? endTime - startTime : 0

	    					$("strong", _this.content).html(Ibos.date.numberToTime(iv/3600000));
	    				};
	    				// 初始化日期控件
	    				$start.datepicker({
	    					target: $end,
	    					pickTime: true,
	    					pickSeconds:false,
	    					format: "yyyy-mm-dd hh:ii"
	    				});

	    				$start.on("change changeDate", _renderInterval);
	    				$end.on("change changeDate", _renderInterval);

			    		callback && callback.call(_this, _this.content);
					}
				});
			} else {
				callback && callback.call(_this, _this.content);	
			}
		},
		/**
		 * 获取有效的表单值
		 * @method getVal
		 * @return {Object} 可能的属性包括starttime, endtime, allday
		 */
		getVal: function(){
			var formData = [],
				$form;

			if(this.content && this.content.length) {
				$form = this.content.find("form");
				formData = $form.serializeArray();
			}

			return formData;
		},

		/**
		 * 是否有值，或者说值是否合法 starttime 和 endtime 都是必须的
		 * @method hasVal 
		 * @return {Boolean}
		 */
		hasVal: function(){
			var data = U.serializedToObject(this.getVal());
			return $.trim(data.begin) !== "" && $.trim(data.end) !== "";
		},

		// 重置控件
		reset: function(){
			var $start = $('[data-node="startTime"]', this.content),
				$end = $('[data-node="endTime"]', this.content),
				$allDay = $('[name="allday"]', this.content);
				currentDate = new Date;

			// 将开始时间设置为当前时间
			if($start.length){
				$start.datetimepicker("setLocalDate", currentDate);
			}

			// 线束时间设置为1天后
			if($end.length){
				currentDate.setDate(currentDate.getDate() + 1)
				$end.datetimepicker("setLocalDate", currentDate);
			}

			// 取消“全天”复选框的选中状态
			if($allDay.length){
				$allDay.label("uncheck");
			}

			this.ctrl.removeClass("active");
		}
	});

	
	/**
	 * 事件发布 - 菜单基类
	 * @class AsoMenu
	 * @constructor
	 * @param {Element|Jquery|String} ctrl  对话框开关
	 * @param {Element|Jquery|String} menu  菜单节点
	 */
	function AsoMenu(ctrl, menu){
		var _this = this;
			
		this.$ctrl = $(ctrl),
		this.$menu = $(menu);

		if(!this.$ctrl.length || !this.$menu.length){
			$.error("AsoMenu: 找不到需要的元素");
		}

		// 点击开关打开菜单
		this.$ctrl.on("click", function(){
			_this.show();
		});
	}
	AsoMenu.prototype = {
		constructor: AsoMenu,

		position: function(){
			this.$menu.position({
				of: this.$ctrl,
				my: "left top+10",
				at: "left bottom"
			})
		},

		show: function(){
			var _this = this;
			this.$menu.show();
			this.position();
			this.$ctrl.addClass("active");

			// 点击菜单以外区域则隐藏菜单
			$(document).on("mousedown.asomenu", function(e){
				if(_this.$menu[0] !== e.target && !$.contains(_this.$menu[0], e.target)){
					_this.hide();
				}
			});
		},

		hide: function(){
			this.$menu.hide();
			this.$ctrl.removeClass("active");
			$(document).off("mousedown.asomenu");
		}
	};

	/**
	 * 事件发布 - 标签菜单
	 * @class AsoTagMenu
	 * @constructor
	 * @extends {AsoMenu}
	 * @param {Element|Jquery|String} ctrl  对话框开关
	 * @param {Element|Jquery|String} menu  菜单节点
	 */
	function AsoTagMenu(ctrl, menu) {
		this._super.call(this, ctrl, menu)
		
		this.$menu.on("change", ".radio input", function(){
			$(this).closest("[data-node='submenuToggle']").parent().toggleClass("active", this.value != 0);
		});
	}
	Ibos.core.inherits(AsoTagMenu, AsoMenu);
	$.extend(AsoTagMenu.prototype, {
		getData: function(){
			var retData = [];

			$(".radio > input", this.$menu).each(function(){
				retData = retData.concat($(this).serializeArray());
			});

			return retData;
		},

		hide: function(){
			// 找到用户设置过的标签（即非默认标签）
			var nonDefault = $.grep(this.getData(), function(d){
				return d.value != "0";
			});
			// 用户已自定义标签时，按钮保持高亮状态
			this.$ctrl.toggleClass("active", !!nonDefault.length);
			this.$menu.hide();
			$(document).off("mousedown.asomenu");
		},

		reset: function(){
			$(".radio > input[value='0']", this.$menu).click();
			this.$ctrl.removeClass("active");
		}
	});

	// crm 事件发布
	function EvtPublish(textarea, btn, onpublish){
		var _this = this,
			$textarea = $(textarea),
			$btn = $(btn);

		var _isEnablePublish = function(){
			var val = $textarea.val();
			return $.trim(val) !== "" && val !== $textarea.attr("placeholder");
		}
		var _triggerPublish = function(evt){
			onpublish && onpublish.call(_this, evt, $textarea.val(), { btn: $btn, textarea: $textarea });
		}


		// 由于 IE 8 下使用 value 模拟 placeholder， 所以此处要绕开。
		$textarea.on("input propertychange", function(){
			setTimeout(function(){
				$btn.prop("disabled", !_isEnablePublish());
			}, 0);
		})
		// 支持 ctrl + enter 发布
		.on("keydown", function(evt){
			if(evt.ctrlKey && evt.which === 13 && _isEnablePublish()){
				_triggerPublish(evt);
			}
		});

		$btn.on("click", _triggerPublish);

		this.reset = function(){
			$textarea.val("").triggerHandler("input");
		}
	};

	$.extend(Crm, {
		AsoTagMenu: AsoTagMenu,
		AsoContactDialog: AsoContactDialog,
		AsoDatetimeDialog: AsoDatetimeDialog,
		AsoOppDialog: AsoOppDialog,
		EvtPublish: EvtPublish
	});
})();
