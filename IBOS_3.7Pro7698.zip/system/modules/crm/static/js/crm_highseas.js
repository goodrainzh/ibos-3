/**
 * Crm 公海设置
 * @author  inaki
 * @version $Id$
 */
$(function () {
	var Highseas = {
		op: {
			// 新增公海
			add: function (data, callback) {
				$.post(Ibos.app.url('crm/highseas/add'), data, function (res) {
					callback && callback(res);
				}, "json");
			},
			// 更新公海信息
			update: function (data, callback) {
				$.post(Ibos.app.url('crm/highseas/edit'), data, function (res) {
					callback && callback(res);
				}, "json");
			},
			// 移除公海
			remove: function (ids, callback) {
				$.post(Ibos.app.url('crm/highseas/del'), {ids: ids}, function (res) {
					callback && callback(res);
				}, "json");
			}
		},
		// 初始公海信息表单
		_initForm: function (form) {
			$(form.name).focus();
			$(form.scope).userSelect({
				data: Ibos.data.get()
			});
			// 客户数上限必须为有效数字
			$(form.max).on("change", function () {
				if( !$.trim(this.value) ){
					this.value = '';
				}else if (!U.regex(this.value, 'int')) {
					this.value = Ibos.string.toPositiveInt(this.value);
				}
			});
		},
		// 验证公海信息表单
		_validateForm: function (form) {
			if ($.trim(form.name.value) === "") {
				Ui.tip("@CRM.INPUT_HIGHSEAS_NAME", "warning");
				$(form.name).focus();
				return false;
			}
			return true;
		},
		// 打开新建公海对话框
		add: function (ok) {
			var _this = this;
			Ui.closeDialog("d_highseas_info");
			Ui.ajaxDialog(Ibos.app.url('crm/highseas/add'), {
				id: "d_highseas_info",
				title: U.lang("CRM.ADD_HIGHSEAS"),
				padding: "20px",
				lock: true,
				ok: function () {
					var $form = this.DOM.content.find("form"), formData;
					if (_this._validateForm($form[0])) {
						formData = $form.serializeArray();
						ok && ok.call(this, formData);
					}
					return false;
				},
				cancel: true,
				init: function () {
					_this._initForm(this.DOM.content.find("form")[0]);
				}
			});
		},
		// 打开编辑公海对话框
		edit: function (param, ok) {
			var _this = this;
			param = param || {};
			Ui.closeDialog("d_highseas_info");
			Ui.ajaxDialog(Ibos.app.url('crm/highseas/edit', param), {
				id: "d_highseas_info",
				title: U.lang("CRM.EDIT_HIGHSEAS"),
				lock: true,
				padding: "20px",
				ok: function () {
					var $form = this.DOM.content.find("form"), formData;
					if (_this._validateForm($form[0])) {
						formData = $form.serializeArray();
						$.each(param, function (name, value) {
							formData.push({name: name, value: value});
						});
						ok && ok.call(this, formData);
					}
					return false;
				},
				cancel: true,
				init: function () {
					_this._initForm(this.DOM.content.find("form")[0]);
				}
			});
		}
	};

	var HighseasList = function (container, opts) {
		this._super.apply(this, arguments);
	};
	HighseasList.prototype = {
		add: function (param) {
			var _this = this;
			Highseas.add(function (data) {
				var dialog = this;
				Highseas.op.add(data, function (res) {
					if (res.isSuccess) {
						_this.addItem(res.data);
						Ui.tip("@OPERATION_SUCCESS");
						dialog.close();
					} else {
						Ui.tip(res.msg, "danger");
					}
				});
			});
		},
		edit: function (param) {
			var _this = this;
			// 默认公海不能编辑
			if (param.id == "1") {
				return false;
			}
			Highseas.edit(param, function (data) {
				var dialog = this;
				Highseas.op.update(data, function (res) {
					if (res.isSuccess) {
						_this.updateItem(param.id, res.data);
						Ui.tip("@OPERATION_SUCCESS");
						dialog.close();
					} else {
						Ui.tip(res.msg, "danger");
					}
				});
			});
		},
		remove: function (param) {
			var _this = this;
			Ui.confirm(U.lang("CRM.REMOVE_HIGHSEAS_CONFIRM"), function () {
				Highseas.op.remove(param.id, function (res) {
					if (res.isSuccess) {
						_this.removeItem(param.id);
						Ui.tip("@OPERATION_SUCCESS");
					} else {
						Ui.tip(res.msg, "danger");
					}
				});

			});
		}
	};

	Ibos.core.inherits(HighseasList, Crm.MncardList);
	new HighseasList("#highseas_list", {tpl: "tpl_highseas_item"});
});