/**
 *  CRM 首页 js
 *  @version $Id$
 */
(function () {
	var CrmIndex = {
		op: {
			// 获取对应 常用菜单项 的未读数
			getNewCount: function (icons, callback) {
				var iconStr = $.isArray(icons) ? icons.join(",") : icons;
				if (iconStr) {
					// @Debug:
					$.get(Ibos.app.url("main/api/loadNew", {random: Math.random()}), {
						module: iconStr
					}, callback, "json");
				}
			}
		},

		renderWidget: function(name, data, callback) {
			var modBox = MBox.get(name);
			if(modBox && data) {
				$.each(data, function(tabName, tabData) {
					if(tabData) {
						modBox.setContent(tabData, tabName);
					}
					callback && callback();
				});
			}
		},

		// 渲染面板上的widget内容
		renderWidgets: function (data) {
			var that = this;
			if (data) {
				// 循环模块数据
				$.each(data, function(modName, modData) {
					that.renderWidget(modName, modData);
				});
			}
		},

		loadWidget: function(widgetNames) {
			var that = this,
				index = 0;
			widgetNames = $.isArray(widgetNames) ? widgetNames : widgetNames.split(',');

			function _load(modName, tabName) {
				$.get(Ibos.app.url('crm/index/' + tabName, { range: Ibos.app.g('dataRange') }))
				.done(function(res) {
					var data = {};
					data[tabName] = res;
					that.renderWidget(modName, data, function(){
						if( index < widgetNames.length - 1 ){
							index++;
							loadData();
						}
					});
				});
			}
			loadData();
			function loadData(){
				var name = widgetNames[index];
					settings = that.getWidgetSetting( name );
				if( settings.tab && settings.tab.length ){
					$.each(settings.tab, function(i, tabItem) {
						_load(name, tabItem.name);
					});
				}else{
					_load(name, name);
				}
			}
		},

		// 写入常用菜单的未读数
		updateNewCount: function (name, count) {
			var type = typeof name;
			var _set = function (name, count) {
				count = parseInt(count, 10);
				if (count) {
					$("[data-bubble='" + name + "']").text(count).show();
				} else {
					$("[data-bubble='" + name + "']").empty().hide();
				}
			};

			// 当为对象时，假设为键值对
			if (type === "object") {
				for (var prop in name) {
					if (name.hasOwnProperty(prop)) {
						_set(prop, name[prop]);
					}
				}
			} else if (type === "string") {
				_set(name, count);
			}
		},
		// 打开 widget 管理对话框
		showWidgetDialog: function () {
			var that = this;
			var data = {
				oa: [],
				crm: []
			};
			var installedWidget = this.getInstalledWidget();
			var selectedWidget = widgetStorage.get();
			// 将已安装可用的部件分为 oa 和 crm 两类
			for (var i = 0; i < installedWidget.length; i++) {
				var type = installedWidget[i].type;
				// 如果是当前在面板上显示的widget部件，则增加 selected 为 true
				// 方便模板解析时默认勾选
				installedWidget[i].selected = ($.inArray(installedWidget[i].name, selectedWidget) !== -1);

				data[type] && data[type].push(installedWidget[i]);
			}

			Ui.dialog({
				id: "d_wd_manager",
				title: false,
				content: $.template("tpl_wd_manager", {wd: data, len: Math.max(data.oa.length, data.crm.length)}),
				padding: 0,
				lock: true,
				init: function () {
					var $content = this.DOM.content;
					// 初始化复选框
					$content.find(".checkbox > input").label()
							.on("change", function () {
								if (this.checked) {
									addWidget(this.value, that.getWidgetSetting(this.value));
									that.loadWidget(this.value);
								} else {
									removeWidget(this.value);
								}
							});
				},
			});
		},
		// 打开数据范围设置对话框
		showRangeDialog: function () {
			Ui.dialog({
				id: "d_data_range",
				title: false,
				content: $.template("tpl_dr", {range: Ibos.app.g("dataRange")}),
				lock: true,
				init: function () {
					this.DOM.content.on("click", ".crm-dr-disk", function () {
						var range = +Ibos.app.g("dataRange");
						range = range >= 3 ? 0 : range + 1;
						$(this).attr("class", "crm-dr-disk crm-dr-d" + range);
						Ibos.app.s("dataRange", range);
					});
				},
				close: function () {
					var range = Ibos.app.g("dataRange");
					window.location.href = Ibos.app.url('crm/index/index')+"&range=" + Ibos.app.g("dataRange");
					Ibos.app.s("dataRange", range);
				},
				padding: 0
			});
		},
		// 加载 echarts 图表插件
		loadEchart: function (callback) {
			// 避免重复加载 echarts
			if (typeof echarts !== "undefined") {
				callback && callback();
			} else if ($.data(window, "loadingEchart")) {
				var timer = setInterval(function () {
					if (typeof echarts !== "undefined") {
						callback && callback();
						clearInterval(timer);
					}
				}, 100);
			} else {
				$.getScript(Ibos.app.getStaticUrl("/js/lib/echarts/echarts.min.js"), callback)
						.done(function () {
							$.removeData(window, "loadingEchart");
						});
				$.data(window, "loadingEchart", true);
			}
		},

		getInstalledWidget: function() {
			return Ibos.app.g('widget') || [];
		},

		getInstalledWidgetName: function() {
			return $.map(this.getInstalledWidget(), function (w) {
				return w.name || '';
			});
		},

		getWidgetSetting: function(name) {
			return $.grep(this.getInstalledWidget(), function (setting) {
				return setting.name === name;
			})[0];
		}
	};

	var widgetStorage = {
		key: "crm_widget",
		get: function () {
			return Ibos.local.get(this.key);
		},
		set: function (value) {
			value = value || [];
			return Ibos.local.set(this.key, value);
		},
		add: function (value) {
			var result = this.get() || [];
			result.push(value);
			return this.set(result);
		},
		remove: function (value) {
			var result = this.get() || [],
					index = $.inArray(value, result);
			if (index !== -1) {
				result.splice(index, 1);
				return this.set(result)
			}
		},
		has: function (value) {
			var result = this.get() || [];
			return $.inArray(value, result) !== -1;
		},
		clear: function () {
			Ibos.local.remove(this.key);
		}
	};

	var addWidget = function (name, settings) {
		if (!widgetStorage.has(name)) {
			// 生成 MBox 实例并插入到面板中
			var mbox = new MBox(name, $.extend({
				onremove: function (name) {
					// 模块移除时，删除对应存储，uncheck对应项
					widgetStorage.remove(name);
				}
			}, settings));
			mbox.appendTo("#wd_container")
			widgetStorage.add(name);
		}
	};
	var removeWidget = function (name) {
		if (widgetStorage.has(name)) {
			var mbox = MBox.get(name);
			mbox && mbox.remove();
			widgetStorage.remove(name);
		}
	};

	$(function () {
		// 初始化时，读取本地存储，确认已安装的模块
		var selectedWidget = widgetStorage.get();
		// 若没有选中任何 widget，则判断为重置默认
		if (!selectedWidget) {
			selectedWidget = CrmIndex.getInstalledWidgetName();
		}
		widgetStorage.set([]);
		// 根据本地缓存的数据生成 widget
		if (selectedWidget && selectedWidget.length) {
			$.each(selectedWidget, function (i, w) {
				addWidget(w, CrmIndex.getWidgetSetting(w));
			});
		}

		var refresh = function () {
			// 渲染各 widget 的内容
			CrmIndex.loadWidget(selectedWidget);

			// 更新各模块未读消息数
			CrmIndex.op.getNewCount(Ibos.app.g("menu"), function (res) {
				CrmIndex.updateNewCount(res);
			});
		};

		refresh();
		// 定时自动刷新
		setInterval(refresh, 60000);
		// 初始化拖拽排序功能
		$("#wd_container").sortable({handle: ".mbox-header", tolerance: "pointer"})
				.on("sortupdate", function (evt, data) {
					var srg = [];
					$("#wd_container .mbox").each(function () {
						var name = $.attr(this, "data-name");
						srg.push(name);
						widgetStorage.set(srg);
					});
				});
		//
		Ibos.evt.add({
			// 打开 widget 管理对话框
			showWidgetDialog: function () {
				CrmIndex.showWidgetDialog();
			},
			// 打开 数据范围设置对话框
			showRangeDialog: function () {
				CrmIndex.showRangeDialog();
			},
			totop: function () {
				Ui.scrollToTop();
			},
			resetWidget: function () {
				widgetStorage.clear();
				window.location.reload();
			}
		});
	});

	Crm.Index = CrmIndex;
})();

