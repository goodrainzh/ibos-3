/**
 * Crm 线索模块
 * @author  inaki
 * @version $Id$
 */
(function() {
	var Lead = {
		// 数据交互
		op: {
			// 获取线索完整信息
			getLead: function(id, callback) {
				if (id) {
					$.get(Ibos.app.url('crm/lead/index'), {leadid: id}, function(res) {
						// @Debug:
						res = {
							subject: "网站客户",
							account: "广东欧派家居集团有限公司",
							contact: "陈先生",
							record: [
								{content: "今年内暂时没考虑，发了邮件", datetime: "2014-2-13 12:00"},
								{content: "网站负责人不在，网站内容有点乱", datetime: "2014-2-13 12:00"}
							],
							tel: "82529888",
							phone: "15919127974",
							email: "oupai@qq.com",
							address: "广州市白云区广花三路366号",
							site: "http://www.oppein.com/"
						};
						callback && callback(res);
					}/*, "json"*/)
				}
			},
			validateLead: function(data) {
				var parsed;
				if (!data || !data.length) {
					return false;
				}
				parsed = U.serializedToObject(data);
				if ($.trim(parsed.client) === "") {
					return false;
				}
				return true;
			},
			addLead: function(data, callback) {
				if (this.validateLead(data)) {
					$.post(Ibos.app.url('crm/lead/add'), data, function(res) {
						callback && callback(res);
						$(Lead).trigger("leadadd", {data: data, res: res});
					}, "json");
				}
			},
			updateLead: function(id, data, callback) {
				if (this.validateLead(data)) {
					data.push({name: "id", value: id});
					$.post(Ibos.app.url('crm/lead/edit'), data, function(res) {
						callback && callback(res);
						$(Lead).trigger("leadupdate", {id: id, data: data, res: res});
					}, "json");
				}
			},
			// 删除线索
			removeLead: function(ids, callback) {
				if (ids) {
					$.post(Ibos.app.url('crm/lead/del'), {ids: ids}, function(res) {
						callback && callback(res);
						$(Lead).trigger("leadremove", {ids: ids, res: res});
					}, "json");
				}
			},
			// 转化线索
			transLead: function(data, callback) {
				$.post(Ibos.app.url('crm/lead/trans'), data, function(res) {
					callback && callback(res);
					$(Lead).trigger("leadtrans", {data: data, res: res});
				}, "json");
			},
			// 保存线索为新客户
			transLeadToAccout: function(data, callback) {
				$.post(Ibos.app.url('crm/lead/transConfirm'), data, function(res) {
					callback && callback(res);
					$(Lead).trigger("leadtransaccount", {data: data, res: res});
				}, "json");
			}
		},
		// 对话框基本配置
		_dialog: function(url, opts) {
			Ui.closeDialog("d_lead_info");
			if (url) {
				Ui.ajaxDialog(url, $.extend({
					id: "d_lead_info",
					title: U.lang("CRM.LEAD"),
					width: 560,
					padding: 0,
					lock: true,
					okVal: U.lang("SAVE"),
					init: function() {
						if ($.fn.placeholder) {
							this.DOM.content.find("[placeholder]").placeholder();
						}
					},
					close: function() {
						$.formValidator && $.formValidator.resetTipState("leadInfo");
					},
					cancel: true,
					ok: true
				}, opts));
			}
		},
		// 视图上验证表单
		_validateForm: function(ok) {
			var formData;
			if ($.formValidator.pageIsValid("leadInfo")) {
				formData = this.DOM.content.find("form").serializeArray();
				ok && ok.call(this, formData);
			}
		},
		// 打开添加线索对话框
		addLead: function() {
			var _this = this;
			this._dialog(Ibos.app.url('crm/lead/add'), {
				ok: function() {
					_this._validateForm.call(this, function(formData) {
						_this.op.addLead(formData);
					});
					return false;
				}
			});
		},
		// 打开编辑线索对话框
		editLead: function(param) {
			var _this = this;
			this._dialog(Ibos.app.url('crm/lead/edit', param || {}), {
				ok: function() {
					_this._validateForm.call(this, function(formData) {
						_this.op.updateLead(param.id, formData);
					});
					return false;
				}
			});
		},
		// 打开转换线索对话框
		transLead: function(param) {
			param = param || {};
			Ui.ajaxDialog(Ibos.app.url('crm/lead/trans', param || {}), {
				id: "d_trans_lead",
				title: U.lang("CRM.TRANS_LEAD"),
				padding: 0,
				okVal: U.lang("SAVE"),
				cancel: true,
				width: 420,
				init: function() {
					var $content = this.DOM.content;
					// 初始化checkbox radio;
					$content.find(".checkbox input, .radio input").label();
					// 切换百叶窗效果
					$content.find(".radio input").on("change", function() {
						if (this.checked) {
							var $opt = $(this).closest(".crmld-trans-opt");
							$opt.find(".crmld-trans-opt-body").slideDown(200);
							$opt.siblings().find(".crmld-trans-opt-body").slideUp(200);
						}
					});
					$content.find(":checkbox[name='transtype[opportunity]']").on("change", function() {
						$content.find(".subject-wrap").slideToggle(200);
					});
				},
				ok: function() {
					var $content = this.DOM.content,
						$oppCheckbox = $content.find(":checkbox[name='transtype[opportunity]']"),
						isChecked = $oppCheckbox.prop("checked"),
						$subject = $content.find("[name='subject']"),
						subject = $subject.val(),
						formData = $content.find("form").serializeArray();
					if(isChecked && !subject){
						$subject.blink().focus();
						return false;
					}
					formData.push({name: "id", value: param.id});
					Lead.op.transLead(formData);
					return false;
				}
			});
		},
		// 打开检测重复对话框
		showCheckRepeatDialog: function(param) {
			var _this = this;
			Ui.ajaxDialog(Ibos.app.url('crm/lead/checkrepeat', param || {}), {
				id: "d_ckrp_lead",
				title: U.lang("CRM.CHECK_REPEAT_ACCOUNT"),
				padding: 0,
				okVal: U.lang("SAVE"),
				ok: function() {
					var formData = this.DOM.content.find("form").serializeArray();
					formData.push({name: "leadid", value: param.leadId});
					formData.push({name: 'subject', value: U.entity.unescape(param.subject)});
					// 保存线索为新客户
					_this.op.transLeadToAccout(formData);
					return false;
				},
				cancel: true
			});
		}
	};
	Crm.Lead = Lead;
})();

$(function() {
	var Lead = Crm.Lead;
	$(Lead).on({
		"leadadd leadupdate leadremove leadtransaccount": function(evt, evtData) {
			var res = evtData.res;
			if (res.isSuccess) {
				Ui.tip("@OPERATION_SUCCESS");
			} else {
				Ui.tip(res.msg, "danger");
			}
		},
		"leadadd leadupdate": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				Ui.getDialog("d_lead_info").close();
			}
		},
		"leadtrans": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				Ui.tip("@OPERATION_SUCCESS");
				Ui.getDialog("d_trans_lead").close();
			}
		},
		"leadtransaccount": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				Ui.getDialog("d_ckrp_lead").close();
			}
		}
	});

	Ibos.evt.add({
		"addLead": function() {
			Lead.addLead();
		},
		"editLead": function(param) {
			Lead.editLead(param);
		}
	});
});

