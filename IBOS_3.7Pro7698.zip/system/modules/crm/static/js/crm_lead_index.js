/**
 * CRM 线索首页
 * @author  inaki
 * @version $Id$
 */

$(function() {
	var Lead = Crm.Lead;
	// 批量操作入口
	Lead.multiAccess = function(callback) {
		var leadIds = U.getCheckedValue("lead[]", "#lead_table");
		if (!leadIds) {
			Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", "warning");
		} else {
			callback && callback(leadIds);
		}
	};
	// 初始化表格控件
	var leadTable = $("#lead_table").DataTable($.extend(true, {}, Ibos.settings.dataTable, {
		// --- Data
		deferLoading: 0, // 每个文件加上这一行
		ajax: Ibos.app.url('crm/lead/index'),
        language: {
            zeroRecords: '<div class="tac"><img src="static/image/common/no-info.png"></div>'
        },
		// --- Callback
		initComplete: function() {
			// Fixed: IE8下表格初始化后需要再次初始化 checkbox，否则触发不了change事件
			$(this).find('[data-name]').label();
		},
		rowCallback: function(row, data) {
			$(row).find("label input[type='checkbox']").label();
		},
		order: [1, "desc"], // ID 倒序
		// --- Column		
		columns: [
			// 复选框
			{
				"data": "",
				"orderable": false,
				"className": "dt-checkbox-td",
				"render": function(data, type, row) {
					return '<label class="checkbox mbz"><input type="checkbox" name="lead[]" value="' + row.leadid + '"/></label>';
				}
			},
			// ID（隐藏）
			{
				"data": "leadid",
				"visible": false,
				"render": function(data, type, row) {
					return row.leadid;
				}
			},
			// 客户名称
			// @Todo: 联系方式
			{
				"data": "client",
				"render": function(data, type, row) {
					var _tpl = '<div>' +
							'<a href="javascript:;" class="xcm" data-action="editLead" data-param="{&quot;id&quot;: &quot;<%= row.leadid %>&quot;}"><%= row.client %></a> ' +
							'<% if(row.isNew) { %>' +
							'<span class="label label-warning label-small"><%= U.lang("CRM.NEW_ASSIGN")%></span>' +
							'<% } %>' +
							'</div>' +
							'<div class="cps-info fss">' +
							'<% if(row.contact) { %> <span><i class="o16 om-user-simple"></i> <%= row.contact %></span> <% } %>' +
							'<% if(row.tel) { %>' +
							'<a href="javascript:;" class="ilsep" data-action="phoneTo" data-param="{&quot;number&quot;: &quot;<%= row.tel %>&quot;}" title="<%= U.lang(\"CRM.PHONE_TO\")%>">' +
							'<i class="o16 om-phone-simple"></i> <%= row.tel %>' +
							'</a>' +
							'<% } %>' +
							'<% if(row.email) { %>' +
							'<a href="#<%= row.email %>" class="ilsep" title="<%= U.lang(\"CRM.SEND_MAIL\")%>">' +
							'<i class="o16 om-email-simple"></i> <%= row.email %>' +
							'</a>' +
							'<% } %>' +
							'</div>';

					return $.template(_tpl, {row: row});
				}
			},
			// 线索状态
			{
				"data": "status",
				"type": "numeric",
				"render": function(data, type, row) {
					var _tpls = [
						'<div class="crm-memo crm-memo-default"><i class="crm-memo-parts"></i><%= row.statusText %></div>',
						'<div class="crm-memo" style="background-color: #91CE31;"><i class="crm-memo-parts" style="background-color: #91CE31;"></i><%= row.statusText %></div>'
					];
					return $.template(_tpls[row.status], {row: row});
				}
			},
			// 归属用户
			{
				"data": "uid",
				"render": function(data, type, row) {
					var _tpl = '<a href="<%= row.user.spaceUrl %>" class="avatar-circle avatar-circle-small">' +
							'<img src="<%= row.user.avt %>" />' +
							'</a> ' +
							'<span class="fss"><%= row.user.name %></span>';
					return $.template(_tpl, {row: row});
				}
			},
			// 更新时间
			{
				"data": "updatetime",
				"render": function(data, type, row) {
					var _tpl = '<span class="fss dt-opbar"><%= row.updateTime %></span>' +
							'<div class="dt-h-opbar">' +
							'<% if(row.status!=1) { %><a href="javascript:;" class="o-crm-trans" data-action="transLead" data-param="{&quot;id&quot;: &quot;<%= row.leadid %>&quot;}" title="<%= U.lang(\"CRM.TRANS_LEAD\") %>"></a><% } %>' +
							'<% if(row.acc.accAssign) { %><a href="javascript:;" class="o-crm-assign mls" data-action="assignLead" data-param="{&quot;id&quot;: &quot;<%= row.leadid %>&quot;}" title="<%= U.lang(\"CRM.ASSIGN\") %>"></a><% } %>' +
							'</div>';
					return $.template(_tpl, {row: row});
				}
			}
		]
	}));

	// 搜索事件
	$("#lead_search").search(function(value) {
		leadTable.search(value).draw();
	});

	// 操作菜单项变更
	$("#lead_table").on("change", "[name='lead[]']", function(evt) {
		var $checked = U.getChecked("lead[]", evt.delegateTarget);
		$("#lead_operation_menu").find("[role='singleOperation']").toggle($checked.length <= 1);
	});

	// 数据交互事件
	$(Lead).on({
		"leadadd": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				leadTable.draw();
			}
		},
		"leadupdate leadremove": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				leadTable.draw(false);
			}
		},
		// 转换线索
		"leadtrans leadtransaccount": function(evt, evtData) {
			var res = evtData.res;
			if (res.isSuccess) {
				leadTable.draw(false);
				// 线索转化出错时
			} else {
				// 出错类型为客户重复, 弹出客户重复处理对话框
				if (res.errorType = "existedClient") {
					Lead.showCheckRepeatDialog(res.data);
					Ui.closeDialog("d_trans_lead");
				} else {
					Ui.tip(res.msg, "danger");
					return false;
				}
			}
		}
	});

	// 高级查询
	$(document).on("advquery", function(evt, evtData) {
		leadTable.ajax.url(Ibos.app.url('crm/lead/index') + '&' + evtData.param).load();
	});
	Crm.Query.init("#crm_filter_dropdown");
	Crm.Query.replayCondition(Ibos.app.g('query-condition'));

	Ibos.evt.add({
		"removeLeads": function() {
			Lead.multiAccess(function(leadIds) {
				Ui.confirm(U.lang("CRM.REMOVE_LEAD_CONFIRM"), function() {
					Lead.op.removeLead(leadIds);
				});
			});
		},
		// 操作菜单上的转换线索
		"transSelectedLead": function() {
			var leadId = U.getCheckedValue("lead[]", "#lead_table");
			if (!leadId) {
				Ui.tip("@SELECT_ONE_ITEM", "warning");
				return false;
			}
			Lead.transLead({id: leadId});
		},
		// 转换线索
		"transLead": function(param) {
			Lead.transLead(param);
		},
		// 共享线索信息
		"shareLeads": function() {
			Lead.multiAccess(function(leadIds) {
				Crm.showShareDialog(Ibos.app.url('crm/lead/share', {ids: leadIds}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						Ui.tip("@OPERATION_SUCCESS", "success");
						this.close();
					}
				});
			});
		},
		// 批量分配线索
		"assignLeads": function() {
			Lead.multiAccess(function(leadIds) {
				Crm.showAssignDialog(Ibos.app.url('crm/lead/assign', {ids: leadIds}), function(res) {
					// 此处 this 指向 dialog 实例
					if (res.isSuccess) {
						this.close();
						leadTable.draw(false);
					}
				});
			});
		},
		// 分配线索
		"assignLead": function(param) {
			Crm.showAssignDialog(Ibos.app.url('crm/lead/assign', {ids: param.id}), function(res) {
				// 此处 this 指向 dialog 实例
				if (res.isSuccess) {
					this.close();
					leadTable.draw(false);
				}
			});
		}
	});
});

