/**
 * Crm 线索信息
 * @version $Id$
 * @anthor  inaki
 */

$(function () {
	// 初始化归属用户
	var initUid = $("#lead_belong_input").val();
	var belongModel = new Crm.BelongModel(initUid);
	var belongView = new Crm.BelongView(belongModel, {
		display: "#lead_belong_display",
		button: "#lead_belong_btn",
		input: "#lead_belong_input"
	});
	var belongController = new Crm.BelongController(belongModel, belongView);
	belongController.setUid(initUid);

	// 切换内容隐藏表单验证提示内容
	$("#lead_info_tab").on("shown", '[data-toggle="tab"]', function(evt) {
		$.formValidator.resetTipState("leadInfo");
	});

	// 初始化表单验证
	var _initFormValidator = function () {
		// 延时执行以修正提示定位
		setTimeout(function () {
			$.formValidator.initConfig({
				formID: "lead_info_form",
				theme: "",
				validatorGroup: "leadInfo"
			});
			// 线索相关客户不能为空
			$("#lead_account").formValidator({
				onFocus: U.lang("CRM.INPUT_LEAD_ACCOUNT"),
				validatorGroup: "leadInfo"
			}).regexValidator({
				regExp: "notempty",
				dataType: "enum",
				onError: U.lang("CRM.INPUT_LEAD_ACCOUNT")
			});
			// 线索相关联系人不能为空
			$("#lead_contact").formValidator({
				onFocus: U.lang("CRM.INPUT_LEAD_CONTACT"),
				validatorGroup: "leadInfo"
			}).regexValidator({
				regExp: "notempty",
				dataType: "enum",
				onError: U.lang("CRM.INPUT_LEAD_CONTACT")
			});
			// 线索联系人电话格式验证
			$("#lead_phone").formValidator({
				onFocus: U.lang("CRM.INPUT_LEAD_PHONE"),
				empty: true,
				validatorGroup: "leadInfo"
			}).regexValidator({
				regExp: "^0\\d{2,3}-?\\d{7,8}$",
				dataType: "number",
				onError: U.lang("CRM.SURE_CORRECT_PHONE")
			});
			// 线索联系人手机格式验证
			$("#lead_mobile").formValidator({
				onFocus: U.lang("CRM.INPUT_LEAD_MOBILE"),
				empty: true,
				validatorGroup: "leadInfo"
			}).regexValidator({
				regExp: "mobile",
				dataType: "enum",
				onError: U.lang("CRM.SURE_CORRECT_MOBILE")
			});
			// 线索联系人地址格式验证
			$("#lead_email").formValidator({
				onFocus: U.lang("CRM.INPUT_LEAD_EMAIL"),
				empty: true,
				validatorGroup: "leadInfo"
			}).regexValidator({
				regExp: "email",
				dataType: "enum",
				onError: U.lang("CRM.SURE_CORRECT_EMAIL")
			});
			$("#lead_website").formValidator({
				onFocus: U.lang("CRM.INPUT_LEAD_WEBSITE"),
				empty: true,
				validatorGroup: "leadInfo"
			}).regexValidator({
				regExp: "url",
				dataType: "enum",
				onError: U.lang("CRM.SURE_CORRECT_WEBSITE")
			});
		}, 0);
	};

	Crm.loadFormValidator(_initFormValidator);
});