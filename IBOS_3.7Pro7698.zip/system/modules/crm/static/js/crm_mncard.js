/**
 * Crm 卡片式内容列表通用基类
 * @author  inaki
 * @version $Id$
 */
Crm.MncardList = function (container, opts) {
	this.$container = $(container);
	opts = opts || {};
	this.tpl = opts.tpl || "";
	this.bindEvents();
};
Crm.MncardList.prototype = {
	constructor: Crm.MncardList,
	// 绑定列表相关的事件
	bindEvents: function () {
		var _this = this;

		this.$container.bindEvents({
			"click .mncard-plus": function () {
				_this.add(Ibos.app.getEvtParams(this));
			},
			"click .mncard[data-id]": function () {
				_this.edit(Ibos.app.getEvtParams(this));
			},
			"click .mn-cond-btn": function (evt) {
				var $item = $(this).closest(".mncard");
				_this.remove(Ibos.app.getEvtParams($item[0]));
				// 删除按钮在卡片范围内，需要阻止冒泡，否则会触发编辑事件
				evt.stopPropagation();
			}
		});
	},
	// 修正数据，此方法在这里没有任何意义
	// 有必要时子类可以重写
	correctData: function (data) {
		return data;
	},
	// 添加一项至列表
	addItem: function (data) {
		var $lastItem = this.$container.children(":last");
		return $.tmpl(this.tpl, this.correctData(data)).insertBefore($lastItem);
	},
	// 更新列表中某项的视图
	updateItem: function (id, data) {
		var $item = this.$container.children("[data-id='" + id + "']");

		if ($item.length) {
			return $.tmpl(this.tpl, this.correctData(data)).replaceAll($item);
		}

		return false;
	},
	// 删除列表中的一项
	removeItem: function (id) {
		var $item = this.$container.children("[data-id='" + id + "']");

		if ($item.length) {
			return $item.remove();
		}

		return false;
	},
	add: $.noop,
	edit: $.noop,
	remove: $.noop
};
