/**
 * Crm 关闭机会
 * @author  inaki
 * @version $Id$
 */

$(function(){
	var $oppCloseForm = $("#opp_close_form");

	// 转换失败时不允许生成合同
	$(".radio input", $oppCloseForm).label();

	$("[data-toggle='switch']", $oppCloseForm).iSwitch();

	$("#actual_enddate").datepicker({
		pickTime: true,
		pickSeconds: false,
		format: "yyyy-mm-dd hh:ii"
	});

	$oppCloseForm.bindEvents({
		// 强制实际收入为数字
		"change [name='actualincome']": function(){
			var value = this.value.replace(/\,/g, "");
			this.value = U.regex(value, "currency") ? 
						value : 
					Ibos.string.addCommas(Ibos.string.toPositiveDecimals(value, 2));
		},

		// 转换失败时不允许生成合同
		"change .radio input": function(){
			if(this.value == "0") {
				$("#generate_contract").iSwitch("turnOff").iSwitch("setDisabled")
			} else if(this.value == "2") {
				$("#generate_contract").iSwitch("setEnabled")
			}
		}
	})
});