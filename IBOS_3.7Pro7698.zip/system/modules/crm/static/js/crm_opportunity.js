/**
 * Crm 机会模块
 * @version $Id$
 */

(function() {
	var Opp = {
		op: {
			// 机会信息验证
			_validateOppData: function(data) {
				var parsed;
				if (!data || !data.length) {
					return false;
				}
				parsed = U.serializedToObject(data);
				if ($.trim(parsed.subject) === "") {
					return false;
				}
				return true;
			},
			// 添加机会
			add: function(data, callback) {
				if (this._validateOppData(data)) {
					$.post(Ibos.app.url('crm/opportunity/add'), data, function(res) {
						callback && callback(res);
						$(Opp).trigger("oppadd", {data: data, res: res});
					}, "json");
				}
			},
			// 更新机会信息
			update: function(id, data, callback) {
				if (this._validateOppData(data)) {
					data.push({name: "id", value: id});
					$.post(Ibos.app.url("crm/opportunity/edit"), data, function(res) {
						callback && callback(res);
						$(Opp).trigger("oppupdate", {id: id, data: data, res: res});
						window.location.reload();
					}, "json");
				}
			},
			// 删除机会
			remove: function(ids, callback) {
				if (ids) {
					$.post(Ibos.app.url('crm/opportunity/del'), {ids: ids}, function(res) {
						callback && callback(res);
						$(Opp).trigger("oppremove", {ids: ids, res: res});
					}, "json");
				}
			},
			// 获取机会
			get: function(param, callback) {
				if ($.isFunction(param)) {
					callback = param;
					param = null;
				}
				$.post(Ibos.app.url('crm/opportunity/select'), param, function(res) {
					callback && callback(res);
					// 作为全局数据缓存
					Ibos.app.s("opportunity", res.data);
				}, "json");
			},
			// 恢复快照
			restoreSnap: function(param, callback) {
				if (param && param.id) {
					$.post(Ibos.app.url("crm/opportunity/restoresnap"), param, function(res) {
						callback && callback(res);
					}, "json");
				}
			},
			// 验证签单条件方案数据
			_validateSchemeData: function(data) {
				if (data) {
					if (!$.trim(data.name)) {
						Ui.tip("@CRM.INPUT_SCHEME_NAME", "warning");
						return false;
					}
					if (!U.isPositiveInt(data.limit)) {
						Ui.tip("@CRM.DISPLAY_COUNT_INCORRECT", "warning");
						return false;
					}
					return true;
				}

				return false;
			},
			// 添加签单条件方案
			addScheme: function(data, callback) {
				if (this._validateSchemeData(data)) {
					$.post(Ibos.app.url('crm/opportunity/presetcondition', {op: 'add'}), data, function(res) {
						callback && callback(res);
						if (res.isSuccess) {
							$(Opp).trigger("schemeadd", res.data);
						}
					}, "json");
				}
			},
			// 更新签单条件方案
			updateScheme: function(id, data, callback) {
				if (this._validateSchemeData(data)) {
					data.id = id;
					$.post(Ibos.app.url('crm/opportunity/presetcondition', {op: 'edit'}), data, function(res) {
						callback && callback(res);
						if (res.isSuccess) {
							$(Opp).trigger("schemeupdate", res.data);
						}
					}, "json");
				}
			},
			// 移除签单条件组
			removeScheme: function(id, callback) {
				if (id) {
					$.post(Ibos.app.url("crm/opportunity/deletepresetparam"), {id: id}, function(res) {
						res = {isSuccess: true};
						callback && callback(res);
						if (res.isSuccess) {
							$(Opp).trigger("schemeremove", {id: id});
						}
					}/*, "json"*/);
				}
			},
			getScheme: function(id, callback) {
				if (id) {
					$.get(Ibos.app.url('crm/opportunity/presetcondition', {op: 'get'}), {id: id}, function(res) {
						callback && callback(res);
					}, "json");
				}
			},
			// 关闭机会（将机会转为成功或失败状态）
			closeOpp: function(data, callback) {
				if (data && data.length) {
					$.post(Ibos.app.url('crm/opportunity/closeopp'), data, function(res) {
						// @Debug:
						res = {isSuccess: true};
						callback && callback(res);
					}/*, "json"*/);
				}
			},
			// 更新机会进度
			updateProgress: function(param, callback) {
				if (param && param.id) {
					$.post(Ibos.app.url('crm/opportunity/edit', {'op': 'field', 'field': 'tag'}), param, function(res) {
						callback && callback(res);
					}, "json");
				}
			},
			// 完成、取消完成签单条件
			finishCond: function(param, callback) {
				if (param && param.id) {
					$.post(Ibos.app.url('crm/opportunity/edit', {'op': 'field', 'field': 'cond'}), param, function(res) {
						callback && callback(res);
					}, "json");
				}
			},
			// 更新成交概率
			updateProbability: function(param, callback) {
				if (param && typeof param.value !== "undefined") {
					$.post(Ibos.app.url('crm/opportunity/edit', {'op': 'field', 'field': 'chance'}), param, function(res) {
						callback && callback(res);
					}, "json");
				}
			},
			// 复制机会
			copyOpp: function(param, callback) {
				if (param && param.id) {
					$.post("?", param, function(res) {
						// @Debug:
						res = {isSuccess: true};
						callback && callback(res);
						$(Opp).trigger("oppcopy", {param: param, res: res});
					}/*, "json"*/);
				}
			},
			// 完成机会
			finishOpp: function(param, callback) {
				if (param && param.id) {
					$.post("?", param, function(res) {
						// @Debug:
						res = {isSuccess: true};
						callback && callback(res);
						$(Opp).trigger("oppfinish", {param: param, res: res});
					}/*, "json"*/);
				}
			},
			// 签单条件提交
			sendSingCond: function(param){
				var url = Ibos.app.url("crm/opportunity/condition");
				return $.post(url, param, $.noop);
			}
		},
		_dialog: function(url, opts) {
			var _this = this;
			Ui.closeDialog("d_opportunity_info");
			if (url) {
				Ui.ajaxDialog(url, $.extend({
					id: "d_opportunity_info",
					title: U.lang("CRM.OPPORTUNITY_INFO"),
					width: 600,
					padding: 0,
					lock: true,
					init: function(){
						var $content = this.DOM.content,
							$contact = $content.find("[name='contactidS']"),
							$selectedCon = $content.find("[data-node='selectedContact']");
						$content.on("click", "[data-node='accountAttach']", function(e){
							var param = "";
							Crm.Account.selectOne(param, function(accountId){
								var id = accountId,
									data = Ibos.app.g("crmAccounts"),
									accObj = _this._getAccountInfoById(data, id);
								$content.find("[data-node='selectedAccount']").text(U.entity.unescape(accObj.name));
								$content.find("[name='cid']").val(accObj.id);

								var $selected = $content.find("[data-node='contactAttach']"),
									cdata = $selected.data("param");
								cdata.cid = id;
								$selected.attr("data-param", $.toJSON(cdata));
								$contact.val("");
								$selectedCon.text("");
							});
						}).on("click", "[data-node='contactAttach']", function(e){
							var param = $(this).data("param");
							Crm.Contact.select(param, function(selected){
								var data = Ibos.app.g("contacts"),
									ctArr = _this._getContactByCids(data, selected),
									ctStr = _this._formData(ctArr);
								$contact.val(selected);
								$selectedCon.text(ctStr);
							});
						});
					},
					ok: true,
					cancel: true,
					close: function() {
						$.formValidator && $.formValidator.resetTipState("oppInfo");
					}
				}, opts));
			}

		},
		_validateForm: function(ok) {
			var formData;
			if ($.formValidator && $.formValidator.pageIsValid("oppInfo")) {
				formData = this.DOM.content.find("form").serializeArray();
				ok && ok.call(this, formData);
			}
		},
		_getAccountInfoById: function(data, id){
			var acObj;
			$.each(data, function(index, el) {
				if(el.id === id){
					acObj = el
				}
			});
			return acObj;
		},
		_getContactByCids: function(data, ids){
			var cnObj = [];
			$.each(data, function(index, el) {
				if($.inArray(el.id, ids) >= 0){
					cnObj.push(el);
				}
			});
			return cnObj;
		},
		_formData: function(arr){
			var nameStr = "";
			$.each(arr, function(index, el) {
				nameStr = nameStr +  U.entity.unescape(el.name) + ",";
			});
			return nameStr;
		},
		// 新建机会
		add: function(param, ok) {
			var _this = this;
			this._dialog(Ibos.app.url("crm/opportunity/add", param), {
				ok: function() {
					_this._validateForm.call(this, function(formData) {
						Opp.op.add(formData);
					});
					return false;
				}
			});
		},
		// 编辑机会
		edit: function(param, ok) {
			var _this = this;
			this._dialog(Ibos.app.url("crm/opportunity/edit", param), {
				ok: function() {
					_this._validateForm.call(this, function(formData) {
						Opp.op.update(param.id, formData);
					});
					return false;
				}
			});
		},
		// 选择机会对话框
		selectOne: function(param, ok) {
			var _this = this,
				dialog = Ui.ajaxDialog(Ibos.app.url("crm/opportunity/select"), {
					id: "d_select_opportunity",
					title: U.lang("CRM.SELECT_OPPORTUNITY"),
					padding: 0,
					ok: false,
					init: function(){
						// _this.op.get($.extend({'formhash': Ibos.app.g('formhash')}, param), function(res) {
							// var accounts = res.data;
							var bcb = new Crm.BnCardBox({
								container: "#opp_bncard_list",
								page: "#select_opp_pn",
								search: "#select_opp_search"
							}, {
								tpl: "tpl_opp_card",
								params: $.extend({'formhash': Ibos.app.g('formhash')}, param),
								op: _this.op.get
							});
							$("#opp_bncard_list").on("click", "[data-node-type='bncard']", function() {
								var selected = $(this).data("id");
								ok && ok(selected);
								Ui.getDialog("d_select_opportunity").close();
							});
						// });
					},
					close: function(){
						Ibos.app.s("bnCards", null);
						Ibos.app.s("crmAccounts", null);
					},
					cancel: function(){
						Ibos.app.s("bnCards", null);
						Ibos.app.s("crmAccounts", null);
					},
					lock: true
				});
			dialog.opParams = param;
		},
		// 显示签单条件管理对话框
		showCondScheme: function() {
			Ui.closeDialog("d_sign_scheme");
			Ui.ajaxDialog(Ibos.app.url('crm/opportunity/presetparam'), {
				id: "d_sign_scheme",
				title: U.lang("CRM.SIGN_CONDITION_MANAGE"),
				// lock: true,
				padding: "20px"
			});
		},
		// 显示新建、编辑、查看签单条件对话框
		showCondInfo: function(param, ok) {
			param = param || {};
			Ui.closeDialog("d_sign_info");
			Ui.ajaxDialog(Ibos.app.url('crm/opportunity/presetcondition', param), {
				id: "d_sign_info",
				title: U.lang("CRM.SETUP_SIGN_CONDITION"),
				padding: 0,
				ok: ok || true,
				okVal: U.lang("SAVE"),
				cancel: true
			});
		},
		// 显示关闭机会对话框
		showCloseDialog: function(param, ok) {
			param = param || {};
			Ui.closeDialog("d_close_opp");
			Ui.ajaxDialog(Ibos.app.url('crm/opportunity/closeopp', param), {
				id: "d_close_opp",
				title: U.lang("CRM.TRANSACTION_DATA"),
				padding: "20px",
				ok: ok || true,
				okVal: U.lang("SAVE"),
				cancel: true
			});
		},
		// 批量操作入口
		multiAccess: function(callback) {
			var oppIds = U.getCheckedValue("opportunity[]", "#opportunity_table");
			if (!oppIds) {
				Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", "warning");
			} else {
				callback && callback(oppIds);
			}
		}
	};
	Crm.Opportunity = Opp;
})();

$(function() {
	var Opp = Crm.Opportunity;

	$(Opp).on({
		"oppadd oppupdate oppremove oppcopy oppfinish": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				Ui.tip("@OPERATION_SUCCESS");
			} else {
				Ui.tip(evtData.res.msg, "danger");
			}
		},
		"oppadd oppupdate": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				Ui.getDialog("d_opportunity_info").close();
			}
		}
	});

	Ibos.evt.add({
		// 添加机会
		"addOpp": function(param) {
			Opp.add(param);
		},
		// 编辑机会
		"editOpp": function(param) {
			Opp.edit(param);
		},
		// 完成、取消完成 签单条件
		"finishCond": function(param, elem) {
			var finished = $(this).hasClass("active");
			Opp.op.finishCond($.extend({finish: !finished}, param),
					function(res) {
						if (res.isSuccess) {
							$(elem).toggleClass("active", !finished);
						}
					});
		}
	});

	
	$(".open_finish").click(function(){
		var $finish = $("#acc_finish_list");
		$finish.slideToggle();                                         
	});	
	$(".open_fail").click(function(){
		var $fail = $("#acc_fail_list");
		$fail.slideToggle();
	});
});
