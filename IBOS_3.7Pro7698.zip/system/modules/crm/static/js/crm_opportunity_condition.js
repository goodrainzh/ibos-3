var Opp = Crm.Opportunity;

var loadProjectSelect = {
    $container: $("#cond_load_project"),
    tpl: "",
    init: function () {
        var _this = this;
        // 监听签单条件预设方案的变化
        $(Opp).off("schemeadd schemeupdate schemeremove").on({
            "schemeadd": function (evt, evtData) {
                _this.$container.append($.template('<option value="<%=id%>"><%=name%></option>', {
                    id: evtData.id,
                    name: evtData.name
                }));
            },
            "schemeupdate": function (evt, evtData) {
                _this.$container.find("option[value='" + evtData.id + "']").text(evtData.name);
            },
            "schemeremove": function (evt, evtData) {
                _this.$container.find("option[value='" + evtData.id + "']").remove();
            }
        });
        _this.$container.on("change", function (res) {
            if (this.value) {
                Opp.op.getScheme(this.value, function (res) {
                    if (res.isSuccess) {
                        $(_this).trigger("loadprojectchange", {conds: res.data});
                    }
                });
            }
        });
    }
};
loadProjectSelect.init();

// 签单条件方案设置
$("#setup_scheme").on("click", function () {
    Opp.showCondScheme();
});

$(loadProjectSelect).on("loadprojectchange", function (evt, data) {
    var tpl = "";
    if (data.conds && data.conds.length) {
        for (var i = 0; i < data.conds.length; i++) {
            tpl += $.template("tpl_opp_cond", {index: i+1, value: data.conds[i]});
        }
        tpl +=  '<li class="control-group">'+
                    '<div class="controls">'+
                        '<a href="javacript:;" class="xcbu mls" data-node="addItem">增加签单条件</a>'+
                    '</div>'+
                '</li>';
        $("#sign_cond_list").html(tpl);
    }
});

// 新增签单条件
var signCond = {
    $container: $("#sign_cond_list"),
    tpl: "tpl_opp_cond",
    rowLen : 0,
    init: function () {
        var _this = this;
        _this.rowLen = _this.$container.find("li").length;
        this.$container.bindEvents({
            "click [data-node='addItem']": function(evt){
                _this.addRow({
                    index: _this.rowLen,
                    value: ""
                });
                _this.rowLen++;
            },
            "click .o-close": function () {
                _this.removeRow($(this).closest(".control-group"));
            }
        });
    },
    // 增加一行联系方式
    addRow: function (data) {
        var $newRow = $.template(this.tpl, data);
        this.$container.find("li:last-child").before($newRow);
    },
    // 移除一行联系方式
    removeRow: function ($row) {
        var $prevRow = $row.prev();
        // 移除一行后，焦点放到被移除行的上一行中
        if ($prevRow.length) {
            $prevRow.find("[name='extendvalue[]']").focus();
            // 若已没有可用行，则焦点放到新建行中
        } else {
            this.$container.find('[name="extendvalue[]"]').focus();
        }
        $row.remove();
    }
};
signCond.init();
