/**
 * Crm 机会动态页
 * @author 		inaki
 * @version 	$Id$
 */
$(function() {
	var Opp = Crm.Opportunity;
	// 状态按钮 hover 时改变内容
	var oldContent = "";
	$(document).on({
		"mouseenter": function() {
			var $elem = $(this), status = $.attr(this, "data-opp-status"); // Ibos.app.g("oppStatus")
			oldContent = $elem.html();
			// 在“已成交”、“已失败” 状态下，可以重启机会
			if (status == "1" || status == "2") {
				$elem.html('<i class="o-opp-loop-g"></i> ' + U.lang("CRM.RESTART_OPPORTUNITY"));
				// 在“执行中”状态下， 可以关闭机会
			} else if (status == "0") {
				$elem.html('<i class="o-opp-chi-g"></i> ' + U.lang("CRM.CLOSE_OPPORTUNITY"));
			}
		},
		"mouseleave": function() {
			$(this).html(oldContent);
			oldContent = "";
		}
	}, ".opp-status-btn");

	// 简易漏斗
	var OppFunnel = function(element, data) {
		$element = $(element);
		var _this = this;
		var _template = '<ul class="opp-funnel-list">' +
				'<% for(var i = 0; i < data.length; i++) { %>' +
				'<li title="<%= data[i].name %>">' +
				'<% if(i !== data.length - 1) { %>' +
				'<div class="opp-funnel-line"></div>' +
				'<% } %>' +
				'</li>' +
				'<% } %>' +
				'</ul>' +
				'<div class="opp-funnel-mask"></div>' +
				'<div class="opp-funnel-mask-bt"></div>';

		if (data && data.length) {
			this.data = data;
			$element.html($.template(_template, {data: data}));
			this.$list = $element.find(".opp-funnel-list");
			this.$mask = $element.find(".opp-funnel-mask");
			this.$btMask = $element.find(".opp-funnel-mask-bt");
			$.each(data, function(i, d) {
				if (d.selected) {
					_this.setStep(i + 1);
					return false;
				}
			});
		}
		;
	};
	// 设置漏斗高亮位置
	OppFunnel.prototype.setStep = function(step) {
		var data = this.data;
		step = step || 0;
		if (step > data.length) {
			return;
		}
		var $items = this.$list.find(">li");
		var nh, mkh, bmkh;
		if (step === 0) {
			nh = 100 / data.length;
			$items.height(nh + "%").removeClass("active");
		} else {
			nh = 100 / (data.length + 1);
			$items.height(nh + "%").removeClass("active").eq(step - 1).height(nh * 2 + "%").addClass("active");
		}
		bmkh = step == data.length ? nh * 2 : nh;
		mkh = 100 - bmkh;
		this.$mask.height(mkh + "%");
		this.$btMask.height(bmkh + "%").css("top", mkh + "%");
	};
	// 初始化执行中状态下的脚本
	if (Ibos.app.g("oppStatus") == "0") {
		var $progressSelect = $("#progress_menu");
		// 根据步骤数据初始化漏斗
		var of = new OppFunnel("#opp_funnel", $progressSelect.find("option").map(function() {
			return {
				name: this.text,
				value: this.value,
				selected: this.selected
			};
		}).get());
		// 机会进度伪选择框
		$progressSelect.pSelect().on("change", function() {
			of.setStep(this.selectedIndex + 1);
			Opp.op.updateProgress({value: this.value, id: Ibos.app.g("oppId")}, function(res) {
				if (res.isSuccess) {
					Ui.tip("@OPERATION_SUCCESS");
				} else {
					Ui.tip(res.msg, "danger");
				}
			});
		});
		// 成交概率
		var $oppPbb = $("#opp_probability"), probability = $oppPbb.attr("data-value");
		$oppPbb.slider({range: "min", value: probability, step: 10})
				.on("slide", function(evt, data) {
					$("#opp_probability_display").html(data.value + "%");
				})
				.on("slidechange", function(evt, data) {
					$("#opp_probability_display").html(data.value + "%");
					Opp.op.updateProbability({value: data.value, id: Ibos.app.g("oppId")}, function(res) {
						if (res.isSuccess) {
							Ui.tip("@OPERATION_SUCCESS");
						} else {
							Ui.tip(res.msg, "danger");
						}
					});
				});
	}
	Ibos.evt.add({
		// 更改机会状态
		"changeOppStatus": function() {
			var status = $.attr(this, "data-opp-status");
			// 重启机会，直接跳转刷新
			if (status == "1" || status == "2") {
				window.location.href = Ibos.app.url('crm/opportunity/detail', {id: Ibos.app.g("oppId"), opt: 'restart'});
				// 关闭机会
			} else if (status == "0") {
				Opp.showCloseDialog({id: Ibos.app.g("oppId")}, function() {
					var dialog = this, $form = this.DOM.content.find("form"), formData = $form.serializeArray();
					formData.push({name: 'id', value: Ibos.app.g("oppId")});
					Opp.op.closeOpp(formData, function(res) {
						if (res.isSuccess) {
							Ui.tip("@OPERATION_SUCCESS");
							dialog.close();
							window.location.reload();
						} else {
							Ui.tip(res.msg, "danger");
						}
					});
					return false;
				});
			}
		},
		// 上传附件
		"openUploadDialog": function() {
			Ibos.uploadDialog({
				upload_url: Ibos.app.url('crm/opportunity/attach'),
				post_params: {id: Ibos.app.g("oppId")},
				custom_settings: {
					success: function(file, res) {
						var dyAttachment = $("#dy_attachment");
						dyAttachment.prepend($.template("tpl_attach", res)).closest(".crm-attach-card").removeClass("empty");
						if( dyAttachment.children().length > 5 ){
							dyAttachment.children(".media:last").remove();
						}
					}
				}
			});
		},
		// 编辑签单条件
	    editSignCond: function(param, elem){
			var url = Ibos.app.url("crm/opportunity/condition", param);
	        Ui.ajaxDialog(url ,{
	            title: Ibos.l("CRM.EDIT_SIGN_CONDITION"),
	            width: 580,
				lock: true,
	            ok: function(){
					var _this = this,
						$parent = this.DOM.content,
						tpl = "",
						$input = $parent.find("[name='signcond[]']");
						$parent.find("[name='id']").val(param.id),
						isReg = true;
					var data = $parent.find("form").serializeArray();

					$.each($input, function(i, item){
						if( $.trim(item.value) === '' ){
							$(item).blink().focus();
							isReg = false;
							return false;
						}
						isReg = true;
					});
					if(isReg){
						Opp.op.sendSingCond(data).done(function(res){
							if( res.isSuccess ){
								for (var i = 0; i < res.data.condition.length; i++) {
					                tpl += $.template("tpl_cond_list", res.data.condition[i]);
					            }
								$(".opp-panel .opp-c-list").html( tpl );
								_this.close();
							}
							Ui.tip(res.msg, res.isSuccess? "" : "danger");
						});
					}
					return false;
	            },
	            cancel: true
	        });
	    }
	});
});
