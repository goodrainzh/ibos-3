/**
 * Crm 机会列表
 * @author  	inaki
 * @version 	$Id$
 */

$(function() {
    var Opp = Crm.Opportunity;
    // 初始化表格控件
    var opportunityTable = $("#opportunity_table").DataTable($.extend(true, {}, Ibos.settings.dataTable, {
        // --- Data
        deferLoading: 0, // 每个文件加上这一行
        ajax: Ibos.app.url('crm/opportunity/index'),
        language: {
            zeroRecords: '<div class="tac"><img src="static/image/common/no-info.png"></div>'
        },
        // --- Callback
        initComplete: function() {
            // Fixed: IE8下表格初始化后需要再次初始化 checkbox，否则触发不了change事件
            $(this).find('[data-name]').label();
        },
        rowCallback: function(row, data) {
            var $row = $(row);
            $row.find("label input[type='checkbox']").label();
        },
        order: [1, "desc"], // ID 倒序

        columns: [
            // 复选框
            {
                "data": "",
                "orderable": false,
                "className": "dt-checkbox-td",
                "render": function(data, type, row) {
                    return '<label class="checkbox mbz"><input type="checkbox" name="opportunity[]" value="' + row.id + '"/></label>';
                }
            },
            // ID（隐藏）
            {
                "data": "oid",
                "visible": false,
                "render": function(data, type, row) {
                    return row.id;
                }

            },
            // 状态
            {
                "data": "status",
                "type": "numberic",
                "className": "xac",
                "render": function(data, type, row) {
                    var _tpls = [
                        '<a href="javascript:;" class="crm-spot crm-spot-blue" title="<%= row.statusText %>"><i class="o-opp-sandglass"></i></a>',
                        '<a href="javascript:;" class="crm-spot crm-spot-green" title="<%= row.statusText %>"><i class="o-opp-handshake"></i></a>',
                        '<a href="javascript:;" class="crm-spot crm-spot-gray" title="<%= row.statusText %>"><i class="o-opp-chi"></i></a>'
                    ];

                    return $.template(_tpls[row.status], {row: row});
                }
            },
            // 机会主题
            {
                "data": "subject",
                "render": function(data, type, row) {
                    return '<a href="' + row.homeUrl + '" class="xcm opp-sub-ellipsis" title="' + row.name + '">' + row.name + '</a>';
                }
            },
            // 归属用户
            {
                "data": "uid",
                "render": function(data, type, row) {
                    var _tpl = '<a href="<%= row.user.spaceUrl %>" class="avatar-circle avatar-circle-small">' +
                            '<img src="<%= row.user.avt %>" />' +
                            '</a> ' +
                            '<span class="fss"><%= row.user.name %></span>';
                    return row.user ? $.template(_tpl, {row: row}) : '';
                }
            },
            // 预算金额
            {
                "data": "income",
                "render": function(data, type, row) {
                    return '<span class="xco"><strong class="ffmy">￥</strong>' + row.income + '</span>';
                }
            },
            // 机会进度
            {
                "data": "process",
                "render": function(data, type, row) {
                    return '<span class="crm-num">' + row.progress.index + '</span> <span class="ilsep fss">' + row.progress.text + '</span>';
                }
            },
            // 创建日期
            {
                "data": "createtime",
                "render": function(data, type, row) {
                    return '<span class="fss">' + row.createTime + '</span>';
                }
            }
        ]
    }));


    $("#opportunity_search").search(function(value) {
        opportunityTable.search(value).draw();
    });


    // 操作菜单项变更
    $("#opportunity_table").on("change", "[name='opportunity[]']", function(evt) {
        var $checked = U.getChecked("opportunity[]", evt.delegateTarget);
        $("#opp_operation_menu").find("[role='singleOperation']").toggle($checked.length <= 1);
    });


    // 高级查询，替换表格数据 ajax 地址
    $(document).on("advquery", function(evt, evtData) {
        opportunityTable.ajax.url(Ibos.app.url('crm/opportunity/index') + '&' + evtData.param).load();
    });
    Crm.Query.init("#crm_filter_dropdown");
    Crm.Query.replayCondition(Ibos.app.g('query-condition'));
    $(Opp).on({
        "oppadd ": function(evt, evtData) {
            if (evtData.res.isSuccess) {
                opportunityTable.draw();
            } else {
                Ui.tip(evtData.res.msg, "danger");
            }
        },
        "oppfinish oppremove": function(evt, evtData) {
            if (evtData.res.isSuccess) {
                opportunityTable.draw(false);
            }
        }
    });


    Ibos.evt.add({
        // 复制选中机会
        "copySelectedOpp": function() {
            var oppId = U.getCheckedValue("opportunity[]", "#opportunity_table");
            if (!oppId) {
                Ui.tip("@SELECT_ONE_ITEM", "warning");
                return false;
            }
            Opp.add({copy: oppId});
        },
        // 完成机会
        "finishOpps": function() {
            Opp.multiAccess(function(oppIds) {
                Opp.op.finishOpp({id: oppIds});
            });
        },
        // 批量删除机会
        "removeOpps": function() {
            Opp.multiAccess(function(oppIds) {
                Ui.confirm(U.lang("CRM.REMOVE_OPP_CONFIRM"), function() {
                    Opp.op.remove(oppIds);
                });
            });
        },
        // 发送邮件
        "sendMail": function() {
            if (Ibos.app.g('externalmail') != 1) {
                Ui.tip("@CRM.NOT_OPEN_EMAIL_EXTERNAL", "warning");
                return false;
            }
            Opp.multiAccess(function(ids) {
                window.location.href = Ibos.app.url('crm/opportunity/sendmail', {ids: ids});
            });
        },
        // 共享机会信息
        "shareOpp": function() {
            Opp.multiAccess(function(oppIds) {
                Crm.showShareDialog(Ibos.app.url('crm/opportunity/share', {ids: oppIds}), function(res) {
                    // 此处 this 指向 dialog 实例
                    if (res.isSuccess) {
                        this.close();
                    }
                });
            });
        },
        // 分配机会信息
        "assignOpp": function() {
            Opp.multiAccess(function(oppIds) {
                Crm.showAssignDialog(Ibos.app.url('crm/opportunity/assign', {ids: oppIds}), function(res) {
                    // 此处 this 指向 dialog 实例
                    if (res.isSuccess) {
                        this.close();
                        opportunityTable.draw(false);
                    }
                });
            });
        }
    });
});
