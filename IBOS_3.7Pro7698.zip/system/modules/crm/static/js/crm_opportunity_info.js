/**
 * Crm 机会信息
 * @version $Id$
 */
$(function () {
	var Opp = Crm.Opportunity;

	// 机会共享
	$("#opp_share_tab").on("shown", function () {
		Crm.loadShare("#opp_share", Ibos.app.url('crm/opportunity/share'), Ibos.app.getEvtParams(this));
	});

	$("#opp_info_tab").on("shown", '[data-toggle="tab"]', function (evt) {
		$.formValidator.resetTipState("oppInfo");
	});
	// 初始化归属用户
	var initUid = $("#belong_input").val();
	var belongModel = new Crm.BelongModel(initUid);
	var belongView = new Crm.BelongView(belongModel, {
		display: "#belong_info",
		button: "#update_belong_btn",
		input: "#belong_input"
	});
	var belongController = new Crm.BelongController(belongModel, belongView);
	belongController.setUid(initUid);


	// 初始化快照功能
	if (Crm.SnapModel) {
		var snapModel = new Crm.SnapModel({url: Ibos.app.url('crm/opportunity/snap')});
		var snapView = new Crm.SnapView(snapModel, {
			content: "#opp_snap_body",
			select: "#opp_snap_id",
			prevBtn: "#opp_snap_prev",
			nextBtn: "#opp_snap_next"
		});
		var snapCtrl = new Crm.SnapController(snapModel, snapView);
	}

	// 恢复快照
	$("#opp_snap_restore").on("click", function () {
		var id = snapModel.getVal();
		Opp.op.restoreSnap({id: id}, function (res) {
			if (res.isSuccess) {
				Ui.closeDialog("d_opportunity_info");
				Ui.tip("@CRM.RESTORE_SNAP_SUCCESS");
				window.location.reload();
			} else {
				Ui.tip(res.msg, "warning");
				return false;
			}
		});
	});
	// 成交机率
	var $probabilityInput = $("#probability_value"), $probabilityDisplay = $("#probability_display");
	$("#probability_slider").slider({
		range: 'min',
		value: +$probabilityInput.val() || 0,
		step: 10
	}).on({
		"slidechange": function (evt, data) {
			$probabilityInput.val(data.value);
			$probabilityDisplay.html(data.value + "%");
		},
		"slide": function (evt, data) {
			$probabilityDisplay.html(data.value + "%");
		}
	});
	// 预期结束日期选择
	$("#expect_enddate").datepicker({
		startDate: new Date,
	});
	// 客户、联系人快速选择框
	$("#opp_account").ibosSelect();
	$("#opp_contact").ibosSelect({allowClear: true});


	// 小数数值自动修正
	$(document).on("change", "[data-decimals]", function() {
		var digits = $.attr(this, "data-digits") || 2,
			value = this.value.replace(/\,/g, "");
		this.value = U.regex(value, "currency") ?
				value :
				Ibos.string.addCommas(Ibos.string.toPositiveDecimals(value, digits));
	});

	// 客户改变时，改变查看链接
	$("#opp_account").on("change", function () {
		$("#view_account_info").attr("href", Ibos.app.url('crm/client/detail', {id: this.value}));
	}).triggerHandler("change");

	// 初始化表单验证
	var _initFormValidator = function () {
		// 延时执行以修正提示定位
		setTimeout(function () {
			$.formValidator.initConfig({
				formID: "opp_info_form",
				theme: "",
				validatorGroup: "oppInfo"
			});
			// 机会主题不能为空
			$("#opp_subject").formValidator({
				onFocus: U.lang("CRM.INPUT_OPP_SUBJECT"),
				validatorGroup: "oppInfo"
			}).regexValidator({
				regExp: "notempty",
				dataType: "enum",
				onError: U.lang("CRM.INPUT_OPP_SUBJECT")
			});
		}, 0);
	};
	Crm.loadFormValidator(_initFormValidator);

});