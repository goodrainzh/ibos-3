/**
 * Crm 通用查询配置
 * @author inaki
 * @version $Id$
 */

$(function () {
	// 查询设置操作
	var query = Crm.query = {
		containerSelector: "#crm_query_dialog",
		op: {
			// 添加条件方案
			add: function (data, callback) {
				$.post(Ibos.app.url('crm/query/add'), data, callback, "json");
			},
			// 更新条件方案
			update: function (data, callback) {
				$.post(Ibos.app.url('crm/query/edit'), data, callback, "json");
			},
			// 删除条件方案
			remove: function (data, callback) {
				$.post(Ibos.app.url('crm/query/del'), data, callback, "json");
			},
			moveup: function (data, callback) {
				data.op = "moveup";
				$.post(Ibos.app.url('crm/query/editgroup'), data, callback, "json");
			},
			movedown: function (data, callback) {
				data.op = "movedown";
				$.post(Ibos.app.url('crm/query/editgroup'), data, callback, "json");
			},
			// 设置为默认条件方案
			setDefault: function (data, callback) {
				data.op = "setDefault";
				$.post(Ibos.app.url('crm/query/editgroup'), data, callback, "json");
			}
		},
		// 获取当前选中条件
		getSelected: function () {
			return $(".crm-query-list li.selected", this.containerSelector);
		},
		// 选中查询条件
		select: function (item) {
			var $item = $(item), $container;
			if ($item.length) {
				$container = $(this.containerSelector);
				// 更新选中样式，只允许单选
				$container.find(".crm-query-list li").removeClass("selected");
				$item.addClass("selected");
				// 如果选中系统默认的条目，则隐藏编辑和删除按钮
				$("#edit_query, #remove_query").prop("disabled", $item.is('[data-node-type="systemQuery"]'));
			}
		},
		getGroupId: function () {
			return $(this.containerSelector).attr("data-groupid");
		},
		// 上移查询条件
		moveup: function () {
			var $item = this.getSelected(), $prevItem = $item.prev();
			if ($item.length && $prevItem.length) {
				this.op.moveup({groupid: this.getGroupId(), id: $item.attr("data-id")}, function (res) {
					$item.insertBefore($prevItem);
				});
			}
		},
		// 下移查询条件
		movedown: function () {
			var $item = this.getSelected(), $nextItem = $item.next();
			if ($item.length && $nextItem.length) {
				this.op.movedown({groupid: this.getGroupId(), id: $item.attr("data-id")}, function (res) {
					$item.insertAfter($nextItem);
				});
			}
		},
		// 移除查询条件
		remove: function () {
			var _this = this, $item = this.getSelected();
			if ($item.length) {
				Ui.confirm(U.lang("CRM.REMOVE_CONDITION_CONFIRM"), function () {
					_this.op.remove({id: $item.attr("data-id")}, function (res) {
						if (res.isSuccess) {
							$item.remove();
						}
					});
				});
			}
		},
		// 打开添加条件窗口
		toAdd: function () {
			var _this = this, groupid = this.getGroupId();
			Crm.showCondDialog(Ibos.app.url('crm/query/add', {groupid: groupid}), {}, function (data) {
				var dialog = this;
				data.groupid = groupid;
				data.formhash = Ibos.app.g('formhash');
				_this.op.add(data, function (res) {
					if (res.isSuccess) {
						dialog.close();
						Crm.showQueryDialog({groupid: groupid});
					}
				});
				return false;
			});
		},
		// 打开编辑条件窗口
		toEdit: function () {
			var _this = this, $item = this.getSelected(), groupid = this.getGroupId();
			if ($item.length) {
				var id = $item.attr("data-id");
				Crm.showCondDialog(Ibos.app.url('crm/query/edit', {groupid: groupid, id: id}), {}, function (data) {
					var dialog = this;
					data.id = id;
					data.groupid = groupid;
					data.formhash = Ibos.app.g('formhash');
					_this.op.update(data, function (res) {
						if (res.isSuccess) {
							dialog.close();
							Crm.showQueryDialog({groupid: groupid});
						}
					});
					return false;
				});
			}
		},
		// 设置默认条件
		setDefault: function ($item) {
			param = {
				id: $item.attr("data-id"),
				groupid: this.getGroupId()
			};
			this.op.setDefault(param, function () {
				$item.addClass("active").siblings().removeClass("active");
			});
		},
		init: function () {
			var _this = this;
			// 事件绑定
			$(this.containerSelector).bindEvents({
				"click .crm-query-list li": function () {
					_this.select(this);
				},
				"click #moveup_query": function (evt) {
					_this.moveup();
				},
				"click #movedown_query": function () {
					_this.movedown();
				},
				"click #remove_query": function () {
					_this.remove();
				},
				"click #add_query_quick,#add_query": function () {
					_this.toAdd();
				},
				"click #edit_query": function () {
					_this.toEdit();
				},
				"click .crm-query-setdefault": function (evt) {
					var $item = $(this).closest("li");
					query.setDefault($item);
					evt.stopPropagation();
				}
			});
		}
	};
	query.init();
});