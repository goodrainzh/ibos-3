/**
 * Crm 产品服务
 * @author   inaki
 * @version  $Id$
 */

$(function() {
	var product = {
		op: {
			add: function(data) {
				$.post(Ibos.app.url('crm/product/add'), data, function(res) {
					$(product).trigger("productadd", {data: data, res: res});
				}, "json");
			},
			update: function(id, data) {
				data.push({name: "id", value: id});
				$.post(Ibos.app.url('crm/product/edit'), data, function(res) {
					$(product).trigger("productupdate", {id: id, data: data, res: res});
				}, "json");
			},
			// 批量删除产品
			remove: function(ids) {
				$.post(Ibos.app.url('crm/product/del'), {ids: ids}, function(res) {
					$(product).trigger("productremove", {ids: ids, res: res});
				}, "json");
			}
		},
		// 新建、编辑产品对话框入口
		_dialog: function(url, ok) {
			Ui.closeDialog("d_prod_info");
			return Ui.ajaxDialog(url, {
				id: "d_prod_info",
				title: U.lang("CRM.PRODUCT_INFO"),
				cancel: true,
				padding: "20px",
				width: 410,
				lock: true,
				init: function() {
					var $prodForm = $("#prod_info_form");
					$prodForm.find(".radio input").label();
					// 价格强制为有效数字
					$prodForm.on("change", "[name='cost'], [name='price']", function() {
						if (!U.regex(this.value, 'decimals')) {
							var value = this.value.replace(/\,/g, "");
							this.value = U.regex(value, "currency") ? 
										value : 
									Ibos.string.addCommas(Ibos.string.toPositiveDecimals(value, 2));
						}
					});
				},
				ok: function() {
					var $prodForm = $("#prod_info_form"), formData;
					// 产品名称不能为空
					if ($.trim($prodForm[0].name.value) === "") {
						Ui.tip("@CRM.INPUT_PRODUCT_NAME", "warning");
						return false;
					}
					
					formData = $prodForm.serializeArray();
					ok && ok.call(this, formData);
					return false;
				}
			});
		},
		// 打开新建产品对话框
		showAddDialog: function(param) {
			var _this = this;
			return this._dialog(Ibos.app.url('crm/product/add', param || {}), function(formData) {
				_this.op.add(formData);
			});
		},
		// 打开编辑产品对话框
		showEditDialog: function(param) {
			var _this = this;
			return this._dialog(Ibos.app.url('crm/product/edit', param || {}), function(formData) {
				_this.op.update(param.id, formData);
			});
		},
		// 新建、编辑产品目录对话框入口
		_showCateDialog: function(url, ok, opts) {
			return Ui.ajaxDialog(url, $.extend({
				id: "d_prod_category",
				width: 410,
				cancel: true,
				padding: "20px",
				lock: true,
				init: function() {
					this.DOM.content.find("[data-toggle='switch']").iSwitch();
				},
				ok: function() {
					var $form = this.DOM.content.find("form"), formData;
					if ($.trim($form[0].name.value) === "") {
						Ui.tip("@TREEMENU.INPUT_CATEGORY_NAME", "warning");
						$($form[0].name).focus();
						return false;
					}
					formData = $form.serializeArray();
					ok && ok.call(this, formData);
					return false;
				}
			}, opts));
		},
		// 打开新建产品目录对话框
		showAddCateDialog: function(param, ok) {
			var url = Ibos.app.url('crm/productcategory/add', param || {});
			return this._showCateDialog(url, ok, {
				title: U.lang("CRM.ADD_PRODUCT_CATEGORY")
			});
		},
		// 打开编辑产品目录对话框
		showEditCateDialog: function(param, ok) {
			var url = Ibos.app.url('crm/productcategory/edit', param || {});
			return this._showCateDialog(url, ok, {
				title: U.lang("CRM.EDIT_PRODUCT_CATEGORY")
			});
		}
	};


	// 初始化表格控件
	var productTable = $("#product_table").DataTable($.extend(true, {}, Ibos.settings.dataTable, {
		// --- Data
		ajax: {
			url: Ibos.app.url('crm/product/index'),
			type: 'post'
		},
        language: {
            zeroRecords: '<div class="tac"><img src="static/image/common/no-info.png"></div>'
        },
		// --- Callback
		initComplete: function() {
			// Fixed: IE8下表格初始化后需要再次初始化 checkbox，否则触发不了change事件
			$(this).find('[data-name]').label();
		},
		rowCallback: function(row, data) {
			$(row).find("label input[type='checkbox']").label();
		},
		order: [1, "desc"], // ID 倒序
		// --- Column		
		columns: [
			// 复选框
			{
				"data": "",
				"orderable": false,
				"className": "dt-checkbox-td",
				"render": function(data, type, row) {
					return '<label class="checkbox mbz"><input type="checkbox" name="product[]" value="' + row.productid + '"/></label>';
				}
			},
			// ID（隐藏）
			{
				"data": "",
				"visible": false,
				"render": function(data, type, row) {
					return row.productid;
				}
			},
			// 产品名称
			{
				"data": "name",
				"render": function(data, type, row) {
					return '<a href="javascript:;" class="xcm" data-action="editProduct" data-param="{&quot;id&quot;: &quot;' + row.productid + '&quot;}">' + row.name + '</a>';
				}
			},
			// 销售价格
			{
				"data": "price",
				"render": function(data, type, row) {
					return '<span class="fss xco"><em class="ffmy">￥</em>' + row.price + '</span>';
				}
			},
			// 成本价格
			{
				"data": "cost",
				"render": function(data, type, row) {
					return '<span class="fss"><em class="ffmy">￥</em>' + row.cost + '</span>';
				}
			},
			// 单位
			{
				"data": "unit",
				"render": function(data, type, row) {
					return '<span class="fss">' + row.unit + '</span>';
				}
			},
			// 分类
			{
				"data": "category",
				"render": function(data, type, row) {
					return '<span class="fss">' + row.catName + "</span>";
				}
			}
		]
	}));


	$("#product_search").search(function(value) {
		productTable.search(value).draw();
	});


	// 数据交互事件
	$(product).on({
		// 新建产品
		"productadd": function(eve, evtData) {
			if (evtData.res.isSuccess) {
				productTable.draw();
				Ui.tip(evtData.res.msg);
			} else {
				Ui.tip(evtData.res.msg, "danger");
			}
		},
		// 编辑产品信息、删除产品
		"productupdate productremove": function(eve, evtData) {
			if (evtData.res.isSuccess) {
				productTable.draw(false);
				Ui.tip(evtData.res.msg);
			} else {
				Ui.tip(evtData.res.msg, "danger");
			}
		},
		"productadd productupdate": function(evt, evtData) {
			if (evtData.res.isSuccess) {
				Ui.getDialog("d_prod_info").close();
			}
		}
	});


	Ibos.evt.add({
		"addProduct": function(param) {
			product.showAddDialog(param);
		},
		"editProduct": function(param) {
			product.showEditDialog(param);
		},
		"removeProducts": function() {
			var prodIds = U.getCheckedValue("product[]");
			if (!prodIds) {
				Ui.tip("@SELECT_AT_LEAST_ONE_ITEM", "warning");
				return false;
			}
			Ui.confirm(U.lang("CRM.REMOVE_PRODUCT_CONFIRM"), function() {
				product.op.remove(prodIds);
			});

		}
	});


	// 产品目录树配置
	var treeSettings = {
		data: {
			simpleData: {
				enable: true
			}
		},
		view: {
			showLine: false,
			showIcon: false,
			selectedMulti: false,
			addDiyDom: function(treeId, treeNode){
				var $obj = $("#"+ treeNode.tId +"_switch");
				if($obj.hasClass("noline_docu")){
					$obj.removeClass("noline_docu").addClass("noline_close");
				}
			}
		},
		callback: {
			// 点击树节点时，替换dataTable的 ajax 地址刷新表格
			onClick: function(evt, treeId, treeNode) {
				var param = {"catid": treeNode.id};
				$("[data-action='addProduct'").attr("data-param", JSON.stringify(param));
				treeNode.ajaxUrl = treeNode.ajaxUrl || Ibos.app.url("crm/product/index", param);
				treeNode.ajaxUrl && productTable.ajax.url(treeNode.ajaxUrl).load();
			}
		}
	};

	// 初始化树及操作菜单
	$.get(Ibos.app.url('crm/productcategory/index'), function(res) {
		$.map(res, function(item){
			item.name = U.entity.unescape(item.name);
		});
		var treeObj = $.fn.zTree.init($("#prod_cate_tree"), treeSettings, res);
		// 目录树相关操作方法
		var treeCategory = new TreeCategory(treeObj);
		// 目录树菜单
		new TreeCategoryMenu(treeObj, {
			menu: [
				{
					name: "add",
					text: U.lang("NEW"),
					handler: function(treeNode, menuObj) {
						product.showAddCateDialog({catid: treeNode.id}, function(formData) {
							var dialog = this;
							var data = U.serializedToObject(formData);
							treeCategory.add(data, {
								url: Ibos.app.url('crm/productcategory/add'),
								success: function() {
									Ui.tip("@OPERATION_SUCCESS");
									dialog.close();
								}
							});
						});
						menuObj.menu.hide();
					}
				},
				{
					name: "update",
					text: U.lang("EDIT"),
					handler: function(treeNode, menuObj) {
						product.showEditCateDialog({catid: treeNode.id}, function(formData) {
							var dialog = this;
							var data = U.serializedToObject(formData);
							treeCategory.update(treeNode.id, data, {
								url: Ibos.app.url('crm/productcategory/edit'),
								success: function() {
									Ui.tip("@OPERATION_SUCCESS");
									dialog.close();
								},
								error: function(res) {
									Ui.tip(res.msg, "danger");
								}
							});
							menuObj.menu.hide();
						});
					}
				},
				{
					name: "moveup",
					text: U.lang("MOVEUP"),
					handler: function(treeNode, menuObj) {
						treeCategory.moveup(treeNode.id, {
							url: Ibos.app.url('crm/productcategory/edit'),
							success: function() {
								Ui.tip("@OPERATION_SUCCESS");
							}
						});
						menuObj.menu.hide();
					}
				},
				{
					name: "movedown",
					text: U.lang("MOVEDOWN"),
					handler: function(treeNode, menuObj) {
						treeCategory.movedown(treeNode.id, {
							url: Ibos.app.url('crm/productcategory/edit'),
							success: function() {
								Ui.tip("@OPERATION_SUCCESS");
							}
						});
						menuObj.menu.hide();
					}
				},
				{
					name: "remove",
					text: U.lang("DELETE"),
					handler: function(treeNode, menuObj) {
						Ui.confirm(U.lang("CRM.PRODUCT_CATEGORY_CONFIRM"), function() {
							menuObj.$ctrl.hide().appendTo(document.body);
							treeCategory.remove(treeNode.id, {
								url: Ibos.app.url('crm/productcategory/del'),
								success: function() {
									Ui.tip("@OPERATION_SUCCESS");
								},
								error: function(res) {
									Ui.tip(res.msg, 'danger');
								}
							});
							menuObj.menu.hide();
						});
					}
				}
			]
		});
	}, 'json');
});
