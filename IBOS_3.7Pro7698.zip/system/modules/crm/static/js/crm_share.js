/**
 * CRM  通用共享功能
 * @version $Id$
 */
$(function () {
	var share = {
		// 增加共享人员
		addUser: function (uids) {
			var rowHtml = "";
			if (uids) {
				$.each(uids.split(","), function (index, uid) {
					// 拿到用户信息，合并当前时间作为共享时间，生成模板
					var userinfo = Ibos.data.getUser(uid);
					if ($("#crm_share_table tr[data-id='" + uid + "']").length) {
						return true;
					}
					rowHtml += $.template("tpl_crm_share_row", {data: $.extend({
							sharetime: Ibos.date.format(null, "yyyy-mm-dd hh:ii")
						}, userinfo)});
				});
				$(rowHtml).appendTo("#crm_share_table").find(".checkbox input").label();
			}
		},
		// 移除共享人员
		removeUser: function (uids) {
			if (uids) {
				$.each(uids.split(","), function (index, uid) {
					$("#crm_share_table tr[data-id='" + uid + "']").remove();
				});
			}
		}
	};

	$("#share_user_add").userSelect({
		type: "user",
		data: Ibos.data.get("user"),
		box: $("#share_user_add_box")
	});

	$("#crm_share").bindEvents({
		"click .btn-primary": function () {
			var uids = $("#share_user_add").val();
			share.addUser(uids);
			$("#share_user_add").userSelect("setValue", "");
		},
		"click .o-trash": function () {
			var uid = $.attr(this, "data-id"), recid = $.attr(this, "data-recid");
			share.removeUser(uid);
			if (recid) {
				$('#delids').val($('#delids').val() + ',' + recid);
			}
		}
	}).find(".checkbox input").label();
});