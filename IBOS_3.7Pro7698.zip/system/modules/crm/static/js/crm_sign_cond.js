/**
 * Crm 机会 签单条件管理
 * @version $Id$
 */
$(function () {
	var Opp = Crm.Opportunity;

	var _parseForm = function (form) {
		var ret = {};
		ret.name = form.name.value;
		ret.limit = form.limit.value;
		ret.formhash = form.formhash.value;
		ret.condition = [];

		$.each(form['cond[]'], function (i, cd) {
			if ($.trim(cd.value) !== "") {
				ret.condition.push(cd.value);
			}
		});
		return ret;
	};

	var SchemeList = function (container, opts) {
		this._super.apply(this, arguments);
	};

	SchemeList.prototype = {
		add: function (param) {
			var _this = this;
			Opp.showCondInfo({op: 'add'}, function () {
				var $form = this.DOM.content.find("form"), data = _parseForm($form[0]);
				$(Opp).one("schemeadd", function (evt, evtData) {
					_this.addItem(evtData);
					Ui.closeDialog("d_sign_info");
				});
				Opp.op.addScheme(data);
				return false;
			});
		},
		edit: function (param) {
			var _this = this;
			param.op = 'edit';
			Opp.showCondInfo(param, function () {
				var $form = this.DOM.content.find("form"), data = _parseForm($form[0]);
				$(Opp).one("schemeupdate", function (evt, evtData) {
					_this.updateItem(param.id, evtData);
					Ui.closeDialog("d_sign_info");
				});
				Opp.op.updateScheme(param.id, data);
				return false;
			});
		},
		remove: function (param) {
			var _this = this;
			Ui.confirm(U.lang("CRM.DELETE_COND_SCHEME_CONFIRM"), function () {
				$(Opp).one("schemeremove", function (evt, evtData) {
					_this.removeItem(param.id);
				});
				Opp.op.removeScheme(param.id);
			});
		}
	};
	Ibos.core.inherits(SchemeList, Crm.MncardList);
	new SchemeList("#sign_scheme_list", {tpl: "tpl_sign_scheme"});
});
