/**
 * Crm 机会 签单条件设置
 * @version  $Id$
 * @author   inaki
 */
(function () {
	// 根据下拉菜单的值，生成对应数目的输入框
	var cond = {
		$container: $("#opp_cond_custom"),
		$select: $("#opp_cond_count"),
		tpl: "tpl_opp_condition",
		init: function(){
			var _this = this;
			this.$select.change(function(){

				var $children = _this.$container.children(),
					childCount = $children.length,
					diff = +this.value - childCount,
					tplHtml = "";

				// 改变后的值大于原值时，需要增加输入框
				if(diff > 0) {
					for(var i = 0; i < diff; i++) {
						tplHtml += $.template(_this.tpl);
					}
					_this.$container.append(tplHtml);
				// 否则，删除最后面的相应数目输入框
				} else {
					$children.filter(":gt(" + (this.value - 1) + ")").remove();
				}

			})
			.trigger("change");
		}
	};
	cond.init();
})(); 