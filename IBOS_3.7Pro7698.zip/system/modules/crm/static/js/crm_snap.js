/**
 * Crm 快照类
 * @version $Id$
 */

// 快照模型类
Crm.SnapModel = function (settings) {
	this.settings = settings;
	this._id = "";
	this._cache = {};
};
// 从服务器拿到数据，类型为 html
Crm.SnapModel.prototype.fetch = function (param) {
	var _this = this;
	if (param && typeof param.id !== "undefined") {
		// 如果有缓存，则从缓存中读取
		if (this._cache[param.id]) {
			this._id = param.id;
			$(_this).trigger("snapChange", this._cache[param.id]);
			// 没有则从数据库中获取
		} else {
			$.get(this.settings.url, param, function (res) {
				// 写入缓存
				_this._cache[param.id] = res;
				_this._id = param.id;
				$(_this).trigger("snapChange", res);
			});
		}
	}
};

Crm.SnapModel.prototype.getVal = function () {
	return this._id;
};

// 快照视图类
// elements.select
// elements.prevBtn
// elements.nextBtn
// elements.content
Crm.SnapView = function (model, elements) {
	var _this = this;
	this.elements = elements || {};
	$(model).on("snapChange", function (evt, res) {
		_this.render(res);
	});

	var $select = this.$select = $(this.elements.select),
			$prevBtn = this.$prevBtn = $(this.elements.prevBtn),
			$nextBtn = this.$nextBtn = $(this.elements.nextBtn);

	// 如果视图中包含下拉框
	if ($select.length) {
		$select.on("change", function () {
			_this.updateBtnStatus();
			model.fetch({id: this.value});
		});

		// 如果有上下调整选项的按钮
		if ($prevBtn.length) {
			$prevBtn.on("click", function () {
				var $prev = $select.find("option:selected").prev();
				if ($prev && $prev.length) {
					$prev.prop("selected", true);
					$select.trigger("change");
				}
			});
		}
		if ($nextBtn.length) {
			$nextBtn.on("click", function () {
				var $next = $select.find("option:selected").next();
				if ($next && $next.length) {
					$next.prop("selected", true);
					$select.trigger("change");
				}
			});
		}

		$select.trigger("change");
	}
};

// 渲染内容
Crm.SnapView.prototype.render = function (html) {
	var $content = $(this.elements.content);
	if ($content.length) {
		$content.html(html);
	}
};
/**
 * 禁止“上一个快照”按钮
 * @method disablePrevBtn
 * @param  {Boolean} status  是否禁止
 * @return {}
 */
Crm.SnapView.prototype.disablePrevBtn = function (status) {
	if (this.$prevBtn.length) {
		this.$prevBtn.prop("disabled", status);
	}
};
/**
 * 禁止“下一个快照”按钮
 * @method disableNextBtn
 * @param  {Boolean} status  是否禁止
 * @return {}
 */
Crm.SnapView.prototype.disableNextBtn = function (status) {
	if (this.$nextBtn.length) {
		this.$nextBtn.prop("disabled", status);
	}
};
/**
 * 根据选择框的选项更新按钮状态
 * @return {}
 */
Crm.SnapView.prototype.updateBtnStatus = function () {
	var selectElem = this.$select[0],
			isFirstOption = false,
			isLastOption = false;

	if (selectElem) {
		isFirstOption = selectElem.selectedIndex === 0;
		isLastOption = selectElem.selectedIndex === selectElem.options.length - 1;

		this.disablePrevBtn(isFirstOption);
		this.disableNextBtn(isLastOption);
	}
};


// 快照控制器类
Crm.SnapController = function (model, view) {
	this.model = model;
	this.view = view;
};
Crm.SnapController.prototype.get = function (id) {
	this.model.fetch({id: id});
};