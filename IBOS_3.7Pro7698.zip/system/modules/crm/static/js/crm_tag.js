/**
 * Crm 标签管理
 * @author  inaki
 * @version $Id$
 */

$(function () {
	var TagList = function (container, opts) {
		this._super.apply(this, arguments);
	};
	TagList.prototype = {
		correctData: function (data) {
			return $.extend({
				count: 0,
				tags: []
			}, data);
		},
		// 验证数据，标题不能为空
		_valiForm: function (form) {
			if ($.trim(form.name.value) === "") {
				Ui.tip("@CRM.INPUT_TAG_SUBJECT", "warning");
				$(form.name).focus();
				return false;
			}
			return true;
		},
		add: function (param) {
			var _this = this;
			var url = Ibos.app.url('crm/tag/add');
			Ui.closeDialog("d_tag_add");
			Ui.ajaxDialog(url, {
				id: "d_tag_add",
				title: U.lang("CRM.ADD_TAG"),
				lock: true,
				ok: function () {
					var dialog = this, $form = this.DOM.content.find("form"), formData = $form.serializeArray();
					if (_this._valiForm($form[0])) {
						formData.push({name: "op", value: "add"}, {name: "module", value: param.modId});
						$.post(url, formData, function (res) {
							_this.addItem(res.data);
							dialog.close();
						}, "json");
					}
					return false;
				},
				cancel: true
			});
		},
		edit: function (param) {
			var _this = this;
			Ui.closeDialog("d_tag_edit");
			Ui.ajaxDialog(Ibos.app.url('crm/tag/edit', param), {
				id: "d_tag_edit",
				title: U.lang("CRM.EDIT_TAG"),
				lock: true,
				ok: function () {
					var dialog = this, $form = this.DOM.content.find("form"), formData = $form.serializeArray();
					formData.push(
							{name: "op", value: "update"},
							{name: "id", value: param.id},
							{name: "default", value: $('#tag_option_default').find('option:selected').text()}
					);
					if (_this._valiForm($form[0])) {
						$.post(Ibos.app.url('crm/tag/edit'), formData, function (res) {
							if (res.isSuccess) {
								_this.updateItem(param.id, res.data);
								dialog.close();
							} else {
								Ui.tip("@CRM.EDIT_TAG_FAILED", "warning");
							}
						}, "json");
					}
					return false;
				},
				cancel: true
			});
		},
		remove: function (param) {
			var _this = this, formData = [];
			Ui.confirm(U.lang("CRM.REMOVE_TAG_CONFIRM"), function () {
				formData.push({name: "op", value: "remove"}, {name: "id", value: param.id});
				$.post(Ibos.app.url('crm/tag/del'), formData, function (res) {
					_this.removeItem(param.id);
				});
			});
		}
	};
	Ibos.core.inherits(TagList, Crm.MncardList);
	$(".mncard-list").each(function (i, elem) {
		new TagList(elem, {
			tpl: "tpl_tag_group"
		});
	});
});