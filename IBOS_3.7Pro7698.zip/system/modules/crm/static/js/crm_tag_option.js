/**
 * Crm 标签管理 标签选项设置
 * @author  inaki
 * @version $Id$
 */

(function () {
	// 选项列表
	var tagOption = {
		$container: $("#tag_option_list"),
		tpl: "tpl_tag_option",
		// 选色器主要颜色
		colors: ["#DADFE6", "#B2C0D1", "#7AC2F3", "#6FBAEC", "#85E39D", "#A7D85A", "#B2C882", "#FFE18F", "#FFBB6D", "#F1A33D", "#E88C73"],
		// 添加标签选项时，默认选中的颜色值
		defaultColor: "#DADFE6",
		// 初始化选色控件
		_initColorPicker: function ($ctx) {
			var _this = this;

			$(".tag-color-picker", $ctx).each(function () {
				var $elem = $(this),
					$input = $elem.next(),
					$icon = $elem.find("i");

				$elem.colorPicker({
					// 为避免容器事件冲突，此处使用 UniqId 为每个选色器生成独立节点
					// @Todo: 但是会生成大量冗余节点，需要考虑更优的方案
					id: "color_picker_" + U.uniqid(),
					data: _this.colors,
					// 定位左下
					position: {my: "left top", at: "left bottom"},
					speed: 100,
					onPick: function (hex) {
						$input.val(hex);
						$icon.css("background-color", hex);
					}
				});
			});
		},
		init: function () {
			var _this = this;

			this._initColorPicker(this.$container);

			// 执行操作时发布对应的事件
			this.$container.bindEvents({
				"click #tag_option_add": function () {
					_this.add();
				},
				"click .o-trash": function () {
					var $item = $(this).closest("li"), id = $item.attr("data-id");
					$item.remove();
					if (!$(this).hasClass('new')) {
						$('#delids').val($('#delids').val() + ',' + id);
					}
					$(_this).trigger("optionremove", {id: id});
				},
				"change [name='tagOption[]']": function () {
					var $item = $(this).closest("li");
					$(_this).trigger("optionupdate", {id: $item.attr("data-id"), text: this.value});
				},
				"change [name='newtagOption[]']": function () {
					var $item = $(this).closest("li");
					$(_this).trigger("optionupdate", {id: $item.attr("data-id"), text: this.value});
				}
			});
		},
		add: function () {
			var $children = this.$container.children("[data-id]"), // 只有带 data-id 属性的才是有效的子节点
				id = $children.length + 1, // id 根据节点数自增
				$row = $.tmpl(this.tpl, {color: this.defaultColor, id: id});

			this._initColorPicker($row);

			$(this).trigger("optionadd", {id: id});

			// 增加一行后自动聚焦
			if($children.length) {
				$row.insertAfter($children.eq(-1)).find('[name="newtagOption[]"]').focus();
			} else {
				$row.prependTo(this.$container).find('[name="newtagOption[]"]').focus();
			}
			return $row;
		}
	};
	tagOption.init();


	// 标签默认选项下拉菜单
	// 监听选项列表的变化，随之变化选项
	var tagDefault = {
		$container: $("#tag_option_default"),
		add: function (id) {
			return $("<option value='" + id + "'></option>").appendTo(this.$container);
		},
		update: function (id, text) {
			return this.$container.find("option[value='" + id + "']").text(text);
		},
		remove: function (id) {
			return this.$container.find("option[value='" + id + "']").remove();
		},
		init: function () {
			var _this = this;
			$(tagOption).on({
				"optionadd": function (evt, data) {
					_this.add(data.id);
				},
				"optionupdate": function (evt, data) {
					_this.update(data.id, data.text);
				},
				"optionremove": function (evt, data) {
					_this.remove(data.id);
				}
			});
		}
	};
	tagDefault.init();
})();