(function () {
	// 目标数统计表格
	var TgTable = function (element) {
		var _this = this, $element = $(element);
		this.renewTotal = function (quarter) {
			var total = 0;
			$element.find("input[data-quarter='" + quarter + "']").each(function () {
				total += +this.value;
			});
			$element.find("[data-node='total'][data-quarter='" + quarter + "']").html(total);
		};
		$element.on("change", "input[data-quarter]", function () {
			var quarter = $.attr(this, "data-quarter");
			if (!U.isPositiveInt(this.value)) {
				var val = this.value.replace(/\D/g, "").replace(/^0*/, "");
				this.value = val ? val : 0;
			}
			_this.renewTotal(quarter);
		});
	};

	// 获取目标 Html
	// param.submod [param.year]
	var loadTarget = function (param, callback) {
		$.get(Ibos.app.url('crm/target/loadtarget', param), callback);
	};

	// 获取目标某时期的进度数据
	var loadTargetStatus = function (param, callback) {
		$.get(Ibos.app.url('crm/target/loadtargetstatus', param), function (res) {
			callback && callback(res);
		}, "json");
	};

	var loadTargetContainer = function (container, param) {
		var $container = $(container);
		$container.waiting(null, "normal");
		loadTarget(param, function (res) {
			$container.waiting(false)
					.html(res)
					.trigger("loadtarget", param)
					// 绑定年份切换
					.find("[data-year]").on("click", function () {
				loadTargetContainer($container, {op: param.op, year: $.attr(this, "data-year")});
			});
		});
	};
	// 绑定 Tab 事件
	$("#crm_target_tab").tab().on("show", function (evt) {
		var submod = $.attr(evt.target, "data-op");
		var $container = $($.attr(evt.target, "href"));
		if (!$.data(evt.target, "load")) {
			loadTargetContainer($container, {op: submod});
			$.data(evt.target, "load", true);
		}
	}).find("[active][data-toggle='tab']").tab("show");

	var initContainer = function (container, statusTpl) {
		var $container = $(container);
		$container.on("loadtarget", function (evt, data) {
			// 初始化统计表格
			new TgTable($container.find(".crmt-quar-list"));
			// 显示进度视图切换
			$container.find("[data-node='period']").on("change", function () {
				loadTargetStatus({
					op: data.op,
					period: this.value,
					year: data.year
				}, function (res) {
					try {
						$container.find(".crm-target").html($.template(statusTpl, res.data));
					} catch (e) {

					}
				});
			}).trigger("change");
		});
	};
	// 客户数量
	initContainer("#account_target", "tpl_account_progress");
	// 机会数量
	initContainer("#opp_target", "tpl_opp_progress");
	// 合同金额
	initContainer("#contract_target", "tpl_contract_progress");
	// 收款金额
	initContainer("#collection_target", "tpl_collection_progress");
})();