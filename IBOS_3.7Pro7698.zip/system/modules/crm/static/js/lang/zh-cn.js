/**
 * CRM 模块语言包
 * @version $Id$
 */

var L = L || {};
L.CRM = {
	// 通用
	SHARE: 									"共享",
	ASSIGN: 								"分配",
	NEW_ASSIGN: 								"新分配",
	REPEATED_CONDITION: 					"条件重复",
	ADD_SHARE_USER_SUCCESS: 				"增加共享人员成功",
	REMOVE_SHARE_USER_SUCCESS: 				"移除共享人员成功",
	RESTORE_SNAP_SUCCESS: 					"恢复快照成功",
	RESTORE_SNAP_FAIL:						"恢复快照失败`",
	SETUP_TARGET: 							"设置目标",
	SELECT_ASSIGN_USER: 					"请选择要分配的用户",
	SELECT_USER: 							"请选择客户",
	PHONE_TO: 								"拨打电话",
	SEND_MAIL: 								"发送邮件",

	// 查询设置
	SETUP_QUERY: 							"设置查询",
	ADD_QUERY_CONDITION: 					"新建查询条件",
	REMOVE_CONDITION_CONFIRM: 				"确定删除该条件方案吗？",
	INPUT_COND_NAME: 						"请填写条件名称",
	INPUT_COND_SQL: 						"请添加条件语句",
	PLEASE_COMPLETED_CONDITION: 			"请填写完整条件",

	// 线索
	LEAD: 									"线索",
	TRANS_LEAD: 							"转换线索",
	CHECK_REPEAT_ACCOUNT: 					"检查重复的客户",
	REMOVE_LEAD_CONFIRM: 					"确定删除选中的线索吗？",
	// REMOVE_LEAD_SUCCESS: 					"删除线索成功",
	// TRANS_LEAD_SUCCESS: 					"转换线索成功",
	// ADD_LEAD_SUCCESS: 						"添加线索成功",
	// UPDATE_LEAD_SUCCESS: 					"修改线索成功",
	// SHARE_LEAD_SUCCESS: 					"共享线索成功",
	// ASSIGN_LEAD_SUCCESS: 					"分配线索成功",
	INPUT_LEAD_SUBJECT: 					"请填写线索主题",
	INPUT_LEAD_ACCOUNT: 					"请填写线索客户",
	INPUT_LEAD_CONTACT: 					"请填写联系人",
	INPUT_LEAD_PHONE:                       "请输入电话",
	INPUT_LEAD_MOBILE:                      "请输入手机",
	INPUT_LEAD_EMAIL:                       "请输入邮箱",
	INPUT_LEAD_QQ:                       	"请输入qq",
	INPUT_LEAD_WEBSITE:                     "请输入网址",
	INPUT_LEAD_ADDRESS:                     "请输入地址",
	INPUT_LEAD_WEIBO:                     	"请输入微博",
	SURE_CORRECT_PHONE:                     "请输入正确的电话",
	SURE_CORRECT_MOBILE:                    "请输入正确的手机",
	SURE_CORRECT_EMAIL:  					"请输入正确的邮箱",
	SURE_CORRECT_QQ:  						"请输入正确的qq",
	SURE_CORRECT_WEBSITE:                   "请输入正确的网址",

	// 客户
	SELECT_ACCOUNT: 						"选择客户",
	REMOVE_ACCOUNT_CONFIRM: 				"确定删除选中的客户吗？",
	REMOVE_CONTACT_CONFIRM: 				"确定删除选中的联系人吗？",
	DETACH_CONTACT_CONFIRM: 				"确定取消联系人关联吗？",
	// ADD_ACCOUNT_SUCCESS: 					"添加客户成功",
	ACCOUNT_INFO: 							"客户基本信息",
	SHARE_ACCOUNT_SUCCESS: 					"共享客户成功",
	ASSIGN_ACCOUNT_SUCCESS: 				"分配客户成功",
	SELECT_TARGET_HIGHSEAS: 				"选择要移动到的公海",
	PLEASE_SELECT_TARGET_HIGHSEAS: 			"请选择要移动到的公海",
	BAIDU_SEARCH: 							"百度一下",
	INPUT_ACCOUNT_FULLNAME: 				"请填写客户全称",
	DEFAULT_ADDRESS: 						"深圳市",
	ADD_CLIENT:								"新增客户",
	NOT_OPEN_EMAIL_EXTERNAL :				"未安装邮件模块或未开启外部邮箱功能",

	REMOVE_ATTACH_CONFIRM: 					"确定删除该附件吗？",
	REMOVE_ATTACHS_CONFIRM: 				"确定删除选中附件吗？",
	REMOVE_ERECORDS_CONFIRM: 				"确定删除选中电子档吗？",
	REMOVE_ATTACH_SUCCESS: 					"删除附件成功",
	INPUT_ACCOUNT_ZIPCODE:                  "请输入邮编",
	SURE_CORRECT_ZIPCODE:                   "请输入正确的邮编",

	// 联系人
	SELECT_CONTACT: 						"选择联系人",
	CONTACT_INFO: 							"联系人信息",
	SHARE_CONTACT_SUCCESS: 					"共享联系人成功",
	ASSIGN_CONTACT_SUCCESS: 				"分配联系人成功",
	INPUT_CONTACT_NAME: 					"请填写联系人姓名",

	// 附件
	SINGLE_ATTACH_INFO_TPL: 				'已选中 <strong class="xco"><%=name%></strong>，大小 <strong class="xco"><%=size%></strong>，上传于 <%=time%>',
	MULTI_ATTACH_INFO_TPL: 					'已选中 <strong class="xco"><%=count%></strong> 个文件，共 <strong class="xco"><%=size%></strong>',

	// 机会
	SELECT_OPPORTUNITY: 					"选择机会",
	OPPORTUNITY_INFO: 						"机会信息",
	REMOVE_OPP_CONFIRM: 					"确定删除选中的机会吗？",
	SIGN_CONDITION_MANAGE: 					"签单条件管理",
	EDIT_SIGN_CONDITION: 					"编辑签单条件",
	SETUP_SIGN_CONDITION: 					"设置签单条件",
	DELETE_COND_SCHEME_CONFIRM: 			"确定删除签单条件方案吗？",
	INPUT_SCHEME_NAME: 						"请填写方案名称",
	DISPLAY_COUNT_INCORRECT: 				"最多显示条数只能为数字",
	RESTART_OPPORTUNITY: 					"重启机会",
	CLOSE_OPPORTUNITY: 						"关闭机会",
	TRANSACTION_DATA: 						"成交数据",
	INPUT_OPP_SUBJECT: 						"请填写机会主题",
	INPUT_EXPECT_REVENUE:                   "请输入预期收入",
	SURE_CORRECT_EXPECT_REVENUE:            "请输入正确的收入格式",

	// 事件
	EVENT: 									"事件",
	INPUT_EVENT_CONTENT: 					"请填写事件内容",
	REMOVE_RECORDS_CONFIRM: 				"确定删除选中的事件记录吗？",
	// CONCERN_CONTACT: 					"关联联系人",
	// CONCERN_OPPORTUNITY: 				"关联机会",
	// SETUP_TIME: 							"设置时间",

	// 合同
	SELECT_CONTRACT: 						"选择合同",
	REMOVE_CONTRACT_CONFIRM: 				"确定要删除选中的合同吗？",

	// 收款
	COLLECTION_INFO: 						"收款信息",
	COLLECTION_PLAN: 						"收款计划",
	REMOVE_COLLECTION_CONFIRM: 				"确定删除选中的收款信息吗？",
	INPUT_PLAN_COLL_TIME: 					"请填写收款时间",
	CONSISTENT_WITH_PLAN: 					"与计划一致",
	TO_COLLECTED: 							"待收款",

	// 公海管理
	ADD_HIGHSEAS: 							"新建公海",
	EDIT_HIGHSEAS: 							"编辑公海",
	REMOVE_HIGHSEAS_CONFIRM: 				"确定删除该公海吗？",
	INPUT_HIGHSEAS_NAME: 					"请填写公海名称",

	// 权限设置
	AUTH_LEVEL_0: 							"无权限",
	AUTH_LEVEL_1:  							"本人",
	AUTH_LEVEL_2:  							"本部门及下属部门",
	AUTH_LEVEL_4:  							"当前分支机构",
	AUTH_LEVEL_8:  							"全体部门",

	// 标签管理
	ADD_TAG: 								"新建标签",
	EDIT_TAG: 								"编辑标签",
	INPUT_TAG_SUBJECT: 						"请填写标签名称",
	REMOVE_TAG_CONFIRM: 					"确定删除该组标签吗？",
	EDIT_TAG_SUCCEED:						"编辑标签成功",
	EDIT_TAG_FAILED:						"编辑标签失败",

	// 产品服务
	INPUT_PRODUCT_NAME: 					"请填写产品名称",
	PRODUCT_INFO: 							"产品信息",
	REMOVE_PRODUCT_CONFIRM: 				"确定删除选中的产品吗？",
	ADD_PRODUCT_CATEGORY: 					"添加产品分类",
	EDIT_PRODUCT_CATEGORY: 					"编辑产品分类",
	PRODUCT_CATEGORY_CONFIRM:				"确定删除该产品目录吗？"
};
